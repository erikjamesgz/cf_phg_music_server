var __defProp = Object.defineProperty;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __esm = (fn, res) => function __init() {
  return fn && (res = (0, fn[__getOwnPropNames(fn)[0]])(fn = 0)), res;
};
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};

// node_modules/@jitl/quickjs-ffi-types/dist/index.mjs
var init_dist = __esm({
  "node_modules/@jitl/quickjs-ffi-types/dist/index.mjs"() {
  }
});

// node_modules/@jitl/quickjs-wasmfile-release-sync/dist/ffi.mjs
var ffi_exports = {};
__export(ffi_exports, {
  QuickJSFFI: () => QuickJSFFI
});
var QuickJSFFI;
var init_ffi = __esm({
  "node_modules/@jitl/quickjs-wasmfile-release-sync/dist/ffi.mjs"() {
    QuickJSFFI = class {
      constructor(module) {
        this.module = module;
        this.DEBUG = false;
        this.QTS_Throw = this.module.cwrap("QTS_Throw", "number", ["number", "number"]);
        this.QTS_NewError = this.module.cwrap("QTS_NewError", "number", ["number"]);
        this.QTS_RuntimeSetMemoryLimit = this.module.cwrap("QTS_RuntimeSetMemoryLimit", null, ["number", "number"]);
        this.QTS_RuntimeComputeMemoryUsage = this.module.cwrap("QTS_RuntimeComputeMemoryUsage", "number", ["number", "number"]);
        this.QTS_RuntimeDumpMemoryUsage = this.module.cwrap("QTS_RuntimeDumpMemoryUsage", "number", ["number"]);
        this.QTS_RecoverableLeakCheck = this.module.cwrap("QTS_RecoverableLeakCheck", "number", []);
        this.QTS_BuildIsSanitizeLeak = this.module.cwrap("QTS_BuildIsSanitizeLeak", "number", []);
        this.QTS_RuntimeSetMaxStackSize = this.module.cwrap("QTS_RuntimeSetMaxStackSize", null, ["number", "number"]);
        this.QTS_GetUndefined = this.module.cwrap("QTS_GetUndefined", "number", []);
        this.QTS_GetNull = this.module.cwrap("QTS_GetNull", "number", []);
        this.QTS_GetFalse = this.module.cwrap("QTS_GetFalse", "number", []);
        this.QTS_GetTrue = this.module.cwrap("QTS_GetTrue", "number", []);
        this.QTS_NewRuntime = this.module.cwrap("QTS_NewRuntime", "number", []);
        this.QTS_FreeRuntime = this.module.cwrap("QTS_FreeRuntime", null, ["number"]);
        this.QTS_NewContext = this.module.cwrap("QTS_NewContext", "number", ["number", "number"]);
        this.QTS_FreeContext = this.module.cwrap("QTS_FreeContext", null, ["number"]);
        this.QTS_FreeValuePointer = this.module.cwrap("QTS_FreeValuePointer", null, ["number", "number"]);
        this.QTS_FreeValuePointerRuntime = this.module.cwrap("QTS_FreeValuePointerRuntime", null, ["number", "number"]);
        this.QTS_FreeVoidPointer = this.module.cwrap("QTS_FreeVoidPointer", null, ["number", "number"]);
        this.QTS_FreeCString = this.module.cwrap("QTS_FreeCString", null, ["number", "number"]);
        this.QTS_DupValuePointer = this.module.cwrap("QTS_DupValuePointer", "number", ["number", "number"]);
        this.QTS_NewObject = this.module.cwrap("QTS_NewObject", "number", ["number"]);
        this.QTS_NewObjectProto = this.module.cwrap("QTS_NewObjectProto", "number", ["number", "number"]);
        this.QTS_NewArray = this.module.cwrap("QTS_NewArray", "number", ["number"]);
        this.QTS_NewArrayBuffer = this.module.cwrap("QTS_NewArrayBuffer", "number", ["number", "number", "number"]);
        this.QTS_NewFloat64 = this.module.cwrap("QTS_NewFloat64", "number", ["number", "number"]);
        this.QTS_GetFloat64 = this.module.cwrap("QTS_GetFloat64", "number", ["number", "number"]);
        this.QTS_NewString = this.module.cwrap("QTS_NewString", "number", ["number", "number"]);
        this.QTS_GetString = this.module.cwrap("QTS_GetString", "number", ["number", "number"]);
        this.QTS_GetArrayBuffer = this.module.cwrap("QTS_GetArrayBuffer", "number", ["number", "number"]);
        this.QTS_GetArrayBufferLength = this.module.cwrap("QTS_GetArrayBufferLength", "number", ["number", "number"]);
        this.QTS_NewSymbol = this.module.cwrap("QTS_NewSymbol", "number", ["number", "number", "number"]);
        this.QTS_GetSymbolDescriptionOrKey = this.module.cwrap("QTS_GetSymbolDescriptionOrKey", "number", ["number", "number"]);
        this.QTS_IsGlobalSymbol = this.module.cwrap("QTS_IsGlobalSymbol", "number", ["number", "number"]);
        this.QTS_IsJobPending = this.module.cwrap("QTS_IsJobPending", "number", ["number"]);
        this.QTS_ExecutePendingJob = this.module.cwrap("QTS_ExecutePendingJob", "number", ["number", "number", "number"]);
        this.QTS_GetProp = this.module.cwrap("QTS_GetProp", "number", ["number", "number", "number"]);
        this.QTS_GetPropNumber = this.module.cwrap("QTS_GetPropNumber", "number", ["number", "number", "number"]);
        this.QTS_SetProp = this.module.cwrap("QTS_SetProp", null, ["number", "number", "number", "number"]);
        this.QTS_DefineProp = this.module.cwrap("QTS_DefineProp", null, ["number", "number", "number", "number", "number", "number", "boolean", "boolean", "boolean"]);
        this.QTS_GetOwnPropertyNames = this.module.cwrap("QTS_GetOwnPropertyNames", "number", ["number", "number", "number", "number", "number"]);
        this.QTS_Call = this.module.cwrap("QTS_Call", "number", ["number", "number", "number", "number", "number"]);
        this.QTS_ResolveException = this.module.cwrap("QTS_ResolveException", "number", ["number", "number"]);
        this.QTS_Dump = this.module.cwrap("QTS_Dump", "number", ["number", "number"]);
        this.QTS_Eval = this.module.cwrap("QTS_Eval", "number", ["number", "number", "number", "string", "number", "number"]);
        this.QTS_GetModuleNamespace = this.module.cwrap("QTS_GetModuleNamespace", "number", ["number", "number"]);
        this.QTS_Typeof = this.module.cwrap("QTS_Typeof", "number", ["number", "number"]);
        this.QTS_GetLength = this.module.cwrap("QTS_GetLength", "number", ["number", "number", "number"]);
        this.QTS_IsEqual = this.module.cwrap("QTS_IsEqual", "number", ["number", "number", "number", "number"]);
        this.QTS_GetGlobalObject = this.module.cwrap("QTS_GetGlobalObject", "number", ["number"]);
        this.QTS_NewPromiseCapability = this.module.cwrap("QTS_NewPromiseCapability", "number", ["number", "number"]);
        this.QTS_PromiseState = this.module.cwrap("QTS_PromiseState", "number", ["number", "number"]);
        this.QTS_PromiseResult = this.module.cwrap("QTS_PromiseResult", "number", ["number", "number"]);
        this.QTS_TestStringArg = this.module.cwrap("QTS_TestStringArg", null, ["string"]);
        this.QTS_GetDebugLogEnabled = this.module.cwrap("QTS_GetDebugLogEnabled", "number", ["number"]);
        this.QTS_SetDebugLogEnabled = this.module.cwrap("QTS_SetDebugLogEnabled", null, ["number", "number"]);
        this.QTS_BuildIsDebug = this.module.cwrap("QTS_BuildIsDebug", "number", []);
        this.QTS_BuildIsAsyncify = this.module.cwrap("QTS_BuildIsAsyncify", "number", []);
        this.QTS_NewFunction = this.module.cwrap("QTS_NewFunction", "number", ["number", "number", "string"]);
        this.QTS_ArgvGetJSValueConstPointer = this.module.cwrap("QTS_ArgvGetJSValueConstPointer", "number", ["number", "number"]);
        this.QTS_RuntimeEnableInterruptHandler = this.module.cwrap("QTS_RuntimeEnableInterruptHandler", null, ["number"]);
        this.QTS_RuntimeDisableInterruptHandler = this.module.cwrap("QTS_RuntimeDisableInterruptHandler", null, ["number"]);
        this.QTS_RuntimeEnableModuleLoader = this.module.cwrap("QTS_RuntimeEnableModuleLoader", null, ["number", "number"]);
        this.QTS_RuntimeDisableModuleLoader = this.module.cwrap("QTS_RuntimeDisableModuleLoader", null, ["number"]);
        this.QTS_bjson_encode = this.module.cwrap("QTS_bjson_encode", "number", ["number", "number"]);
        this.QTS_bjson_decode = this.module.cwrap("QTS_bjson_decode", "number", ["number", "number"]);
      }
    };
  }
});

// node_modules/@jitl/quickjs-wasmfile-release-sync/dist/emscripten-module.browser.mjs
var emscripten_module_browser_exports = {};
__export(emscripten_module_browser_exports, {
  default: () => emscripten_module_browser_default
});
var QuickJSRaw, emscripten_module_browser_default;
var init_emscripten_module_browser = __esm({
  "node_modules/@jitl/quickjs-wasmfile-release-sync/dist/emscripten-module.browser.mjs"() {
    QuickJSRaw = (() => {
      var _scriptName = import.meta.url;
      return (function(moduleArg = {}) {
        var moduleRtn;
        var c = moduleArg, f, n, aa = new Promise((a, b) => {
          f = a;
          n = b;
        }), ba = "object" == typeof window, p = "function" == typeof importScripts;
        function r(a) {
          a = { log: a || function() {
          } };
          for (const b of r.Ia) b(a);
          return c.quickJSEmscriptenExtensions = a;
        }
        r.Ia = [];
        c.quickjsEmscriptenInit = r;
        r.Ia.push((a) => {
          a.getWasmMemory = function() {
            return t;
          };
        });
        var u = Object.assign({}, c), w = "./this.program", x = "", y, z;
        if (ba || p) p ? x = self.location.href : "undefined" != typeof document && document.currentScript && (x = document.currentScript.src), _scriptName && (x = _scriptName), x.startsWith("blob:") ? x = "" : x = x.substr(0, x.replace(/[?#].*/, "").lastIndexOf("/") + 1), p && (z = (a) => {
          var b = new XMLHttpRequest();
          b.open("GET", a, false);
          b.responseType = "arraybuffer";
          b.send(null);
          return new Uint8Array(b.response);
        }), y = (a) => fetch(a, { credentials: "same-origin" }).then((b) => b.ok ? b.arrayBuffer() : Promise.reject(Error(b.status + " : " + b.url)));
        var ca = c.print || console.log.bind(console), A = c.printErr || console.error.bind(console);
        Object.assign(c, u);
        u = null;
        c.thisProgram && (w = c.thisProgram);
        var B = c.wasmBinary, t, C = false, D, E, F, G, H;
        function I() {
          var a = t.buffer;
          c.HEAP8 = E = new Int8Array(a);
          c.HEAP16 = new Int16Array(a);
          c.HEAPU8 = F = new Uint8Array(a);
          c.HEAPU16 = new Uint16Array(a);
          c.HEAP32 = G = new Int32Array(a);
          c.HEAPU32 = H = new Uint32Array(a);
          c.HEAPF32 = new Float32Array(a);
          c.HEAPF64 = new Float64Array(a);
        }
        c.wasmMemory ? t = c.wasmMemory : t = new WebAssembly.Memory({ initial: (c.INITIAL_MEMORY || 16777216) / 65536, maximum: 32768 });
        I();
        var J = [], da = [], ea = [];
        function fa() {
          var a = c.preRun.shift();
          J.unshift(a);
        }
        var K = 0, L = null, M = null;
        function N(a) {
          c.onAbort?.(a);
          a = "Aborted(" + a + ")";
          A(a);
          C = true;
          D = 1;
          a = new WebAssembly.RuntimeError(a + ". Build with -sASSERTIONS for more info.");
          n(a);
          throw a;
        }
        var ha = (a) => a.startsWith("data:application/octet-stream;base64,"), O;
        function ia(a) {
          if (a == O && B) return new Uint8Array(B);
          if (z) return z(a);
          throw "both async and sync fetching of the wasm failed";
        }
        function ja(a) {
          return B ? Promise.resolve().then(() => ia(a)) : y(a).then((b) => new Uint8Array(b), () => ia(a));
        }
        function ka(a, b, d) {
          return ja(a).then((e) => WebAssembly.instantiate(e, b)).then(d, (e) => {
            A(`failed to asynchronously prepare wasm: ${e}`);
            N(e);
          });
        }
        function la(a, b) {
          var d = O;
          return B || "function" != typeof WebAssembly.instantiateStreaming || ha(d) || "function" != typeof fetch ? ka(d, a, b) : fetch(d, { credentials: "same-origin" }).then((e) => WebAssembly.instantiateStreaming(e, a).then(b, function(g) {
            A(`wasm streaming compile failed: ${g}`);
            A("falling back to ArrayBuffer instantiation");
            return ka(d, a, b);
          }));
        }
        function ma(a) {
          this.name = "ExitStatus";
          this.message = `Program terminated with exit(${a})`;
          this.status = a;
        }
        var P = (a) => {
          for (; 0 < a.length; ) a.shift()(c);
        }, Q = c.noExitRuntime || true, oa = "undefined" != typeof TextDecoder ? new TextDecoder() : void 0, R = (a, b, d) => {
          var e = b + d;
          for (d = b; a[d] && !(d >= e); ) ++d;
          if (16 < d - b && a.buffer && oa) return oa.decode(a.subarray(b, d));
          for (e = ""; b < d; ) {
            var g = a[b++];
            if (g & 128) {
              var h = a[b++] & 63;
              if (192 == (g & 224)) e += String.fromCharCode((g & 31) << 6 | h);
              else {
                var k = a[b++] & 63;
                g = 224 == (g & 240) ? (g & 15) << 12 | h << 6 | k : (g & 7) << 18 | h << 12 | k << 6 | a[b++] & 63;
                65536 > g ? e += String.fromCharCode(g) : (g -= 65536, e += String.fromCharCode(55296 | g >> 10, 56320 | g & 1023));
              }
            } else e += String.fromCharCode(g);
          }
          return e;
        }, pa = [0, 31, 60, 91, 121, 152, 182, 213, 244, 274, 305, 335], qa = [0, 31, 59, 90, 120, 151, 181, 212, 243, 273, 304, 334], S = {}, ra = (a) => {
          if (!(a instanceof ma || "unwind" == a)) throw a;
        }, T = 0, sa = (a) => {
          D = a;
          Q || 0 < T || (c.onExit?.(a), C = true);
          throw new ma(a);
        }, ta = (a) => {
          if (!C) try {
            if (a(), !(Q || 0 < T)) try {
              D = a = D, sa(a);
            } catch (b) {
              ra(b);
            }
          } catch (b) {
            ra(b);
          }
        }, ua;
        ua = () => performance.now();
        var U = (a, b, d) => {
          var e = F;
          if (!(0 < d)) return 0;
          var g = b;
          d = b + d - 1;
          for (var h = 0; h < a.length; ++h) {
            var k = a.charCodeAt(h);
            if (55296 <= k && 57343 >= k) {
              var l = a.charCodeAt(++h);
              k = 65536 + ((k & 1023) << 10) | l & 1023;
            }
            if (127 >= k) {
              if (b >= d) break;
              e[b++] = k;
            } else {
              if (2047 >= k) {
                if (b + 1 >= d) break;
                e[b++] = 192 | k >> 6;
              } else {
                if (65535 >= k) {
                  if (b + 2 >= d) break;
                  e[b++] = 224 | k >> 12;
                } else {
                  if (b + 3 >= d) break;
                  e[b++] = 240 | k >> 18;
                  e[b++] = 128 | k >> 12 & 63;
                }
                e[b++] = 128 | k >> 6 & 63;
              }
              e[b++] = 128 | k & 63;
            }
          }
          e[b] = 0;
          return b - g;
        }, V = {}, va = () => {
          if (!W) {
            var a = {
              USER: "web_user",
              LOGNAME: "web_user",
              PATH: "/",
              PWD: "/",
              HOME: "/home/web_user",
              LANG: ("object" == typeof navigator && navigator.languages && navigator.languages[0] || "C").replace("-", "_") + ".UTF-8",
              _: w || "./this.program"
            }, b;
            for (b in V) void 0 === V[b] ? delete a[b] : a[b] = V[b];
            var d = [];
            for (b in a) d.push(`${b}=${a[b]}`);
            W = d;
          }
          return W;
        }, W, wa = [null, [], []], xa = (a) => {
          for (var b = 0, d = 0; d < a.length; ++d) {
            var e = a.charCodeAt(d);
            127 >= e ? b++ : 2047 >= e ? b += 2 : 55296 <= e && 57343 >= e ? (b += 4, ++d) : b += 3;
          }
          return b;
        }, Aa = (a, b, d, e) => {
          var g = { string: (m) => {
            var q = 0;
            if (null !== m && void 0 !== m && 0 !== m) {
              q = xa(m) + 1;
              var na = X(q);
              U(m, na, q);
              q = na;
            }
            return q;
          }, array: (m) => {
            var q = X(m.length);
            E.set(m, q);
            return q;
          } };
          a = c["_" + a];
          var h = [], k = 0;
          if (e) for (var l = 0; l < e.length; l++) {
            var v = g[d[l]];
            v ? (0 === k && (k = ya()), h[l] = v(e[l])) : h[l] = e[l];
          }
          d = a(...h);
          return d = (function(m) {
            0 !== k && za(k);
            return "string" === b ? m ? R(F, m) : "" : "boolean" === b ? !!m : m;
          })(d);
        }, Ca = { b: (a, b, d, e) => {
          N(`Assertion failed: ${a ? R(F, a) : ""}, at: ` + [b ? b ? R(F, b) : "" : "unknown filename", d, e ? e ? R(F, e) : "" : "unknown function"]);
        }, q: () => {
          N("");
        }, n: () => {
          Q = false;
          T = 0;
        }, j: function(a, b, d) {
          a = new Date(1e3 * (b + 2097152 >>> 0 < 4194305 - !!a ? (a >>> 0) + 4294967296 * b : NaN));
          G[d >> 2] = a.getSeconds();
          G[d + 4 >> 2] = a.getMinutes();
          G[d + 8 >> 2] = a.getHours();
          G[d + 12 >> 2] = a.getDate();
          G[d + 16 >> 2] = a.getMonth();
          G[d + 20 >> 2] = a.getFullYear() - 1900;
          G[d + 24 >> 2] = a.getDay();
          b = a.getFullYear();
          G[d + 28 >> 2] = (0 !== b % 4 || 0 === b % 100 && 0 !== b % 400 ? qa : pa)[a.getMonth()] + a.getDate() - 1 | 0;
          G[d + 36 >> 2] = -(60 * a.getTimezoneOffset());
          b = new Date(a.getFullYear(), 6, 1).getTimezoneOffset();
          var e = new Date(a.getFullYear(), 0, 1).getTimezoneOffset();
          G[d + 32 >> 2] = (b != e && a.getTimezoneOffset() == Math.min(e, b)) | 0;
        }, l: (a, b) => {
          S[a] && (clearTimeout(S[a].id), delete S[a]);
          if (!b) return 0;
          var d = setTimeout(() => {
            delete S[a];
            ta(() => Ba(a, ua()));
          }, b);
          S[a] = { id: d, Na: b };
          return 0;
        }, o: (a, b, d, e) => {
          var g = (/* @__PURE__ */ new Date()).getFullYear(), h = new Date(g, 0, 1).getTimezoneOffset();
          g = new Date(g, 6, 1).getTimezoneOffset();
          H[a >> 2] = 60 * Math.max(h, g);
          G[b >> 2] = Number(h != g);
          b = (k) => {
            var l = Math.abs(k);
            return `UTC${0 <= k ? "-" : "+"}${String(Math.floor(l / 60)).padStart(2, "0")}${String(l % 60).padStart(2, "0")}`;
          };
          a = b(h);
          b = b(g);
          g < h ? (U(a, d, 17), U(
            b,
            e,
            17
          )) : (U(a, e, 17), U(b, d, 17));
        }, p: () => Date.now(), m: (a) => {
          var b = F.length;
          a >>>= 0;
          if (2147483648 < a) return false;
          for (var d = 1; 4 >= d; d *= 2) {
            var e = b * (1 + 0.2 / d);
            e = Math.min(e, a + 100663296);
            a: {
              e = (Math.min(2147483648, 65536 * Math.ceil(Math.max(a, e) / 65536)) - t.buffer.byteLength + 65535) / 65536;
              try {
                t.grow(e);
                I();
                var g = 1;
                break a;
              } catch (h) {
              }
              g = void 0;
            }
            if (g) return true;
          }
          return false;
        }, f: (a, b) => {
          var d = 0;
          va().forEach((e, g) => {
            var h = b + d;
            g = H[a + 4 * g >> 2] = h;
            for (h = 0; h < e.length; ++h) E[g++] = e.charCodeAt(h);
            E[g] = 0;
            d += e.length + 1;
          });
          return 0;
        }, g: (a, b) => {
          var d = va();
          H[a >> 2] = d.length;
          var e = 0;
          d.forEach((g) => e += g.length + 1);
          H[b >> 2] = e;
          return 0;
        }, e: () => 52, k: function() {
          return 70;
        }, d: (a, b, d, e) => {
          for (var g = 0, h = 0; h < d; h++) {
            var k = H[b >> 2], l = H[b + 4 >> 2];
            b += 8;
            for (var v = 0; v < l; v++) {
              var m = F[k + v], q = wa[a];
              0 === m || 10 === m ? ((1 === a ? ca : A)(R(q, 0)), q.length = 0) : q.push(m);
            }
            g += l;
          }
          H[e >> 2] = g;
          return 0;
        }, a: t, c: sa, s: function(a, b, d, e, g) {
          return c.callbacks.callFunction(void 0, a, b, d, e, g);
        }, r: function(a) {
          return c.callbacks.shouldInterrupt(void 0, a);
        }, i: function(a, b, d) {
          d = d ? R(F, d) : "";
          return c.callbacks.loadModuleSource(
            void 0,
            a,
            b,
            d
          );
        }, h: function(a, b, d, e) {
          d = d ? R(F, d) : "";
          e = e ? R(F, e) : "";
          return c.callbacks.normalizeModule(void 0, a, b, d, e);
        } }, Y = (function() {
          function a(d) {
            Y = d.exports;
            da.unshift(Y.t);
            K--;
            c.monitorRunDependencies?.(K);
            0 == K && (null !== L && (clearInterval(L), L = null), M && (d = M, M = null, d()));
            return Y;
          }
          var b = { a: Ca };
          K++;
          c.monitorRunDependencies?.(K);
          if (c.instantiateWasm) try {
            return c.instantiateWasm(b, a);
          } catch (d) {
            A(`Module.instantiateWasm callback failed with error: ${d}`), n(d);
          }
          O ||= c.locateFile ? ha("emscripten-module.wasm") ? "emscripten-module.wasm" : c.locateFile ? c.locateFile("emscripten-module.wasm", x) : x + "emscripten-module.wasm" : new URL("emscripten-module.wasm", import.meta.url).href;
          la(b, function(d) {
            a(d.instance);
          }).catch(n);
          return {};
        })();
        c._malloc = (a) => (c._malloc = Y.u)(a);
        c._QTS_Throw = (a, b) => (c._QTS_Throw = Y.v)(a, b);
        c._QTS_NewError = (a) => (c._QTS_NewError = Y.w)(a);
        c._QTS_RuntimeSetMemoryLimit = (a, b) => (c._QTS_RuntimeSetMemoryLimit = Y.x)(a, b);
        c._QTS_RuntimeComputeMemoryUsage = (a, b) => (c._QTS_RuntimeComputeMemoryUsage = Y.y)(a, b);
        c._QTS_RuntimeDumpMemoryUsage = (a) => (c._QTS_RuntimeDumpMemoryUsage = Y.z)(a);
        c._QTS_RecoverableLeakCheck = () => (c._QTS_RecoverableLeakCheck = Y.A)();
        c._QTS_BuildIsSanitizeLeak = () => (c._QTS_BuildIsSanitizeLeak = Y.B)();
        c._QTS_RuntimeSetMaxStackSize = (a, b) => (c._QTS_RuntimeSetMaxStackSize = Y.C)(a, b);
        c._QTS_GetUndefined = () => (c._QTS_GetUndefined = Y.D)();
        c._QTS_GetNull = () => (c._QTS_GetNull = Y.E)();
        c._QTS_GetFalse = () => (c._QTS_GetFalse = Y.F)();
        c._QTS_GetTrue = () => (c._QTS_GetTrue = Y.G)();
        c._QTS_NewRuntime = () => (c._QTS_NewRuntime = Y.H)();
        c._QTS_FreeRuntime = (a) => (c._QTS_FreeRuntime = Y.I)(a);
        c._free = (a) => (c._free = Y.J)(a);
        c._QTS_NewContext = (a, b) => (c._QTS_NewContext = Y.K)(a, b);
        c._QTS_FreeContext = (a) => (c._QTS_FreeContext = Y.L)(a);
        c._QTS_FreeValuePointer = (a, b) => (c._QTS_FreeValuePointer = Y.M)(a, b);
        c._QTS_FreeValuePointerRuntime = (a, b) => (c._QTS_FreeValuePointerRuntime = Y.N)(a, b);
        c._QTS_FreeVoidPointer = (a, b) => (c._QTS_FreeVoidPointer = Y.O)(a, b);
        c._QTS_FreeCString = (a, b) => (c._QTS_FreeCString = Y.P)(a, b);
        c._QTS_DupValuePointer = (a, b) => (c._QTS_DupValuePointer = Y.Q)(a, b);
        c._QTS_NewObject = (a) => (c._QTS_NewObject = Y.R)(a);
        c._QTS_NewObjectProto = (a, b) => (c._QTS_NewObjectProto = Y.S)(a, b);
        c._QTS_NewArray = (a) => (c._QTS_NewArray = Y.T)(a);
        c._QTS_NewArrayBuffer = (a, b, d) => (c._QTS_NewArrayBuffer = Y.U)(a, b, d);
        c._QTS_NewFloat64 = (a, b) => (c._QTS_NewFloat64 = Y.V)(a, b);
        c._QTS_GetFloat64 = (a, b) => (c._QTS_GetFloat64 = Y.W)(a, b);
        c._QTS_NewString = (a, b) => (c._QTS_NewString = Y.X)(a, b);
        c._QTS_GetString = (a, b) => (c._QTS_GetString = Y.Y)(a, b);
        c._QTS_GetArrayBuffer = (a, b) => (c._QTS_GetArrayBuffer = Y.Z)(a, b);
        c._QTS_GetArrayBufferLength = (a, b) => (c._QTS_GetArrayBufferLength = Y._)(a, b);
        c._QTS_NewSymbol = (a, b, d) => (c._QTS_NewSymbol = Y.$)(a, b, d);
        c._QTS_GetSymbolDescriptionOrKey = (a, b) => (c._QTS_GetSymbolDescriptionOrKey = Y.aa)(a, b);
        c._QTS_IsGlobalSymbol = (a, b) => (c._QTS_IsGlobalSymbol = Y.ba)(a, b);
        c._QTS_IsJobPending = (a) => (c._QTS_IsJobPending = Y.ca)(a);
        c._QTS_ExecutePendingJob = (a, b, d) => (c._QTS_ExecutePendingJob = Y.da)(a, b, d);
        c._QTS_GetProp = (a, b, d) => (c._QTS_GetProp = Y.ea)(a, b, d);
        c._QTS_GetPropNumber = (a, b, d) => (c._QTS_GetPropNumber = Y.fa)(a, b, d);
        c._QTS_SetProp = (a, b, d, e) => (c._QTS_SetProp = Y.ga)(a, b, d, e);
        c._QTS_DefineProp = (a, b, d, e, g, h, k, l, v) => (c._QTS_DefineProp = Y.ha)(a, b, d, e, g, h, k, l, v);
        c._QTS_GetOwnPropertyNames = (a, b, d, e, g) => (c._QTS_GetOwnPropertyNames = Y.ia)(a, b, d, e, g);
        c._QTS_Call = (a, b, d, e, g) => (c._QTS_Call = Y.ja)(a, b, d, e, g);
        c._QTS_ResolveException = (a, b) => (c._QTS_ResolveException = Y.ka)(a, b);
        c._QTS_Dump = (a, b) => (c._QTS_Dump = Y.la)(a, b);
        c._QTS_Eval = (a, b, d, e, g, h) => (c._QTS_Eval = Y.ma)(a, b, d, e, g, h);
        c._QTS_GetModuleNamespace = (a, b) => (c._QTS_GetModuleNamespace = Y.na)(a, b);
        c._QTS_Typeof = (a, b) => (c._QTS_Typeof = Y.oa)(a, b);
        c._QTS_GetLength = (a, b, d) => (c._QTS_GetLength = Y.pa)(a, b, d);
        c._QTS_IsEqual = (a, b, d, e) => (c._QTS_IsEqual = Y.qa)(a, b, d, e);
        c._QTS_GetGlobalObject = (a) => (c._QTS_GetGlobalObject = Y.ra)(a);
        c._QTS_NewPromiseCapability = (a, b) => (c._QTS_NewPromiseCapability = Y.sa)(a, b);
        c._QTS_PromiseState = (a, b) => (c._QTS_PromiseState = Y.ta)(a, b);
        c._QTS_PromiseResult = (a, b) => (c._QTS_PromiseResult = Y.ua)(a, b);
        c._QTS_TestStringArg = (a) => (c._QTS_TestStringArg = Y.va)(a);
        c._QTS_GetDebugLogEnabled = (a) => (c._QTS_GetDebugLogEnabled = Y.wa)(a);
        c._QTS_SetDebugLogEnabled = (a, b) => (c._QTS_SetDebugLogEnabled = Y.xa)(a, b);
        c._QTS_BuildIsDebug = () => (c._QTS_BuildIsDebug = Y.ya)();
        c._QTS_BuildIsAsyncify = () => (c._QTS_BuildIsAsyncify = Y.za)();
        c._QTS_NewFunction = (a, b, d) => (c._QTS_NewFunction = Y.Aa)(a, b, d);
        c._QTS_ArgvGetJSValueConstPointer = (a, b) => (c._QTS_ArgvGetJSValueConstPointer = Y.Ba)(a, b);
        c._QTS_RuntimeEnableInterruptHandler = (a) => (c._QTS_RuntimeEnableInterruptHandler = Y.Ca)(a);
        c._QTS_RuntimeDisableInterruptHandler = (a) => (c._QTS_RuntimeDisableInterruptHandler = Y.Da)(a);
        c._QTS_RuntimeEnableModuleLoader = (a, b) => (c._QTS_RuntimeEnableModuleLoader = Y.Ea)(a, b);
        c._QTS_RuntimeDisableModuleLoader = (a) => (c._QTS_RuntimeDisableModuleLoader = Y.Fa)(a);
        c._QTS_bjson_encode = (a, b) => (c._QTS_bjson_encode = Y.Ga)(a, b);
        c._QTS_bjson_decode = (a, b) => (c._QTS_bjson_decode = Y.Ha)(a, b);
        var Ba = (a, b) => (Ba = Y.Ja)(a, b), za = (a) => (za = Y.Ka)(a), X = (a) => (X = Y.La)(a), ya = () => (ya = Y.Ma)();
        c.cwrap = (a, b, d, e) => {
          var g = !d || d.every((h) => "number" === h || "boolean" === h);
          return "string" !== b && g && !e ? c["_" + a] : (...h) => Aa(a, b, d, h);
        };
        c.UTF8ToString = (a, b) => a ? R(F, a, b) : "";
        c.stringToUTF8 = (a, b, d) => U(a, b, d);
        c.lengthBytesUTF8 = xa;
        var Z;
        M = function Da() {
          Z || Ea();
          Z || (M = Da);
        };
        function Ea() {
          function a() {
            if (!Z && (Z = true, c.calledRun = true, !C)) {
              P(da);
              f(c);
              c.onRuntimeInitialized?.();
              if (c.postRun) for ("function" == typeof c.postRun && (c.postRun = [c.postRun]); c.postRun.length; ) {
                var b = c.postRun.shift();
                ea.unshift(b);
              }
              P(ea);
            }
          }
          if (!(0 < K)) {
            if (c.preRun) for ("function" == typeof c.preRun && (c.preRun = [c.preRun]); c.preRun.length; ) fa();
            P(J);
            0 < K || (c.setStatus ? (c.setStatus("Running..."), setTimeout(function() {
              setTimeout(function() {
                c.setStatus("");
              }, 1);
              a();
            }, 1)) : a());
          }
        }
        if (c.preInit) for ("function" == typeof c.preInit && (c.preInit = [c.preInit]); 0 < c.preInit.length; ) c.preInit.pop()();
        Ea();
        moduleRtn = aa;
        return moduleRtn;
      });
    })();
    emscripten_module_browser_default = QuickJSRaw;
  }
});

// node_modules/@cf-wasm/quickjs/node_modules/@jitl/quickjs-ffi-types/dist/index.mjs
function assertSync(fn) {
  return function(...args) {
    let result = fn(...args);
    if (result && typeof result == "object" && result instanceof Promise) throw new Error("Function unexpectedly returned a Promise");
    return result;
  };
}
var EvalFlags, IntrinsicsFlags, JSPromiseStateEnum, GetOwnPropertyNamesFlags, IsEqualOp;
var init_dist2 = __esm({
  "node_modules/@cf-wasm/quickjs/node_modules/@jitl/quickjs-ffi-types/dist/index.mjs"() {
    EvalFlags = { JS_EVAL_TYPE_GLOBAL: 0, JS_EVAL_TYPE_MODULE: 1, JS_EVAL_TYPE_DIRECT: 2, JS_EVAL_TYPE_INDIRECT: 3, JS_EVAL_TYPE_MASK: 3, JS_EVAL_FLAG_STRICT: 8, JS_EVAL_FLAG_STRIP: 16, JS_EVAL_FLAG_COMPILE_ONLY: 32, JS_EVAL_FLAG_BACKTRACE_BARRIER: 64 };
    IntrinsicsFlags = { BaseObjects: 1, Date: 2, Eval: 4, StringNormalize: 8, RegExp: 16, RegExpCompiler: 32, JSON: 64, Proxy: 128, MapSet: 256, TypedArrays: 512, Promise: 1024, BigInt: 2048, BigFloat: 4096, BigDecimal: 8192, OperatorOverloading: 16384, BignumExt: 32768 };
    JSPromiseStateEnum = { Pending: 0, Fulfilled: 1, Rejected: 2 };
    GetOwnPropertyNamesFlags = { JS_GPN_STRING_MASK: 1, JS_GPN_SYMBOL_MASK: 2, JS_GPN_PRIVATE_MASK: 4, JS_GPN_ENUM_ONLY: 16, JS_GPN_SET_ENUM: 32, QTS_GPN_NUMBER_MASK: 64, QTS_STANDARD_COMPLIANT_NUMBER: 128 };
    IsEqualOp = { IsStrictlyEqual: 0, IsSameValue: 1, IsSameValueZero: 2 };
  }
});

// node_modules/@cf-wasm/quickjs/node_modules/quickjs-emscripten-core/dist/chunk-JTKJZQYV.mjs
function setDebugMode(enabled = true) {
  QTS_DEBUG = enabled;
}
function debugLog(...args) {
  QTS_DEBUG && console.log("quickjs-emscripten:", ...args);
}
function* awaitYield(value) {
  return yield value;
}
function awaitYieldOf(generator) {
  return awaitYield(awaitEachYieldedPromise(generator));
}
function maybeAsyncFn(that, fn) {
  return (...args) => {
    let generator = fn.call(that, AwaitYield, ...args);
    return awaitEachYieldedPromise(generator);
  };
}
function maybeAsync(that, startGenerator) {
  let generator = startGenerator.call(that, AwaitYield);
  return awaitEachYieldedPromise(generator);
}
function awaitEachYieldedPromise(gen) {
  function handleNextStep(step) {
    return step.done ? step.value : step.value instanceof Promise ? step.value.then((value) => handleNextStep(gen.next(value)), (error) => handleNextStep(gen.throw(error))) : handleNextStep(gen.next(step.value));
  }
  return handleNextStep(gen.next());
}
function scopeFinally(scope, blockError) {
  let disposeError;
  try {
    scope.dispose();
  } catch (error) {
    disposeError = error;
  }
  if (blockError && disposeError) throw Object.assign(blockError, { message: `${blockError.message}
 Then, failed to dispose scope: ${disposeError.message}`, disposeError }), blockError;
  if (blockError || disposeError) throw blockError || disposeError;
}
function createDisposableArray(items) {
  let array = items ? Array.from(items) : [];
  function disposeAlive() {
    return array.forEach((disposable) => disposable.alive ? disposable.dispose() : void 0);
  }
  function someIsAlive() {
    return array.some((disposable) => disposable.alive);
  }
  return Object.defineProperty(array, SymbolDispose, { configurable: true, enumerable: false, value: disposeAlive }), Object.defineProperty(array, "dispose", { configurable: true, enumerable: false, value: disposeAlive }), Object.defineProperty(array, "alive", { configurable: true, enumerable: false, get: someIsAlive }), array;
}
function isDisposable(value) {
  return !!(value && (typeof value == "object" || typeof value == "function") && "alive" in value && typeof value.alive == "boolean" && "dispose" in value && typeof value.dispose == "function");
}
function intrinsicsToFlags(intrinsics) {
  if (!intrinsics) return 0;
  let result = 0;
  for (let [maybeIntrinsicName, enabled] of Object.entries(intrinsics)) {
    if (!(maybeIntrinsicName in IntrinsicsFlags)) throw new QuickJSUnknownIntrinsic(maybeIntrinsicName);
    enabled && (result |= IntrinsicsFlags[maybeIntrinsicName]);
  }
  return result;
}
function evalOptionsToFlags(evalOptions) {
  if (typeof evalOptions == "number") return evalOptions;
  if (evalOptions === void 0) return 0;
  let { type, strict, strip, compileOnly, backtraceBarrier } = evalOptions, flags = 0;
  return type === "global" && (flags |= EvalFlags.JS_EVAL_TYPE_GLOBAL), type === "module" && (flags |= EvalFlags.JS_EVAL_TYPE_MODULE), strict && (flags |= EvalFlags.JS_EVAL_FLAG_STRICT), strip && (flags |= EvalFlags.JS_EVAL_FLAG_STRIP), compileOnly && (flags |= EvalFlags.JS_EVAL_FLAG_COMPILE_ONLY), backtraceBarrier && (flags |= EvalFlags.JS_EVAL_FLAG_BACKTRACE_BARRIER), flags;
}
function getOwnPropertyNamesOptionsToFlags(options) {
  if (typeof options == "number") return options;
  if (options === void 0) return 0;
  let { strings: includeStrings, symbols: includeSymbols, quickjsPrivate: includePrivate, onlyEnumerable, numbers: includeNumbers, numbersAsStrings } = options, flags = 0;
  return includeStrings && (flags |= GetOwnPropertyNamesFlags.JS_GPN_STRING_MASK), includeSymbols && (flags |= GetOwnPropertyNamesFlags.JS_GPN_SYMBOL_MASK), includePrivate && (flags |= GetOwnPropertyNamesFlags.JS_GPN_PRIVATE_MASK), onlyEnumerable && (flags |= GetOwnPropertyNamesFlags.JS_GPN_ENUM_ONLY), includeNumbers && (flags |= GetOwnPropertyNamesFlags.QTS_GPN_NUMBER_MASK), numbersAsStrings && (flags |= GetOwnPropertyNamesFlags.QTS_STANDARD_COMPLIANT_NUMBER), flags;
}
function concat(...values) {
  let result = [];
  for (let value of values) value !== void 0 && (result = result.concat(value));
  return result;
}
function applyBaseRuntimeOptions(runtime, options) {
  options.interruptHandler && runtime.setInterruptHandler(options.interruptHandler), options.maxStackSizeBytes !== void 0 && runtime.setMaxStackSize(options.maxStackSizeBytes), options.memoryLimitBytes !== void 0 && runtime.setMemoryLimit(options.memoryLimitBytes);
}
function applyModuleEvalRuntimeOptions(runtime, options) {
  options.moduleLoader && runtime.setModuleLoader(options.moduleLoader), options.shouldInterrupt && runtime.setInterruptHandler(options.shouldInterrupt), options.memoryLimitBytes !== void 0 && runtime.setMemoryLimit(options.memoryLimitBytes), options.maxStackSizeBytes !== void 0 && runtime.setMaxStackSize(options.maxStackSizeBytes);
}
var __defProp3, __export3, QTS_DEBUG, errors_exports, QuickJSUnwrapError, QuickJSWrongOwner, QuickJSUseAfterFree, QuickJSNotImplemented, QuickJSAsyncifyError, QuickJSAsyncifySuspended, QuickJSMemoryLeakDetected, QuickJSEmscriptenModuleError, QuickJSUnknownIntrinsic, QuickJSPromisePending, QuickJSEmptyGetOwnPropertyNames, AwaitYield, UsingDisposable, SymbolDispose, prototypeAsAny, Lifetime, StaticLifetime, WeakLifetime, Scope, AbstractDisposableResult, DisposableSuccess, DisposableFail, DisposableResult, QuickJSDeferredPromise, ModuleMemory, DefaultIntrinsics, QuickJSIterator, ContextMemory, QuickJSContext, QuickJSRuntime, QuickJSEmscriptenModuleCallbacks, QuickJSModuleCallbacks, QuickJSWASMModule;
var init_chunk_JTKJZQYV = __esm({
  "node_modules/@cf-wasm/quickjs/node_modules/quickjs-emscripten-core/dist/chunk-JTKJZQYV.mjs"() {
    init_dist2();
    init_dist2();
    __defProp3 = Object.defineProperty;
    __export3 = (target, all) => {
      for (var name in all) __defProp3(target, name, { get: all[name], enumerable: true });
    };
    QTS_DEBUG = false;
    errors_exports = {};
    __export3(errors_exports, { QuickJSAsyncifyError: () => QuickJSAsyncifyError, QuickJSAsyncifySuspended: () => QuickJSAsyncifySuspended, QuickJSEmptyGetOwnPropertyNames: () => QuickJSEmptyGetOwnPropertyNames, QuickJSEmscriptenModuleError: () => QuickJSEmscriptenModuleError, QuickJSMemoryLeakDetected: () => QuickJSMemoryLeakDetected, QuickJSNotImplemented: () => QuickJSNotImplemented, QuickJSPromisePending: () => QuickJSPromisePending, QuickJSUnknownIntrinsic: () => QuickJSUnknownIntrinsic, QuickJSUnwrapError: () => QuickJSUnwrapError, QuickJSUseAfterFree: () => QuickJSUseAfterFree, QuickJSWrongOwner: () => QuickJSWrongOwner });
    QuickJSUnwrapError = class extends Error {
      constructor(cause, context) {
        let message = typeof cause == "object" && cause && "message" in cause ? String(cause.message) : String(cause);
        super(message);
        this.cause = cause;
        this.context = context;
        this.name = "QuickJSUnwrapError";
      }
    };
    QuickJSWrongOwner = class extends Error {
      constructor() {
        super(...arguments);
        this.name = "QuickJSWrongOwner";
      }
    };
    QuickJSUseAfterFree = class extends Error {
      constructor() {
        super(...arguments);
        this.name = "QuickJSUseAfterFree";
      }
    };
    QuickJSNotImplemented = class extends Error {
      constructor() {
        super(...arguments);
        this.name = "QuickJSNotImplemented";
      }
    };
    QuickJSAsyncifyError = class extends Error {
      constructor() {
        super(...arguments);
        this.name = "QuickJSAsyncifyError";
      }
    };
    QuickJSAsyncifySuspended = class extends Error {
      constructor() {
        super(...arguments);
        this.name = "QuickJSAsyncifySuspended";
      }
    };
    QuickJSMemoryLeakDetected = class extends Error {
      constructor() {
        super(...arguments);
        this.name = "QuickJSMemoryLeakDetected";
      }
    };
    QuickJSEmscriptenModuleError = class extends Error {
      constructor() {
        super(...arguments);
        this.name = "QuickJSEmscriptenModuleError";
      }
    };
    QuickJSUnknownIntrinsic = class extends TypeError {
      constructor() {
        super(...arguments);
        this.name = "QuickJSUnknownIntrinsic";
      }
    };
    QuickJSPromisePending = class extends Error {
      constructor() {
        super(...arguments);
        this.name = "QuickJSPromisePending";
      }
    };
    QuickJSEmptyGetOwnPropertyNames = class extends Error {
      constructor() {
        super(...arguments);
        this.name = "QuickJSEmptyGetOwnPropertyNames";
      }
    };
    AwaitYield = awaitYield;
    AwaitYield.of = awaitYieldOf;
    UsingDisposable = class {
      [Symbol.dispose]() {
        return this.dispose();
      }
    };
    SymbolDispose = Symbol.dispose ?? /* @__PURE__ */ Symbol.for("Symbol.dispose");
    prototypeAsAny = UsingDisposable.prototype;
    prototypeAsAny[SymbolDispose] || (prototypeAsAny[SymbolDispose] = function() {
      return this.dispose();
    });
    Lifetime = class _Lifetime extends UsingDisposable {
      constructor(_value, copier, disposer, _owner) {
        super();
        this._value = _value;
        this.copier = copier;
        this.disposer = disposer;
        this._owner = _owner;
        this._alive = true;
        this._constructorStack = QTS_DEBUG ? new Error("Lifetime constructed").stack : void 0;
      }
      get alive() {
        return this._alive;
      }
      get value() {
        return this.assertAlive(), this._value;
      }
      get owner() {
        return this._owner;
      }
      get dupable() {
        return !!this.copier;
      }
      dup() {
        if (this.assertAlive(), !this.copier) throw new Error("Non-dupable lifetime");
        return new _Lifetime(this.copier(this._value), this.copier, this.disposer, this._owner);
      }
      consume(map) {
        this.assertAlive();
        let result = map(this);
        return this.dispose(), result;
      }
      map(map) {
        return this.assertAlive(), map(this);
      }
      tap(fn) {
        return fn(this), this;
      }
      dispose() {
        this.assertAlive(), this.disposer && this.disposer(this._value), this._alive = false;
      }
      assertAlive() {
        if (!this.alive) throw this._constructorStack ? new QuickJSUseAfterFree(`Lifetime not alive
${this._constructorStack}
Lifetime used`) : new QuickJSUseAfterFree("Lifetime not alive");
      }
    };
    StaticLifetime = class extends Lifetime {
      constructor(value, owner) {
        super(value, void 0, void 0, owner);
      }
      get dupable() {
        return true;
      }
      dup() {
        return this;
      }
      dispose() {
      }
    };
    WeakLifetime = class extends Lifetime {
      constructor(value, copier, disposer, owner) {
        super(value, copier, disposer, owner);
      }
      dispose() {
        this._alive = false;
      }
    };
    Scope = class _Scope extends UsingDisposable {
      constructor() {
        super(...arguments);
        this._disposables = new Lifetime(/* @__PURE__ */ new Set());
        this.manage = (lifetime) => (this._disposables.value.add(lifetime), lifetime);
      }
      static withScope(block) {
        let scope = new _Scope(), blockError;
        try {
          return block(scope);
        } catch (error) {
          throw blockError = error, error;
        } finally {
          scopeFinally(scope, blockError);
        }
      }
      static withScopeMaybeAsync(_this, block) {
        return maybeAsync(void 0, function* (awaited) {
          let scope = new _Scope(), blockError;
          try {
            return yield* awaited.of(block.call(_this, awaited, scope));
          } catch (error) {
            throw blockError = error, error;
          } finally {
            scopeFinally(scope, blockError);
          }
        });
      }
      static async withScopeAsync(block) {
        let scope = new _Scope(), blockError;
        try {
          return await block(scope);
        } catch (error) {
          throw blockError = error, error;
        } finally {
          scopeFinally(scope, blockError);
        }
      }
      get alive() {
        return this._disposables.alive;
      }
      dispose() {
        let lifetimes = Array.from(this._disposables.value.values()).reverse();
        for (let lifetime of lifetimes) lifetime.alive && lifetime.dispose();
        this._disposables.dispose();
      }
    };
    AbstractDisposableResult = class _AbstractDisposableResult extends UsingDisposable {
      static success(value) {
        return new DisposableSuccess(value);
      }
      static fail(error, onUnwrap) {
        return new DisposableFail(error, onUnwrap);
      }
      static is(result) {
        return result instanceof _AbstractDisposableResult;
      }
    };
    DisposableSuccess = class extends AbstractDisposableResult {
      constructor(value) {
        super();
        this.value = value;
      }
      get alive() {
        return isDisposable(this.value) ? this.value.alive : true;
      }
      dispose() {
        isDisposable(this.value) && this.value.dispose();
      }
      unwrap() {
        return this.value;
      }
      unwrapOr(_fallback) {
        return this.value;
      }
    };
    DisposableFail = class extends AbstractDisposableResult {
      constructor(error, onUnwrap) {
        super();
        this.error = error;
        this.onUnwrap = onUnwrap;
      }
      get alive() {
        return isDisposable(this.error) ? this.error.alive : true;
      }
      dispose() {
        isDisposable(this.error) && this.error.dispose();
      }
      unwrap() {
        throw this.onUnwrap(this), this.error;
      }
      unwrapOr(fallback) {
        return fallback;
      }
    };
    DisposableResult = AbstractDisposableResult;
    QuickJSDeferredPromise = class extends UsingDisposable {
      constructor(args) {
        super();
        this.resolve = (value) => {
          this.resolveHandle.alive && (this.context.unwrapResult(this.context.callFunction(this.resolveHandle, this.context.undefined, value || this.context.undefined)).dispose(), this.disposeResolvers(), this.onSettled());
        };
        this.reject = (value) => {
          this.rejectHandle.alive && (this.context.unwrapResult(this.context.callFunction(this.rejectHandle, this.context.undefined, value || this.context.undefined)).dispose(), this.disposeResolvers(), this.onSettled());
        };
        this.dispose = () => {
          this.handle.alive && this.handle.dispose(), this.disposeResolvers();
        };
        this.context = args.context, this.owner = args.context.runtime, this.handle = args.promiseHandle, this.settled = new Promise((resolve) => {
          this.onSettled = resolve;
        }), this.resolveHandle = args.resolveHandle, this.rejectHandle = args.rejectHandle;
      }
      get alive() {
        return this.handle.alive || this.resolveHandle.alive || this.rejectHandle.alive;
      }
      disposeResolvers() {
        this.resolveHandle.alive && this.resolveHandle.dispose(), this.rejectHandle.alive && this.rejectHandle.dispose();
      }
    };
    ModuleMemory = class {
      constructor(module) {
        this.module = module;
      }
      toPointerArray(handleArray) {
        let typedArray = new Int32Array(handleArray.map((handle) => handle.value)), numBytes = typedArray.length * typedArray.BYTES_PER_ELEMENT, ptr = this.module._malloc(numBytes);
        return new Uint8Array(this.module.HEAPU8.buffer, ptr, numBytes).set(new Uint8Array(typedArray.buffer)), new Lifetime(ptr, void 0, (ptr2) => this.module._free(ptr2));
      }
      newTypedArray(kind, length) {
        let zeros = new kind(new Array(length).fill(0)), numBytes = zeros.length * zeros.BYTES_PER_ELEMENT, ptr = this.module._malloc(numBytes), typedArray = new kind(this.module.HEAPU8.buffer, ptr, length);
        return typedArray.set(zeros), new Lifetime({ typedArray, ptr }, void 0, (value) => this.module._free(value.ptr));
      }
      newMutablePointerArray(length) {
        return this.newTypedArray(Int32Array, length);
      }
      newHeapCharPointer(string) {
        let strlen = this.module.lengthBytesUTF8(string), dataBytes = strlen + 1, ptr = this.module._malloc(dataBytes);
        return this.module.stringToUTF8(string, ptr, dataBytes), new Lifetime({ ptr, strlen }, void 0, (value) => this.module._free(value.ptr));
      }
      newHeapBufferPointer(buffer) {
        let numBytes = buffer.byteLength, ptr = this.module._malloc(numBytes);
        return this.module.HEAPU8.set(buffer, ptr), new Lifetime({ pointer: ptr, numBytes }, void 0, (value) => this.module._free(value.pointer));
      }
      consumeHeapCharPointer(ptr) {
        let str = this.module.UTF8ToString(ptr);
        return this.module._free(ptr), str;
      }
    };
    DefaultIntrinsics = Object.freeze({ BaseObjects: true, Date: true, Eval: true, StringNormalize: true, RegExp: true, JSON: true, Proxy: true, MapSet: true, TypedArrays: true, Promise: true });
    QuickJSIterator = class extends UsingDisposable {
      constructor(handle, context) {
        super();
        this.handle = handle;
        this.context = context;
        this._isDone = false;
        this.owner = context.runtime;
      }
      [Symbol.iterator]() {
        return this;
      }
      next(value) {
        if (!this.alive || this._isDone) return { done: true, value: void 0 };
        let nextMethod = this._next ?? (this._next = this.context.getProp(this.handle, "next"));
        return this.callIteratorMethod(nextMethod, value);
      }
      return(value) {
        if (!this.alive) return { done: true, value: void 0 };
        let returnMethod = this.context.getProp(this.handle, "return");
        if (returnMethod === this.context.undefined && value === void 0) return this.dispose(), { done: true, value: void 0 };
        let result = this.callIteratorMethod(returnMethod, value);
        return returnMethod.dispose(), this.dispose(), result;
      }
      throw(e) {
        if (!this.alive) return { done: true, value: void 0 };
        let errorHandle = e instanceof Lifetime ? e : this.context.newError(e), throwMethod = this.context.getProp(this.handle, "throw"), result = this.callIteratorMethod(throwMethod, e);
        return errorHandle.alive && errorHandle.dispose(), throwMethod.dispose(), this.dispose(), result;
      }
      get alive() {
        return this.handle.alive;
      }
      dispose() {
        this._isDone = true, this.handle.dispose(), this._next?.dispose();
      }
      callIteratorMethod(method, input) {
        let callResult = input ? this.context.callFunction(method, this.handle, input) : this.context.callFunction(method, this.handle);
        if (callResult.error) return this.dispose(), { value: callResult };
        let done = this.context.getProp(callResult.value, "done").consume((v) => this.context.dump(v));
        if (done) return callResult.value.dispose(), this.dispose(), { done, value: void 0 };
        let value = this.context.getProp(callResult.value, "value");
        return callResult.value.dispose(), { value: DisposableResult.success(value), done };
      }
    };
    ContextMemory = class extends ModuleMemory {
      constructor(args) {
        super(args.module);
        this.scope = new Scope();
        this.copyJSValue = (ptr) => this.ffi.QTS_DupValuePointer(this.ctx.value, ptr);
        this.freeJSValue = (ptr) => {
          this.ffi.QTS_FreeValuePointer(this.ctx.value, ptr);
        };
        args.ownedLifetimes?.forEach((lifetime) => this.scope.manage(lifetime)), this.owner = args.owner, this.module = args.module, this.ffi = args.ffi, this.rt = args.rt, this.ctx = this.scope.manage(args.ctx);
      }
      get alive() {
        return this.scope.alive;
      }
      dispose() {
        return this.scope.dispose();
      }
      [Symbol.dispose]() {
        return this.dispose();
      }
      manage(lifetime) {
        return this.scope.manage(lifetime);
      }
      consumeJSCharPointer(ptr) {
        let str = this.module.UTF8ToString(ptr);
        return this.ffi.QTS_FreeCString(this.ctx.value, ptr), str;
      }
      heapValueHandle(ptr) {
        return new Lifetime(ptr, this.copyJSValue, this.freeJSValue, this.owner);
      }
      staticHeapValueHandle(ptr) {
        return this.manage(this.heapValueHandle(ptr)), new StaticLifetime(ptr, this.owner);
      }
    };
    QuickJSContext = class extends UsingDisposable {
      constructor(args) {
        super();
        this._undefined = void 0;
        this._null = void 0;
        this._false = void 0;
        this._true = void 0;
        this._global = void 0;
        this._BigInt = void 0;
        this._Symbol = void 0;
        this._SymbolIterator = void 0;
        this._SymbolAsyncIterator = void 0;
        this.fnNextId = -32768;
        this.fnMaps = /* @__PURE__ */ new Map();
        this.cToHostCallbacks = { callFunction: (ctx, this_ptr, argc, argv, fn_id) => {
          if (ctx !== this.ctx.value) throw new Error("QuickJSContext instance received C -> JS call with mismatched ctx");
          let fn = this.getFunction(fn_id);
          if (!fn) throw new Error(`QuickJSContext had no callback with id ${fn_id}`);
          return Scope.withScopeMaybeAsync(this, function* (awaited, scope) {
            let thisHandle = scope.manage(new WeakLifetime(this_ptr, this.memory.copyJSValue, this.memory.freeJSValue, this.runtime)), argHandles = new Array(argc);
            for (let i = 0; i < argc; i++) {
              let ptr = this.ffi.QTS_ArgvGetJSValueConstPointer(argv, i);
              argHandles[i] = scope.manage(new WeakLifetime(ptr, this.memory.copyJSValue, this.memory.freeJSValue, this.runtime));
            }
            try {
              let result = yield* awaited(fn.apply(thisHandle, argHandles));
              if (result) {
                if ("error" in result && result.error) throw this.runtime.debugLog("throw error", result.error), result.error;
                let handle = scope.manage(result instanceof Lifetime ? result : result.value);
                return this.ffi.QTS_DupValuePointer(this.ctx.value, handle.value);
              }
              return 0;
            } catch (error) {
              return this.errorToHandle(error).consume((errorHandle) => this.ffi.QTS_Throw(this.ctx.value, errorHandle.value));
            }
          });
        } };
        this.runtime = args.runtime, this.module = args.module, this.ffi = args.ffi, this.rt = args.rt, this.ctx = args.ctx, this.memory = new ContextMemory({ ...args, owner: this.runtime }), args.callbacks.setContextCallbacks(this.ctx.value, this.cToHostCallbacks), this.dump = this.dump.bind(this), this.getString = this.getString.bind(this), this.getNumber = this.getNumber.bind(this), this.resolvePromise = this.resolvePromise.bind(this), this.uint32Out = this.memory.manage(this.memory.newTypedArray(Uint32Array, 1));
      }
      get alive() {
        return this.memory.alive;
      }
      dispose() {
        this.memory.dispose();
      }
      get undefined() {
        if (this._undefined) return this._undefined;
        let ptr = this.ffi.QTS_GetUndefined();
        return this._undefined = new StaticLifetime(ptr);
      }
      get null() {
        if (this._null) return this._null;
        let ptr = this.ffi.QTS_GetNull();
        return this._null = new StaticLifetime(ptr);
      }
      get true() {
        if (this._true) return this._true;
        let ptr = this.ffi.QTS_GetTrue();
        return this._true = new StaticLifetime(ptr);
      }
      get false() {
        if (this._false) return this._false;
        let ptr = this.ffi.QTS_GetFalse();
        return this._false = new StaticLifetime(ptr);
      }
      get global() {
        if (this._global) return this._global;
        let ptr = this.ffi.QTS_GetGlobalObject(this.ctx.value);
        return this._global = this.memory.staticHeapValueHandle(ptr), this._global;
      }
      newNumber(num) {
        return this.memory.heapValueHandle(this.ffi.QTS_NewFloat64(this.ctx.value, num));
      }
      newString(str) {
        let ptr = this.memory.newHeapCharPointer(str).consume((charHandle) => this.ffi.QTS_NewString(this.ctx.value, charHandle.value.ptr));
        return this.memory.heapValueHandle(ptr);
      }
      newUniqueSymbol(description) {
        let key = (typeof description == "symbol" ? description.description : description) ?? "", ptr = this.memory.newHeapCharPointer(key).consume((charHandle) => this.ffi.QTS_NewSymbol(this.ctx.value, charHandle.value.ptr, 0));
        return this.memory.heapValueHandle(ptr);
      }
      newSymbolFor(key) {
        let description = (typeof key == "symbol" ? key.description : key) ?? "", ptr = this.memory.newHeapCharPointer(description).consume((charHandle) => this.ffi.QTS_NewSymbol(this.ctx.value, charHandle.value.ptr, 1));
        return this.memory.heapValueHandle(ptr);
      }
      getWellKnownSymbol(name) {
        return this._Symbol ?? (this._Symbol = this.memory.manage(this.getProp(this.global, "Symbol"))), this.getProp(this._Symbol, name);
      }
      newBigInt(num) {
        if (!this._BigInt) {
          let bigIntHandle2 = this.getProp(this.global, "BigInt");
          this.memory.manage(bigIntHandle2), this._BigInt = new StaticLifetime(bigIntHandle2.value, this.runtime);
        }
        let bigIntHandle = this._BigInt, asString = String(num);
        return this.newString(asString).consume((handle) => this.unwrapResult(this.callFunction(bigIntHandle, this.undefined, handle)));
      }
      newObject(prototype) {
        prototype && this.runtime.assertOwned(prototype);
        let ptr = prototype ? this.ffi.QTS_NewObjectProto(this.ctx.value, prototype.value) : this.ffi.QTS_NewObject(this.ctx.value);
        return this.memory.heapValueHandle(ptr);
      }
      newArray() {
        let ptr = this.ffi.QTS_NewArray(this.ctx.value);
        return this.memory.heapValueHandle(ptr);
      }
      newArrayBuffer(buffer) {
        let array = new Uint8Array(buffer), handle = this.memory.newHeapBufferPointer(array), ptr = this.ffi.QTS_NewArrayBuffer(this.ctx.value, handle.value.pointer, array.length);
        return this.memory.heapValueHandle(ptr);
      }
      newPromise(value) {
        let deferredPromise = Scope.withScope((scope) => {
          let mutablePointerArray = scope.manage(this.memory.newMutablePointerArray(2)), promisePtr = this.ffi.QTS_NewPromiseCapability(this.ctx.value, mutablePointerArray.value.ptr), promiseHandle = this.memory.heapValueHandle(promisePtr), [resolveHandle, rejectHandle] = Array.from(mutablePointerArray.value.typedArray).map((jsvaluePtr) => this.memory.heapValueHandle(jsvaluePtr));
          return new QuickJSDeferredPromise({ context: this, promiseHandle, resolveHandle, rejectHandle });
        });
        return value && typeof value == "function" && (value = new Promise(value)), value && Promise.resolve(value).then(deferredPromise.resolve, (error) => error instanceof Lifetime ? deferredPromise.reject(error) : this.newError(error).consume(deferredPromise.reject)), deferredPromise;
      }
      newFunction(name, fn) {
        let fnId = ++this.fnNextId;
        return this.setFunction(fnId, fn), this.memory.heapValueHandle(this.ffi.QTS_NewFunction(this.ctx.value, fnId, name));
      }
      newError(error) {
        let errorHandle = this.memory.heapValueHandle(this.ffi.QTS_NewError(this.ctx.value));
        return error && typeof error == "object" ? (error.name !== void 0 && this.newString(error.name).consume((handle) => this.setProp(errorHandle, "name", handle)), error.message !== void 0 && this.newString(error.message).consume((handle) => this.setProp(errorHandle, "message", handle))) : typeof error == "string" ? this.newString(error).consume((handle) => this.setProp(errorHandle, "message", handle)) : error !== void 0 && this.newString(String(error)).consume((handle) => this.setProp(errorHandle, "message", handle)), errorHandle;
      }
      typeof(handle) {
        return this.runtime.assertOwned(handle), this.memory.consumeHeapCharPointer(this.ffi.QTS_Typeof(this.ctx.value, handle.value));
      }
      getNumber(handle) {
        return this.runtime.assertOwned(handle), this.ffi.QTS_GetFloat64(this.ctx.value, handle.value);
      }
      getString(handle) {
        return this.runtime.assertOwned(handle), this.memory.consumeJSCharPointer(this.ffi.QTS_GetString(this.ctx.value, handle.value));
      }
      getSymbol(handle) {
        this.runtime.assertOwned(handle);
        let key = this.memory.consumeJSCharPointer(this.ffi.QTS_GetSymbolDescriptionOrKey(this.ctx.value, handle.value));
        return this.ffi.QTS_IsGlobalSymbol(this.ctx.value, handle.value) ? Symbol.for(key) : Symbol(key);
      }
      getBigInt(handle) {
        this.runtime.assertOwned(handle);
        let asString = this.getString(handle);
        return BigInt(asString);
      }
      getArrayBuffer(handle) {
        this.runtime.assertOwned(handle);
        let len = this.ffi.QTS_GetArrayBufferLength(this.ctx.value, handle.value), ptr = this.ffi.QTS_GetArrayBuffer(this.ctx.value, handle.value);
        if (!ptr) throw new Error("Couldn't allocate memory to get ArrayBuffer");
        return new Lifetime(this.module.HEAPU8.subarray(ptr, ptr + len), void 0, () => this.module._free(ptr));
      }
      getPromiseState(handle) {
        this.runtime.assertOwned(handle);
        let state = this.ffi.QTS_PromiseState(this.ctx.value, handle.value);
        if (state < 0) return { type: "fulfilled", value: handle, notAPromise: true };
        if (state === JSPromiseStateEnum.Pending) return { type: "pending", get error() {
          return new QuickJSPromisePending("Cannot unwrap a pending promise");
        } };
        let ptr = this.ffi.QTS_PromiseResult(this.ctx.value, handle.value), result = this.memory.heapValueHandle(ptr);
        if (state === JSPromiseStateEnum.Fulfilled) return { type: "fulfilled", value: result };
        if (state === JSPromiseStateEnum.Rejected) return { type: "rejected", error: result };
        throw result.dispose(), new Error(`Unknown JSPromiseStateEnum: ${state}`);
      }
      resolvePromise(promiseLikeHandle) {
        this.runtime.assertOwned(promiseLikeHandle);
        let vmResolveResult = Scope.withScope((scope) => {
          let vmPromise = scope.manage(this.getProp(this.global, "Promise")), vmPromiseResolve = scope.manage(this.getProp(vmPromise, "resolve"));
          return this.callFunction(vmPromiseResolve, vmPromise, promiseLikeHandle);
        });
        return vmResolveResult.error ? Promise.resolve(vmResolveResult) : new Promise((resolve) => {
          Scope.withScope((scope) => {
            let resolveHandle = scope.manage(this.newFunction("resolve", (value) => {
              resolve(this.success(value && value.dup()));
            })), rejectHandle = scope.manage(this.newFunction("reject", (error) => {
              resolve(this.fail(error && error.dup()));
            })), promiseHandle = scope.manage(vmResolveResult.value), promiseThenHandle = scope.manage(this.getProp(promiseHandle, "then"));
            this.callFunction(promiseThenHandle, promiseHandle, resolveHandle, rejectHandle).unwrap().dispose();
          });
        });
      }
      isEqual(a, b, equalityType = IsEqualOp.IsStrictlyEqual) {
        if (a === b) return true;
        this.runtime.assertOwned(a), this.runtime.assertOwned(b);
        let result = this.ffi.QTS_IsEqual(this.ctx.value, a.value, b.value, equalityType);
        if (result === -1) throw new QuickJSNotImplemented("WASM variant does not expose equality");
        return !!result;
      }
      eq(handle, other) {
        return this.isEqual(handle, other, IsEqualOp.IsStrictlyEqual);
      }
      sameValue(handle, other) {
        return this.isEqual(handle, other, IsEqualOp.IsSameValue);
      }
      sameValueZero(handle, other) {
        return this.isEqual(handle, other, IsEqualOp.IsSameValueZero);
      }
      getProp(handle, key) {
        this.runtime.assertOwned(handle);
        let ptr;
        return typeof key == "number" && key >= 0 ? ptr = this.ffi.QTS_GetPropNumber(this.ctx.value, handle.value, key) : ptr = this.borrowPropertyKey(key).consume((quickJSKey) => this.ffi.QTS_GetProp(this.ctx.value, handle.value, quickJSKey.value)), this.memory.heapValueHandle(ptr);
      }
      getLength(handle) {
        if (this.runtime.assertOwned(handle), !(this.ffi.QTS_GetLength(this.ctx.value, this.uint32Out.value.ptr, handle.value) < 0)) return this.uint32Out.value.typedArray[0];
      }
      getOwnPropertyNames(handle, options = { strings: true, numbersAsStrings: true }) {
        this.runtime.assertOwned(handle), handle.value;
        let flags = getOwnPropertyNamesOptionsToFlags(options);
        if (flags === 0) throw new QuickJSEmptyGetOwnPropertyNames("No options set, will return an empty array");
        return Scope.withScope((scope) => {
          let outPtr = scope.manage(this.memory.newMutablePointerArray(1)), errorPtr = this.ffi.QTS_GetOwnPropertyNames(this.ctx.value, outPtr.value.ptr, this.uint32Out.value.ptr, handle.value, flags);
          if (errorPtr) return this.fail(this.memory.heapValueHandle(errorPtr));
          let len = this.uint32Out.value.typedArray[0], ptr = outPtr.value.typedArray[0], pointerArray = new Uint32Array(this.module.HEAP8.buffer, ptr, len), handles = Array.from(pointerArray).map((ptr2) => this.memory.heapValueHandle(ptr2));
          return this.ffi.QTS_FreeVoidPointer(this.ctx.value, ptr), this.success(createDisposableArray(handles));
        });
      }
      getIterator(iterableHandle) {
        let SymbolIterator = this._SymbolIterator ?? (this._SymbolIterator = this.memory.manage(this.getWellKnownSymbol("iterator")));
        return Scope.withScope((scope) => {
          let methodHandle = scope.manage(this.getProp(iterableHandle, SymbolIterator)), iteratorCallResult = this.callFunction(methodHandle, iterableHandle);
          return iteratorCallResult.error ? iteratorCallResult : this.success(new QuickJSIterator(iteratorCallResult.value, this));
        });
      }
      setProp(handle, key, value) {
        this.runtime.assertOwned(handle), this.borrowPropertyKey(key).consume((quickJSKey) => this.ffi.QTS_SetProp(this.ctx.value, handle.value, quickJSKey.value, value.value));
      }
      defineProp(handle, key, descriptor) {
        this.runtime.assertOwned(handle), Scope.withScope((scope) => {
          let quickJSKey = scope.manage(this.borrowPropertyKey(key)), value = descriptor.value || this.undefined, configurable = !!descriptor.configurable, enumerable = !!descriptor.enumerable, hasValue = !!descriptor.value, get = descriptor.get ? scope.manage(this.newFunction(descriptor.get.name, descriptor.get)) : this.undefined, set = descriptor.set ? scope.manage(this.newFunction(descriptor.set.name, descriptor.set)) : this.undefined;
          this.ffi.QTS_DefineProp(this.ctx.value, handle.value, quickJSKey.value, value.value, get.value, set.value, configurable, enumerable, hasValue);
        });
      }
      callFunction(func, thisVal, ...restArgs) {
        this.runtime.assertOwned(func);
        let args, firstArg = restArgs[0];
        firstArg === void 0 || Array.isArray(firstArg) ? args = firstArg ?? [] : args = restArgs;
        let resultPtr = this.memory.toPointerArray(args).consume((argsArrayPtr) => this.ffi.QTS_Call(this.ctx.value, func.value, thisVal.value, args.length, argsArrayPtr.value)), errorPtr = this.ffi.QTS_ResolveException(this.ctx.value, resultPtr);
        return errorPtr ? (this.ffi.QTS_FreeValuePointer(this.ctx.value, resultPtr), this.fail(this.memory.heapValueHandle(errorPtr))) : this.success(this.memory.heapValueHandle(resultPtr));
      }
      callMethod(thisHandle, key, args = []) {
        return this.getProp(thisHandle, key).consume((func) => this.callFunction(func, thisHandle, args));
      }
      evalCode(code, filename = "eval.js", options) {
        let detectModule = options === void 0 ? 1 : 0, flags = evalOptionsToFlags(options), resultPtr = this.memory.newHeapCharPointer(code).consume((charHandle) => this.ffi.QTS_Eval(this.ctx.value, charHandle.value.ptr, charHandle.value.strlen, filename, detectModule, flags)), errorPtr = this.ffi.QTS_ResolveException(this.ctx.value, resultPtr);
        return errorPtr ? (this.ffi.QTS_FreeValuePointer(this.ctx.value, resultPtr), this.fail(this.memory.heapValueHandle(errorPtr))) : this.success(this.memory.heapValueHandle(resultPtr));
      }
      throw(error) {
        return this.errorToHandle(error).consume((handle) => this.ffi.QTS_Throw(this.ctx.value, handle.value));
      }
      borrowPropertyKey(key) {
        return typeof key == "number" ? this.newNumber(key) : typeof key == "string" ? this.newString(key) : new StaticLifetime(key.value, this.runtime);
      }
      getMemory(rt) {
        if (rt === this.rt.value) return this.memory;
        throw new Error("Private API. Cannot get memory from a different runtime");
      }
      dump(handle) {
        this.runtime.assertOwned(handle);
        let type = this.typeof(handle);
        if (type === "string") return this.getString(handle);
        if (type === "number") return this.getNumber(handle);
        if (type === "bigint") return this.getBigInt(handle);
        if (type === "undefined") return;
        if (type === "symbol") return this.getSymbol(handle);
        let asPromiseState = this.getPromiseState(handle);
        if (asPromiseState.type === "fulfilled" && !asPromiseState.notAPromise) return handle.dispose(), { type: asPromiseState.type, value: asPromiseState.value.consume(this.dump) };
        if (asPromiseState.type === "pending") return handle.dispose(), { type: asPromiseState.type };
        if (asPromiseState.type === "rejected") return handle.dispose(), { type: asPromiseState.type, error: asPromiseState.error.consume(this.dump) };
        let str = this.memory.consumeJSCharPointer(this.ffi.QTS_Dump(this.ctx.value, handle.value));
        try {
          return JSON.parse(str);
        } catch {
          return str;
        }
      }
      unwrapResult(result) {
        if (result.error) {
          let context = "context" in result.error ? result.error.context : this, cause = result.error.consume((error) => this.dump(error));
          if (cause && typeof cause == "object" && typeof cause.message == "string") {
            let { message, name, stack, ...rest } = cause, exception = new QuickJSUnwrapError(cause, context);
            typeof name == "string" && (exception.name = cause.name), exception.message = message;
            let hostStack = exception.stack;
            throw typeof stack == "string" && (exception.stack = `${name}: ${message}
${cause.stack}Host: ${hostStack}`), Object.assign(exception, rest), exception;
          }
          throw new QuickJSUnwrapError(cause);
        }
        return result.value;
      }
      [/* @__PURE__ */ Symbol.for("nodejs.util.inspect.custom")]() {
        return this.alive ? `${this.constructor.name} { ctx: ${this.ctx.value} rt: ${this.rt.value} }` : `${this.constructor.name} { disposed }`;
      }
      getFunction(fn_id) {
        let map_id = fn_id >> 8, fnMap = this.fnMaps.get(map_id);
        if (fnMap) return fnMap.get(fn_id);
      }
      setFunction(fn_id, handle) {
        let map_id = fn_id >> 8, fnMap = this.fnMaps.get(map_id);
        return fnMap || (fnMap = /* @__PURE__ */ new Map(), this.fnMaps.set(map_id, fnMap)), fnMap.set(fn_id, handle);
      }
      errorToHandle(error) {
        return error instanceof Lifetime ? error : this.newError(error);
      }
      encodeBinaryJSON(handle) {
        let ptr = this.ffi.QTS_bjson_encode(this.ctx.value, handle.value);
        return this.memory.heapValueHandle(ptr);
      }
      decodeBinaryJSON(handle) {
        let ptr = this.ffi.QTS_bjson_decode(this.ctx.value, handle.value);
        return this.memory.heapValueHandle(ptr);
      }
      success(value) {
        return DisposableResult.success(value);
      }
      fail(error) {
        return DisposableResult.fail(error, (error2) => this.unwrapResult(error2));
      }
    };
    QuickJSRuntime = class extends UsingDisposable {
      constructor(args) {
        super();
        this.scope = new Scope();
        this.contextMap = /* @__PURE__ */ new Map();
        this._debugMode = false;
        this.cToHostCallbacks = { shouldInterrupt: (rt) => {
          if (rt !== this.rt.value) throw new Error("QuickJSContext instance received C -> JS interrupt with mismatched rt");
          let fn = this.interruptHandler;
          if (!fn) throw new Error("QuickJSContext had no interrupt handler");
          return fn(this) ? 1 : 0;
        }, loadModuleSource: maybeAsyncFn(this, function* (awaited, rt, ctx, moduleName) {
          let moduleLoader = this.moduleLoader;
          if (!moduleLoader) throw new Error("Runtime has no module loader");
          if (rt !== this.rt.value) throw new Error("Runtime pointer mismatch");
          let context = this.contextMap.get(ctx) ?? this.newContext({ contextPointer: ctx });
          try {
            let result = yield* awaited(moduleLoader(moduleName, context));
            if (typeof result == "object" && "error" in result && result.error) throw this.debugLog("cToHostLoadModule: loader returned error", result.error), result.error;
            let moduleSource = typeof result == "string" ? result : "value" in result ? result.value : result;
            return this.memory.newHeapCharPointer(moduleSource).value.ptr;
          } catch (error) {
            return this.debugLog("cToHostLoadModule: caught error", error), context.throw(error), 0;
          }
        }), normalizeModule: maybeAsyncFn(this, function* (awaited, rt, ctx, baseModuleName, moduleNameRequest) {
          let moduleNormalizer = this.moduleNormalizer;
          if (!moduleNormalizer) throw new Error("Runtime has no module normalizer");
          if (rt !== this.rt.value) throw new Error("Runtime pointer mismatch");
          let context = this.contextMap.get(ctx) ?? this.newContext({ contextPointer: ctx });
          try {
            let result = yield* awaited(moduleNormalizer(baseModuleName, moduleNameRequest, context));
            if (typeof result == "object" && "error" in result && result.error) throw this.debugLog("cToHostNormalizeModule: normalizer returned error", result.error), result.error;
            let name = typeof result == "string" ? result : result.value;
            return context.getMemory(this.rt.value).newHeapCharPointer(name).value.ptr;
          } catch (error) {
            return this.debugLog("normalizeModule: caught error", error), context.throw(error), 0;
          }
        }) };
        args.ownedLifetimes?.forEach((lifetime) => this.scope.manage(lifetime)), this.module = args.module, this.memory = new ModuleMemory(this.module), this.ffi = args.ffi, this.rt = args.rt, this.callbacks = args.callbacks, this.scope.manage(this.rt), this.callbacks.setRuntimeCallbacks(this.rt.value, this.cToHostCallbacks), this.executePendingJobs = this.executePendingJobs.bind(this), QTS_DEBUG && this.setDebugMode(true);
      }
      get alive() {
        return this.scope.alive;
      }
      dispose() {
        return this.scope.dispose();
      }
      newContext(options = {}) {
        let intrinsics = intrinsicsToFlags(options.intrinsics), ctx = new Lifetime(options.contextPointer || this.ffi.QTS_NewContext(this.rt.value, intrinsics), void 0, (ctx_ptr) => {
          this.contextMap.delete(ctx_ptr), this.callbacks.deleteContext(ctx_ptr), this.ffi.QTS_FreeContext(ctx_ptr);
        }), context = new QuickJSContext({ module: this.module, ctx, ffi: this.ffi, rt: this.rt, ownedLifetimes: options.ownedLifetimes, runtime: this, callbacks: this.callbacks });
        return this.contextMap.set(ctx.value, context), context;
      }
      setModuleLoader(moduleLoader, moduleNormalizer) {
        this.moduleLoader = moduleLoader, this.moduleNormalizer = moduleNormalizer, this.ffi.QTS_RuntimeEnableModuleLoader(this.rt.value, this.moduleNormalizer ? 1 : 0);
      }
      removeModuleLoader() {
        this.moduleLoader = void 0, this.ffi.QTS_RuntimeDisableModuleLoader(this.rt.value);
      }
      hasPendingJob() {
        return !!this.ffi.QTS_IsJobPending(this.rt.value);
      }
      setInterruptHandler(cb) {
        let prevInterruptHandler = this.interruptHandler;
        this.interruptHandler = cb, prevInterruptHandler || this.ffi.QTS_RuntimeEnableInterruptHandler(this.rt.value);
      }
      removeInterruptHandler() {
        this.interruptHandler && (this.ffi.QTS_RuntimeDisableInterruptHandler(this.rt.value), this.interruptHandler = void 0);
      }
      executePendingJobs(maxJobsToExecute = -1) {
        let ctxPtrOut = this.memory.newMutablePointerArray(1), valuePtr = this.ffi.QTS_ExecutePendingJob(this.rt.value, maxJobsToExecute ?? -1, ctxPtrOut.value.ptr), ctxPtr = ctxPtrOut.value.typedArray[0];
        if (ctxPtrOut.dispose(), ctxPtr === 0) return this.ffi.QTS_FreeValuePointerRuntime(this.rt.value, valuePtr), DisposableResult.success(0);
        let context = this.contextMap.get(ctxPtr) ?? this.newContext({ contextPointer: ctxPtr }), resultValue = context.getMemory(this.rt.value).heapValueHandle(valuePtr);
        if (context.typeof(resultValue) === "number") {
          let executedJobs = context.getNumber(resultValue);
          return resultValue.dispose(), DisposableResult.success(executedJobs);
        } else {
          let error = Object.assign(resultValue, { context });
          return DisposableResult.fail(error, (error2) => context.unwrapResult(error2));
        }
      }
      setMemoryLimit(limitBytes) {
        if (limitBytes < 0 && limitBytes !== -1) throw new Error("Cannot set memory limit to negative number. To unset, pass -1");
        this.ffi.QTS_RuntimeSetMemoryLimit(this.rt.value, limitBytes);
      }
      computeMemoryUsage() {
        let serviceContextMemory = this.getSystemContext().getMemory(this.rt.value);
        return serviceContextMemory.heapValueHandle(this.ffi.QTS_RuntimeComputeMemoryUsage(this.rt.value, serviceContextMemory.ctx.value));
      }
      dumpMemoryUsage() {
        return this.memory.consumeHeapCharPointer(this.ffi.QTS_RuntimeDumpMemoryUsage(this.rt.value));
      }
      setMaxStackSize(stackSize) {
        if (stackSize < 0) throw new Error("Cannot set memory limit to negative number. To unset, pass 0.");
        this.ffi.QTS_RuntimeSetMaxStackSize(this.rt.value, stackSize);
      }
      assertOwned(handle) {
        if (handle.owner && handle.owner.rt !== this.rt) throw new QuickJSWrongOwner(`Handle is not owned by this runtime: ${handle.owner.rt.value} != ${this.rt.value}`);
      }
      setDebugMode(enabled) {
        this._debugMode = enabled, this.ffi.DEBUG && this.rt.alive && this.ffi.QTS_SetDebugLogEnabled(this.rt.value, enabled ? 1 : 0);
      }
      isDebugMode() {
        return this._debugMode;
      }
      debugLog(...msg) {
        this._debugMode && console.log("quickjs-emscripten:", ...msg);
      }
      [/* @__PURE__ */ Symbol.for("nodejs.util.inspect.custom")]() {
        return this.alive ? `${this.constructor.name} { rt: ${this.rt.value} }` : `${this.constructor.name} { disposed }`;
      }
      getSystemContext() {
        return this.context || (this.context = this.scope.manage(this.newContext())), this.context;
      }
    };
    QuickJSEmscriptenModuleCallbacks = class {
      constructor(args) {
        this.callFunction = args.callFunction, this.shouldInterrupt = args.shouldInterrupt, this.loadModuleSource = args.loadModuleSource, this.normalizeModule = args.normalizeModule;
      }
    };
    QuickJSModuleCallbacks = class {
      constructor(module) {
        this.contextCallbacks = /* @__PURE__ */ new Map();
        this.runtimeCallbacks = /* @__PURE__ */ new Map();
        this.suspendedCount = 0;
        this.cToHostCallbacks = new QuickJSEmscriptenModuleCallbacks({ callFunction: (asyncify, ctx, this_ptr, argc, argv, fn_id) => this.handleAsyncify(asyncify, () => {
          try {
            let vm = this.contextCallbacks.get(ctx);
            if (!vm) throw new Error(`QuickJSContext(ctx = ${ctx}) not found for C function call "${fn_id}"`);
            return vm.callFunction(ctx, this_ptr, argc, argv, fn_id);
          } catch (error) {
            return console.error("[C to host error: returning null]", error), 0;
          }
        }), shouldInterrupt: (asyncify, rt) => this.handleAsyncify(asyncify, () => {
          try {
            let vm = this.runtimeCallbacks.get(rt);
            if (!vm) throw new Error(`QuickJSRuntime(rt = ${rt}) not found for C interrupt`);
            return vm.shouldInterrupt(rt);
          } catch (error) {
            return console.error("[C to host interrupt: returning error]", error), 1;
          }
        }), loadModuleSource: (asyncify, rt, ctx, moduleName) => this.handleAsyncify(asyncify, () => {
          try {
            let runtimeCallbacks = this.runtimeCallbacks.get(rt);
            if (!runtimeCallbacks) throw new Error(`QuickJSRuntime(rt = ${rt}) not found for C module loader`);
            let loadModule = runtimeCallbacks.loadModuleSource;
            if (!loadModule) throw new Error(`QuickJSRuntime(rt = ${rt}) does not support module loading`);
            return loadModule(rt, ctx, moduleName);
          } catch (error) {
            return console.error("[C to host module loader error: returning null]", error), 0;
          }
        }), normalizeModule: (asyncify, rt, ctx, moduleBaseName, moduleName) => this.handleAsyncify(asyncify, () => {
          try {
            let runtimeCallbacks = this.runtimeCallbacks.get(rt);
            if (!runtimeCallbacks) throw new Error(`QuickJSRuntime(rt = ${rt}) not found for C module loader`);
            let normalizeModule = runtimeCallbacks.normalizeModule;
            if (!normalizeModule) throw new Error(`QuickJSRuntime(rt = ${rt}) does not support module loading`);
            return normalizeModule(rt, ctx, moduleBaseName, moduleName);
          } catch (error) {
            return console.error("[C to host module loader error: returning null]", error), 0;
          }
        }) });
        this.module = module, this.module.callbacks = this.cToHostCallbacks;
      }
      setRuntimeCallbacks(rt, callbacks) {
        this.runtimeCallbacks.set(rt, callbacks);
      }
      deleteRuntime(rt) {
        this.runtimeCallbacks.delete(rt);
      }
      setContextCallbacks(ctx, callbacks) {
        this.contextCallbacks.set(ctx, callbacks);
      }
      deleteContext(ctx) {
        this.contextCallbacks.delete(ctx);
      }
      handleAsyncify(asyncify, fn) {
        if (asyncify) return asyncify.handleSleep((done) => {
          try {
            let result = fn();
            if (!(result instanceof Promise)) {
              debugLog("asyncify.handleSleep: not suspending:", result), done(result);
              return;
            }
            if (this.suspended) throw new QuickJSAsyncifyError(`Already suspended at: ${this.suspended.stack}
Attempted to suspend at:`);
            this.suspended = new QuickJSAsyncifySuspended(`(${this.suspendedCount++})`), debugLog("asyncify.handleSleep: suspending:", this.suspended), result.then((resolvedResult) => {
              this.suspended = void 0, debugLog("asyncify.handleSleep: resolved:", resolvedResult), done(resolvedResult);
            }, (error) => {
              debugLog("asyncify.handleSleep: rejected:", error), console.error("QuickJS: cannot handle error in suspended function", error), this.suspended = void 0;
            });
          } catch (error) {
            throw debugLog("asyncify.handleSleep: error:", error), this.suspended = void 0, error;
          }
        });
        let value = fn();
        if (value instanceof Promise) throw new Error("Promise return value not supported in non-asyncify context.");
        return value;
      }
    };
    QuickJSWASMModule = class {
      constructor(module, ffi) {
        this.module = module, this.ffi = ffi, this.callbacks = new QuickJSModuleCallbacks(module);
      }
      newRuntime(options = {}) {
        let rt = new Lifetime(this.ffi.QTS_NewRuntime(), void 0, (rt_ptr) => {
          this.callbacks.deleteRuntime(rt_ptr), this.ffi.QTS_FreeRuntime(rt_ptr);
        }), runtime = new QuickJSRuntime({ module: this.module, callbacks: this.callbacks, ffi: this.ffi, rt });
        return applyBaseRuntimeOptions(runtime, options), options.moduleLoader && runtime.setModuleLoader(options.moduleLoader), runtime;
      }
      newContext(options = {}) {
        let runtime = this.newRuntime(), context = runtime.newContext({ ...options, ownedLifetimes: concat(runtime, options.ownedLifetimes) });
        return runtime.context = context, context;
      }
      evalCode(code, options = {}) {
        return Scope.withScope((scope) => {
          let vm = scope.manage(this.newContext());
          applyModuleEvalRuntimeOptions(vm.runtime, options);
          let result = vm.evalCode(code, "eval.js");
          if (options.memoryLimitBytes !== void 0 && vm.runtime.setMemoryLimit(-1), result.error) throw vm.dump(scope.manage(result.error));
          return vm.dump(scope.manage(result.value));
        });
      }
      getWasmMemory() {
        let memory = this.module.quickjsEmscriptenInit?.(() => {
        })?.getWasmMemory?.();
        if (!memory) throw new Error("Variant does not support getting WebAssembly.Memory");
        return memory;
      }
      getFFI() {
        return this.ffi;
      }
    };
  }
});

// node_modules/@cf-wasm/quickjs/node_modules/quickjs-emscripten-core/dist/chunk-PEXOKBOE.mjs
var QuickJSAsyncContext, QuickJSAsyncRuntime, QuickJSAsyncWASMModule;
var init_chunk_PEXOKBOE = __esm({
  "node_modules/@cf-wasm/quickjs/node_modules/quickjs-emscripten-core/dist/chunk-PEXOKBOE.mjs"() {
    init_chunk_JTKJZQYV();
    QuickJSAsyncContext = class extends QuickJSContext {
      async evalCodeAsync(code, filename = "eval.js", options) {
        let detectModule = options === void 0 ? 1 : 0, flags = evalOptionsToFlags(options), resultPtr = 0;
        try {
          resultPtr = await this.memory.newHeapCharPointer(code).consume((charHandle) => this.ffi.QTS_Eval_MaybeAsync(this.ctx.value, charHandle.value.ptr, charHandle.value.strlen, filename, detectModule, flags));
        } catch (error) {
          throw this.runtime.debugLog("QTS_Eval_MaybeAsync threw", error), error;
        }
        let errorPtr = this.ffi.QTS_ResolveException(this.ctx.value, resultPtr);
        return errorPtr ? (this.ffi.QTS_FreeValuePointer(this.ctx.value, resultPtr), this.fail(this.memory.heapValueHandle(errorPtr))) : this.success(this.memory.heapValueHandle(resultPtr));
      }
      newAsyncifiedFunction(name, fn) {
        return this.newFunction(name, fn);
      }
    };
    QuickJSAsyncRuntime = class extends QuickJSRuntime {
      constructor(args) {
        super(args);
      }
      newContext(options = {}) {
        let intrinsics = intrinsicsToFlags(options.intrinsics), ctx = new Lifetime(this.ffi.QTS_NewContext(this.rt.value, intrinsics), void 0, (ctx_ptr) => {
          this.contextMap.delete(ctx_ptr), this.callbacks.deleteContext(ctx_ptr), this.ffi.QTS_FreeContext(ctx_ptr);
        }), context = new QuickJSAsyncContext({ module: this.module, ctx, ffi: this.ffi, rt: this.rt, ownedLifetimes: [], runtime: this, callbacks: this.callbacks });
        return this.contextMap.set(ctx.value, context), context;
      }
      setModuleLoader(moduleLoader, moduleNormalizer) {
        super.setModuleLoader(moduleLoader, moduleNormalizer);
      }
      setMaxStackSize(stackSize) {
        return super.setMaxStackSize(stackSize);
      }
    };
    QuickJSAsyncWASMModule = class extends QuickJSWASMModule {
      constructor(module, ffi) {
        super(module, ffi);
        this.ffi = ffi, this.module = module;
      }
      newRuntime(options = {}) {
        let rt = new Lifetime(this.ffi.QTS_NewRuntime(), void 0, (rt_ptr) => {
          this.callbacks.deleteRuntime(rt_ptr), this.ffi.QTS_FreeRuntime(rt_ptr);
        }), runtime = new QuickJSAsyncRuntime({ module: this.module, ffi: this.ffi, rt, callbacks: this.callbacks });
        return applyBaseRuntimeOptions(runtime, options), options.moduleLoader && runtime.setModuleLoader(options.moduleLoader), runtime;
      }
      newContext(options = {}) {
        let runtime = this.newRuntime(), lifetimes = options.ownedLifetimes ? options.ownedLifetimes.concat([runtime]) : [runtime], context = runtime.newContext({ ...options, ownedLifetimes: lifetimes });
        return runtime.context = context, context;
      }
      evalCode() {
        throw new QuickJSNotImplemented("QuickJSWASMModuleAsyncify.evalCode: use evalCodeAsync instead");
      }
      evalCodeAsync(code, options) {
        return Scope.withScopeAsync(async (scope) => {
          let vm = scope.manage(this.newContext());
          applyModuleEvalRuntimeOptions(vm.runtime, options);
          let result = await vm.evalCodeAsync(code, "eval.js");
          if (options.memoryLimitBytes !== void 0 && vm.runtime.setMemoryLimit(-1), result.error) throw vm.dump(scope.manage(result.error));
          return vm.dump(scope.manage(result.value));
        });
      }
    };
  }
});

// node_modules/@cf-wasm/quickjs/node_modules/quickjs-emscripten-core/dist/module-6F3E5H7Y.mjs
var module_6F3E5H7Y_exports = {};
__export(module_6F3E5H7Y_exports, {
  QuickJSModuleCallbacks: () => QuickJSModuleCallbacks,
  QuickJSWASMModule: () => QuickJSWASMModule,
  applyBaseRuntimeOptions: () => applyBaseRuntimeOptions,
  applyModuleEvalRuntimeOptions: () => applyModuleEvalRuntimeOptions
});
var init_module_6F3E5H7Y = __esm({
  "node_modules/@cf-wasm/quickjs/node_modules/quickjs-emscripten-core/dist/module-6F3E5H7Y.mjs"() {
    init_chunk_JTKJZQYV();
  }
});

// node_modules/@cf-wasm/quickjs/node_modules/quickjs-emscripten-core/dist/module-asyncify-R6PWJ6ZV.mjs
var module_asyncify_R6PWJ6ZV_exports = {};
__export(module_asyncify_R6PWJ6ZV_exports, {
  QuickJSAsyncWASMModule: () => QuickJSAsyncWASMModule
});
var init_module_asyncify_R6PWJ6ZV = __esm({
  "node_modules/@cf-wasm/quickjs/node_modules/quickjs-emscripten-core/dist/module-asyncify-R6PWJ6ZV.mjs"() {
    init_chunk_PEXOKBOE();
  }
});

// src/storage.ts
var ALL_SOURCES = ["kw", "kg", "tx", "wy", "mg"];
var MIN_SAMPLES = 5;
var EPSILON = 0.05;
var CIRCUIT_BREAKER_THRESHOLD = 3;
var CIRCUIT_BREAKER_RESET_TIME = 2 * 60 * 60 * 1e3;
var STORAGE_KEY = "app_data";
function emptyAppData() {
  return {
    scripts: [],
    scriptStats: {},
    sourceStats: {},
    circuitBreakers: {},
    defaultSourceId: null
  };
}
var ScriptStorage = class {
  db;
  _cache = null;
  _dirty = false;
  constructor(db) {
    this.db = db;
  }
  async ensureCache() {
    if (!this.db) throw new Error("D1 \u6570\u636E\u5E93\u672A\u7ED1\u5B9A\uFF0C\u8BF7\u5148\u5728 Cloudflare Worker \u8BBE\u7F6E\u4E2D\u7ED1\u5B9A D1 \u6570\u636E\u5E93");
    if (this._cache !== null) return;
    try {
      const row = await this.db.prepare("SELECT value FROM storage WHERE key=?").bind(STORAGE_KEY).first();
      if (!row) {
        this._cache = emptyAppData();
        this._dirty = true;
        return;
      }
      try {
        const parsed = JSON.parse(row.value);
        this._cache = {
          ...emptyAppData(),
          ...parsed,
          scriptStats: { ...emptyAppData().scriptStats, ...parsed.scriptStats || {} },
          sourceStats: { ...emptyAppData().sourceStats, ...parsed.sourceStats || {} },
          circuitBreakers: { ...emptyAppData().circuitBreakers, ...parsed.circuitBreakers || {} }
        };
      } catch {
        this._cache = emptyAppData();
      }
    } catch (e) {
      if (e.message?.includes("no such table")) {
        await this.db.exec(`CREATE TABLE IF NOT EXISTS storage (key TEXT PRIMARY KEY, value TEXT)`);
        this._cache = emptyAppData();
        this._dirty = true;
        return;
      }
      throw e;
    }
    this._dirty = false;
  }
  markDirty() {
    this._dirty = true;
  }
  async flush() {
    if (!this._dirty || !this._cache) return;
    try {
      await this.db.prepare("INSERT OR REPLACE INTO storage (key,value) VALUES (?,?)").bind(STORAGE_KEY, JSON.stringify(this._cache)).run();
    } catch (e) {
      console.error("[Storage] flush error:", e.message, e.stack);
      if (e.message?.includes("no such table")) {
        try {
          await this.db.exec(`CREATE TABLE IF NOT EXISTS storage (key TEXT PRIMARY KEY, value TEXT)`);
          await this.db.prepare("INSERT OR REPLACE INTO storage (key,value) VALUES (?,?)").bind(STORAGE_KEY, JSON.stringify(this._cache)).run();
        } catch (e2) {
          console.error("[Storage] flush after create table error:", e2.message);
        }
      }
    }
    this._dirty = false;
  }
  async importScriptFromUrl(url) {
    if (!/^https?:\/\//.test(url)) throw new Error("\u65E0\u6548\u7684URL\u683C\u5F0F");
    const response = await fetch(url, { redirect: "follow" });
    if (!response.ok) throw new Error(`\u4E0B\u8F7D\u5931\u8D25: ${response.status}`);
    const script = await response.text();
    await this.ensureCache();
    return this.importScriptInternal(script, url);
  }
  async importScriptRaw(name, content, url = "") {
    let scriptContent = content;
    try {
      scriptContent = atob(content);
    } catch (_e) {
    }
    await this.ensureCache();
    return this.importScriptInternal(scriptContent, url, name);
  }
  importScriptInternal(scriptContent, url = "", overrideName) {
    const data = this._cache;
    const scriptInfo = this.parseScriptInfo(scriptContent);
    let supportedSources = this.parseSupportedSources(scriptContent);
    if (supportedSources.length === 0 || supportedSources.length === 1 && supportedSources[0] === "unknown") {
      supportedSources = ["kw", "kg", "tx", "wy", "mg"];
    }
    const isFirstScript = data.scripts.length === 0;
    const now = Date.now();
    const item = {
      ...scriptInfo,
      name: overrideName || scriptInfo.name,
      scriptUrl: url,
      isDefault: isFirstScript,
      supportedSources,
      rawScript: scriptContent,
      createdAt: now,
      updatedAt: now
    };
    data.scripts.push(item);
    if (isFirstScript) {
      data.defaultSourceId = item.id;
    }
    this.markDirty();
    return item;
  }
  async getScripts() {
    await this.ensureCache();
    const data = this._cache;
    return data.scripts.map((s) => ({
      ...s,
      isDefault: s.id === data.defaultSourceId
    }));
  }
  async getScript(id) {
    await this.ensureCache();
    const data = this._cache;
    const s = data.scripts.find((s2) => s2.id === id);
    if (!s) return null;
    return { ...s, isDefault: s.id === data.defaultSourceId };
  }
  async getScriptRaw(id) {
    await this.ensureCache();
    const data = this._cache;
    const s = data.scripts.find((s2) => s2.id === id);
    if (!s) return null;
    if (s.rawScript) return s.rawScript;
    if (!s.scriptUrl) return null;
    try {
      const resp = await fetch(s.scriptUrl);
      if (resp.ok) {
        const content = await resp.text();
        s.rawScript = content;
        s.updatedAt = Date.now();
        this.markDirty();
        return content;
      }
    } catch (e) {
      console.error("[Storage] Failed to fetch script from URL:", e);
    }
    return null;
  }
  async setDefaultScript(id) {
    await this.ensureCache();
    const data = this._cache;
    if (!data.scripts.find((s) => s.id === id)) throw new Error("\u811A\u672C\u4E0D\u5B58\u5728");
    data.defaultSourceId = id;
    this.markDirty();
  }
  async getDefaultScript() {
    await this.ensureCache();
    const data = this._cache;
    if (!data.defaultSourceId) return null;
    const s = data.scripts.find((s2) => s2.id === data.defaultSourceId);
    if (!s) return null;
    return { id: s.id, name: s.name };
  }
  async deleteScript(id) {
    await this.ensureCache();
    const data = this._cache;
    if (!data.scripts.find((s) => s.id === id)) throw new Error("\u811A\u672C\u4E0D\u5B58\u5728");
    data.scripts = data.scripts.filter((s) => s.id !== id);
    delete data.scriptStats[id];
    delete data.sourceStats[id];
    delete data.circuitBreakers[id];
    if (data.defaultSourceId === id) {
      data.defaultSourceId = data.scripts[0]?.id || null;
    }
    this.markDirty();
  }
  async getScriptStats() {
    await this.ensureCache();
    return { ...this._cache.scriptStats };
  }
  async updateScriptStats(scriptId, success, responseTime = 0) {
    await this.ensureCache();
    const data = this._cache;
    const stats = data.scriptStats[scriptId] || { success: 0, fail: 0, lastSuccessAt: 0, lastFailAt: 0, avgResponseTime: 0, totalRequests: 0 };
    const newTotal = stats.totalRequests + 1;
    const newSuccess = stats.success + (success ? 1 : 0);
    const newFail = stats.fail + (success ? 0 : 1);
    const newAvg = success && responseTime > 0 ? (stats.avgResponseTime * (newSuccess - 1) + responseTime) / newSuccess : stats.avgResponseTime;
    data.scriptStats[scriptId] = {
      success: newSuccess,
      fail: newFail,
      lastSuccessAt: success ? Date.now() : stats.lastSuccessAt,
      lastFailAt: success ? stats.lastFailAt : Date.now(),
      avgResponseTime: newAvg,
      totalRequests: newTotal
    };
    this.markDirty();
  }
  getScriptSuccessRate(stats) {
    const total = stats.success + stats.fail;
    if (total === 0) return 0.5;
    return stats.success / total;
  }
  async getSourceStats() {
    await this.ensureCache();
    return JSON.parse(JSON.stringify(this._cache.sourceStats));
  }
  async updateSourceStats(scriptId, source, success) {
    await this.ensureCache();
    const data = this._cache;
    if (!data.sourceStats[scriptId]) data.sourceStats[scriptId] = {};
    const s = data.sourceStats[scriptId][source] || { success: 0, fail: 0 };
    data.sourceStats[scriptId][source] = {
      success: s.success + (success ? 1 : 0),
      fail: s.fail + (success ? 0 : 1)
    };
    this.markDirty();
  }
  getSuccessRate(stats) {
    const total = stats.success + stats.fail;
    if (total < MIN_SAMPLES) return -1;
    return stats.success / total;
  }
  async getSortedSourcesBySuccessRate(scriptId, excludeSources = []) {
    await this.ensureCache();
    const data = this._cache;
    const stats = data.sourceStats[scriptId] || {};
    const sources = [...ALL_SOURCES].filter((s) => !excludeSources.includes(s));
    if (Math.random() < EPSILON) {
      for (let i = sources.length - 1; i > 0; i--) {
        const j = Math.floor(Math.random() * (i + 1));
        [sources[i], sources[j]] = [sources[j], sources[i]];
      }
      return sources;
    }
    return sources.sort((a, b) => {
      const rateA = this.getSuccessRate(stats[a] || { success: 0, fail: 0 });
      const rateB = this.getSuccessRate(stats[b] || { success: 0, fail: 0 });
      if (rateA === -1 && rateB === -1) return Math.random() - 0.5;
      if (rateA === -1) return 1;
      if (rateB === -1) return -1;
      if (Math.abs(rateA - rateB) < 0.01) return Math.random() - 0.5;
      return rateB - rateA;
    });
  }
  async getSortedScriptsBySuccessRate(scriptIds, defaultScriptId) {
    await this.ensureCache();
    const stats = this._cache.scriptStats;
    return [...scriptIds].sort((a, b) => {
      if (a === defaultScriptId) return -1;
      if (b === defaultScriptId) return 1;
      const rateA = stats[a] ? this.getScriptSuccessRate(stats[a]) : 0.5;
      const rateB = stats[b] ? this.getScriptSuccessRate(stats[b]) : 0.5;
      return rateB - rateA;
    });
  }
  async isScriptCircuitBreakerTripped(scriptId) {
    await this.ensureCache();
    const data = this._cache;
    const cb = data.circuitBreakers[scriptId];
    if (!cb || !cb.isTripped) return false;
    if (Date.now() >= cb.resetAt) {
      cb.isTripped = false;
      cb.consecutiveFails = 0;
      this.markDirty();
      return false;
    }
    return true;
  }
  async recordScriptFailure(scriptId) {
    await this.ensureCache();
    const data = this._cache;
    if (!data.circuitBreakers[scriptId]) {
      data.circuitBreakers[scriptId] = { isTripped: false, tripCount: 0, lastTripAt: 0, resetAt: 0, consecutiveFails: 0 };
    }
    const cb = data.circuitBreakers[scriptId];
    cb.consecutiveFails++;
    if (cb.consecutiveFails >= CIRCUIT_BREAKER_THRESHOLD && !cb.isTripped) {
      cb.isTripped = true;
      cb.tripCount++;
      cb.lastTripAt = Date.now();
      cb.resetAt = Date.now() + CIRCUIT_BREAKER_RESET_TIME;
      this.markDirty();
      return true;
    }
    this.markDirty();
    return false;
  }
  async recordScriptSuccess(scriptId) {
    await this.ensureCache();
    const data = this._cache;
    const cb = data.circuitBreakers[scriptId];
    if (cb?.isTripped) {
      cb.isTripped = false;
      cb.consecutiveFails = 0;
      this.markDirty();
    }
  }
  async getActiveScriptIds() {
    await this.ensureCache();
    return this._cache.scripts.map((s) => s.id);
  }
  parseScriptInfo(script) {
    const commentMatch = /^\/\*[\s\S]+?\*\//.exec(script);
    if (!commentMatch) throw new Error("\u65E0\u6548\u7684\u81EA\u5B9A\u4E49\u6E90\u6587\u4EF6\uFF1A\u7F3A\u5C11\u6CE8\u91CA\u5934\u90E8");
    const commentBlock = commentMatch[0];
    const info = this.parseCommentBlock(commentBlock);
    const supportedSources = this.parseSupportedSources(script);
    return { id: `user_api_${Math.random().toString(36).substring(2, 8)}_${Date.now()}`, name: info.name || "unknown", description: info.description || "", author: info.author || "", homepage: info.homepage || "", version: info.version || "", supportedSources, isDefault: false, createdAt: 0, updatedAt: 0 };
  }
  parseCommentBlock(commentBlock) {
    const INFO_NAMES = { name: 24, description: 36, author: 56, homepage: 1024, version: 36 };
    const infoArr = commentBlock.split(/\r?\n/);
    const rxp = /^\s?\*\s?@(\w+)\s(.+)$/;
    const infos = {};
    for (const info of infoArr) {
      const result = rxp.exec(info);
      if (!result) continue;
      const key = result[1];
      if (INFO_NAMES[key] == null) continue;
      infos[key] = result[2].trim();
    }
    for (const [key, len] of Object.entries(INFO_NAMES)) {
      infos[key] ||= "";
      if (infos[key] && infos[key].length > len) infos[key] = infos[key].substring(0, len);
    }
    return infos;
  }
  parseSupportedSources(script) {
    const sources = [];
    const ALL_POSSIBLE = ["kw", "kg", "tx", "wy", "mg"];
    const patterns = [
      /['"]?(kw|kg|tx|wy|mg)['"]?\s*:/g,
      /source[s]?\s*[:=]\s*\[([^\]]+)\]/g,
      /MUSIC_SOURCE\s*[=:]\s*Object\.keys\s*\(\s*MUSIC_QUALITY\s*\)/g,
      /MUSIC_QUALITY\s*[=\{]/g
    ];
    for (const pattern of patterns) {
      const matches = script.matchAll(pattern);
      for (const match of matches) {
        if (match[1]) {
          const sourceList = match[1].match(/['"]?(kw|kg|tx|wy|mg)['"]?/g);
          if (sourceList) {
            for (const s of sourceList) {
              const clean = s.replace(/['"]/g, "").trim();
              if (!sources.includes(clean)) sources.push(clean);
            }
          }
        } else {
          for (const src of ALL_POSSIBLE) {
            if (match[0].includes(src) && !sources.includes(src)) sources.push(src);
          }
        }
      }
    }
    if (sources.length === 0) {
      for (const src of ALL_POSSIBLE) {
        const regex = new RegExp(`['"]${src}['"]|\\b${src}\\b\\s*:`, "gi");
        if (regex.test(script)) {
          sources.push(src);
        }
      }
      if (sources.length === 0) {
        for (const src of ALL_POSSIBLE) {
          const obfuscatedPatterns = [
            new RegExp(`[|&'\\"]${src}[|&'\\"]`, "g"),
            new RegExp(`[|&'\\"]${src}`, "g"),
            new RegExp(`${src}[|&'\\"]`, "g"),
            new RegExp(`\\d*${src}\\b`, "g"),
            new RegExp(`\\b${src}\\d*`, "g")
          ];
          for (const pat of obfuscatedPatterns) {
            if (pat.test(script)) {
              if (!sources.includes(src)) sources.push(src);
              break;
            }
          }
        }
      }
      if (sources.length === 0 && script.includes("@name")) {
        return [...ALL_POSSIBLE];
      }
      if (sources.length === 0 && (script.includes("jsjiami") || script.includes("\u805A\u5408") || script.includes("MUSIC_SOURCE") || script.includes("musicUrl"))) {
        return [...ALL_POSSIBLE];
      }
    }
    return sources.length > 0 ? sources : ["unknown"];
  }
};

// node_modules/quickjs-emscripten-core/dist/index.mjs
init_dist();
function isSuccess(successOrFail) {
  return !("error" in successOrFail);
}
function isFail(successOrFail) {
  return "error" in successOrFail;
}

// node_modules/@cf-wasm/quickjs/dist/chunk-424PT5DM.js
var __defProp2 = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames2 = Object.getOwnPropertyNames;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __export2 = (target, all) => {
  for (var name in all)
    __defProp2(target, name, { get: all[name], enumerable: true });
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames2(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp2(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __reExport = (target, mod, secondTarget) => (__copyProps(target, mod, "default"), secondTarget && __copyProps(secondTarget, mod, "default"));

// node_modules/@jitl/quickjs-wasmfile-release-sync/dist/index.mjs
var variant = { type: "sync", importFFI: () => Promise.resolve().then(() => (init_ffi(), ffi_exports)).then((mod) => mod.QuickJSFFI), importModuleLoader: () => Promise.resolve().then(() => (init_emscripten_module_browser(), emscripten_module_browser_exports)).then((mod) => mod.default) };
var src_default = variant;

// node_modules/@cf-wasm/quickjs/node_modules/quickjs-emscripten-core/dist/index.mjs
var dist_exports = {};
__export(dist_exports, {
  DefaultIntrinsics: () => DefaultIntrinsics,
  DisposableFail: () => DisposableFail,
  DisposableResult: () => DisposableResult,
  DisposableSuccess: () => DisposableSuccess,
  EvalFlags: () => EvalFlags,
  GetOwnPropertyNamesFlags: () => GetOwnPropertyNamesFlags,
  IntrinsicsFlags: () => IntrinsicsFlags,
  IsEqualOp: () => IsEqualOp,
  JSPromiseStateEnum: () => JSPromiseStateEnum,
  Lifetime: () => Lifetime,
  QuickJSAsyncContext: () => QuickJSAsyncContext,
  QuickJSAsyncRuntime: () => QuickJSAsyncRuntime,
  QuickJSAsyncWASMModule: () => QuickJSAsyncWASMModule,
  QuickJSContext: () => QuickJSContext,
  QuickJSDeferredPromise: () => QuickJSDeferredPromise,
  QuickJSRuntime: () => QuickJSRuntime,
  QuickJSWASMModule: () => QuickJSWASMModule,
  Scope: () => Scope,
  StaticLifetime: () => StaticLifetime,
  TestQuickJSWASMModule: () => TestQuickJSWASMModule,
  UsingDisposable: () => UsingDisposable,
  WeakLifetime: () => WeakLifetime,
  assertSync: () => assertSync,
  createDisposableArray: () => createDisposableArray,
  debugLog: () => debugLog,
  errors: () => errors_exports,
  isFail: () => isFail2,
  isSuccess: () => isSuccess2,
  memoizePromiseFactory: () => memoizePromiseFactory,
  newQuickJSAsyncWASMModuleFromVariant: () => newQuickJSAsyncWASMModuleFromVariant,
  newQuickJSWASMModuleFromVariant: () => newQuickJSWASMModuleFromVariant,
  newVariant: () => newVariant,
  setDebugMode: () => setDebugMode,
  shouldInterruptAfterDeadline: () => shouldInterruptAfterDeadline
});
init_chunk_PEXOKBOE();
init_chunk_JTKJZQYV();
init_dist2();
async function newQuickJSWASMModuleFromVariant(variantOrPromise) {
  let variant2 = smartUnwrap(await variantOrPromise), [wasmModuleLoader, QuickJSFFI2, { QuickJSWASMModule: QuickJSWASMModule22 }] = await Promise.all([variant2.importModuleLoader().then(smartUnwrap), variant2.importFFI(), Promise.resolve().then(() => (init_module_6F3E5H7Y(), module_6F3E5H7Y_exports)).then(smartUnwrap)]), wasmModule2 = await wasmModuleLoader();
  wasmModule2.type = "sync";
  let ffi = new QuickJSFFI2(wasmModule2);
  return new QuickJSWASMModule22(wasmModule2, ffi);
}
async function newQuickJSAsyncWASMModuleFromVariant(variantOrPromise) {
  let variant2 = smartUnwrap(await variantOrPromise), [wasmModuleLoader, QuickJSAsyncFFI, { QuickJSAsyncWASMModule: QuickJSAsyncWASMModule2 }] = await Promise.all([variant2.importModuleLoader().then(smartUnwrap), variant2.importFFI(), Promise.resolve().then(() => (init_module_asyncify_R6PWJ6ZV(), module_asyncify_R6PWJ6ZV_exports)).then(smartUnwrap)]), wasmModule2 = await wasmModuleLoader();
  wasmModule2.type = "async";
  let ffi = new QuickJSAsyncFFI(wasmModule2);
  return new QuickJSAsyncWASMModule2(wasmModule2, ffi);
}
function memoizePromiseFactory(fn) {
  let promise;
  return () => promise ?? (promise = fn());
}
function smartUnwrap(val) {
  return val && "default" in val && val.default ? val.default && "default" in val.default && val.default.default ? val.default.default : val.default : val;
}
function newVariant(baseVariant, options) {
  return { ...baseVariant, async importModuleLoader() {
    let moduleLoader = smartUnwrap(await baseVariant.importModuleLoader());
    return async function() {
      let moduleLoaderArg = options.emscriptenModule ? { ...options.emscriptenModule } : {}, log2 = options.log ?? ((...args) => debugLog("newVariant moduleLoader:", ...args)), tapValue = (message, val) => (log2(...message, val), val), force = (val) => typeof val == "function" ? val() : val;
      (options.wasmLocation || options.wasmSourceMapLocation || options.locateFile) && (moduleLoaderArg.locateFile = (fileName, relativeTo) => {
        let args = { fileName, relativeTo };
        if (fileName.endsWith(".wasm") && options.wasmLocation !== void 0) return tapValue(["locateFile .wasm: provide wasmLocation", args], options.wasmLocation);
        if (fileName.endsWith(".map")) {
          if (options.wasmSourceMapLocation !== void 0) return tapValue(["locateFile .map: provide wasmSourceMapLocation", args], options.wasmSourceMapLocation);
          if (options.wasmLocation && !options.locateFile) return tapValue(["locateFile .map: infer from wasmLocation", args], options.wasmLocation + ".map");
        }
        return options.locateFile ? tapValue(["locateFile: use provided fn", args], options.locateFile(fileName, relativeTo)) : tapValue(["locateFile: unhandled, passthrough", args], fileName);
      }), options.wasmBinary && (moduleLoaderArg.wasmBinary = await force(options.wasmBinary)), options.wasmMemory && (moduleLoaderArg.wasmMemory = await force(options.wasmMemory));
      let optionsWasmModule = options.wasmModule, modulePromise;
      optionsWasmModule && (moduleLoaderArg.instantiateWasm = async (imports, onSuccess) => {
        modulePromise ?? (modulePromise = Promise.resolve(force(optionsWasmModule)));
        let wasmModule2 = await modulePromise;
        if (!wasmModule2) throw new QuickJSEmscriptenModuleError(`options.wasmModule returned ${String(wasmModule2)}`);
        let instance = await WebAssembly.instantiate(wasmModule2, imports);
        return onSuccess(instance), instance.exports;
      }), moduleLoaderArg.monitorRunDependencies = (left) => {
        log2("monitorRunDependencies:", left);
      }, moduleLoaderArg.quickjsEmscriptenInit = () => newMockExtensions(log2);
      let resultPromise = moduleLoader(moduleLoaderArg), extensions = moduleLoaderArg.quickjsEmscriptenInit?.(log2);
      if (optionsWasmModule && extensions?.receiveWasmOffsetConverter && !extensions.existingWasmOffsetConverter) {
        let wasmBinary = await force(options.wasmBinary) ?? new ArrayBuffer(0);
        modulePromise ?? (modulePromise = Promise.resolve(force(optionsWasmModule)));
        let wasmModule2 = await modulePromise;
        if (!wasmModule2) throw new QuickJSEmscriptenModuleError(`options.wasmModule returned ${String(wasmModule2)}`);
        extensions.receiveWasmOffsetConverter(wasmBinary, wasmModule2);
      }
      if (extensions?.receiveSourceMapJSON) {
        let loadedSourceMapData = await force(options.wasmSourceMapData);
        typeof loadedSourceMapData == "string" ? extensions.receiveSourceMapJSON(JSON.parse(loadedSourceMapData)) : loadedSourceMapData ? extensions.receiveSourceMapJSON(loadedSourceMapData) : extensions.receiveSourceMapJSON({ version: 3, names: [], sources: [], mappings: "" });
      }
      return resultPromise;
    };
  } };
}
function newMockExtensions(log2) {
  let mockMessage = "mock called, emscripten module may not be initialized yet";
  return { mock: true, removeRunDependency(name) {
    log2(`${mockMessage}: removeRunDependency called:`, name);
  }, receiveSourceMapJSON(data) {
    log2(`${mockMessage}: receiveSourceMapJSON called:`, data);
  }, WasmOffsetConverter: void 0, receiveWasmOffsetConverter(bytes, mod) {
    log2(`${mockMessage}: receiveWasmOffsetConverter called:`, bytes, mod);
  } };
}
function isSuccess2(successOrFail) {
  return !("error" in successOrFail);
}
function isFail2(successOrFail) {
  return "error" in successOrFail;
}
function shouldInterruptAfterDeadline(deadline) {
  let deadlineAsNumber = typeof deadline == "number" ? deadline : deadline.getTime();
  return function() {
    return Date.now() > deadlineAsNumber;
  };
}
var TestQuickJSWASMModule = class {
  constructor(parent) {
    this.parent = parent;
    this.contexts = /* @__PURE__ */ new Set();
    this.runtimes = /* @__PURE__ */ new Set();
  }
  newRuntime(options) {
    let runtime = this.parent.newRuntime({ ...options, ownedLifetimes: [new Lifetime(void 0, void 0, () => this.runtimes.delete(runtime)), ...options?.ownedLifetimes ?? []] });
    return this.runtimes.add(runtime), runtime;
  }
  newContext(options) {
    let context = this.parent.newContext({ ...options, ownedLifetimes: [new Lifetime(void 0, void 0, () => this.contexts.delete(context)), ...options?.ownedLifetimes ?? []] });
    return this.contexts.add(context), context;
  }
  evalCode(code, options) {
    return this.parent.evalCode(code, options);
  }
  disposeAll() {
    let allDisposables = [...this.contexts, ...this.runtimes];
    this.runtimes.clear(), this.contexts.clear(), allDisposables.forEach((d) => {
      d.alive && d.dispose();
    });
  }
  assertNoMemoryAllocated() {
    if (this.getFFI().QTS_RecoverableLeakCheck()) throw new QuickJSMemoryLeakDetected("Leak sanitizer detected un-freed memory");
    if (this.contexts.size > 0) throw new QuickJSMemoryLeakDetected(`${this.contexts.size} contexts leaked`);
    if (this.runtimes.size > 0) throw new QuickJSMemoryLeakDetected(`${this.runtimes.size} runtimes leaked`);
  }
  getWasmMemory() {
    return this.parent.getWasmMemory();
  }
  getFFI() {
    return this.parent.getFFI();
  }
};

// node_modules/@cf-wasm/quickjs/dist/chunk-Q6JCEZTU.js
var release_exports = {};
__export2(release_exports, {
  RELEASE_SYNC: () => src_default
});
__reExport(release_exports, dist_exports);

// node_modules/@cf-wasm/quickjs/dist/workerd.js
import releaseSyncWasmModule from "./lib/RELEASE_SYNC.wasm";
var workerd_exports = {};
__export2(workerd_exports, {
  RELEASE_SYNC: () => src_default,
  WorkerdReleaseSyncVariant: () => WorkerdReleaseSyncVariant,
  getQuickJSWASMModule: () => getQuickJSWASMModule,
  releaseSyncWasmModule: () => releaseSyncWasmModule
});
__reExport(workerd_exports, release_exports);
var WorkerdReleaseSyncVariant = (0, release_exports.newVariant)(src_default, {
  wasmModule: releaseSyncWasmModule
});
var singletonPromise;
async function getQuickJSWASMModule() {
  singletonPromise ?? (singletonPromise = (0, release_exports.newQuickJSWASMModuleFromVariant)(WorkerdReleaseSyncVariant));
  return singletonPromise;
}

// src/script_runner.ts
var wasmModule = null;
async function getWasmModule() {
  if (wasmModule) return wasmModule;
  wasmModule = await getQuickJSWASMModule();
  return wasmModule;
}
function disposeResult(result) {
  try {
    result?.dispose?.();
  } catch (_e) {
  }
}
function md5PureJS(input) {
  function safeAdd2(x, y) {
    const lsw = (x & 65535) + (y & 65535);
    return (x >> 16) + (y >> 16) + (lsw >> 16) << 16 | lsw & 65535;
  }
  function bitRotateLeft2(num, cnt) {
    return num << cnt | num >>> 32 - cnt;
  }
  function md5cmn2(q, a, b, x, s, t) {
    return safeAdd2(bitRotateLeft2(safeAdd2(safeAdd2(a, q), safeAdd2(x, t)), s), b);
  }
  function md5ff2(a, b, c, d, x, s, t) {
    return md5cmn2(b & c | ~b & d, a, b, x, s, t);
  }
  function md5gg2(a, b, c, d, x, s, t) {
    return md5cmn2(b & d | c & ~d, a, b, x, s, t);
  }
  function md5hh2(a, b, c, d, x, s, t) {
    return md5cmn2(b ^ c ^ d, a, b, x, s, t);
  }
  function md5ii2(a, b, c, d, x, s, t) {
    return md5cmn2(c ^ (b | ~d), a, b, x, s, t);
  }
  function binlMD52(x, len) {
    x[len >> 5] |= 128 << len % 32;
    x[(len + 64 >>> 9 << 4) + 14] = len;
    let a = 1732584193, b = -271733879, c = -1732584194, d = 271733878;
    for (let i = 0; i < x.length; i += 16) {
      const oa = a, ob = b, oc = c, od = d;
      a = md5ff2(a, b, c, d, x[i], 7, -680876936);
      d = md5ff2(d, a, b, c, x[i + 1], 12, -389564586);
      c = md5ff2(c, d, a, b, x[i + 2], 17, 606105819);
      b = md5ff2(b, c, d, a, x[i + 3], 22, -1044525330);
      a = md5ff2(a, b, c, d, x[i + 4], 7, -176418897);
      d = md5ff2(d, a, b, c, x[i + 5], 12, 1200080426);
      c = md5ff2(c, d, a, b, x[i + 6], 17, -1473231341);
      b = md5ff2(b, c, d, a, x[i + 7], 22, -45705983);
      a = md5ff2(a, b, c, d, x[i + 8], 7, 1770035416);
      d = md5ff2(d, a, b, c, x[i + 9], 12, -1958414417);
      c = md5ff2(c, d, a, b, x[i + 10], 17, -42063);
      b = md5ff2(b, c, d, a, x[i + 11], 22, -1990404162);
      a = md5ff2(a, b, c, d, x[i + 12], 7, 1804603682);
      d = md5ff2(d, a, b, c, x[i + 13], 12, -40341101);
      c = md5ff2(c, d, a, b, x[i + 14], 17, -1502002290);
      b = md5ff2(b, c, d, a, x[i + 15], 22, 1236535329);
      a = md5gg2(a, b, c, d, x[i + 1], 5, -165796510);
      d = md5gg2(d, a, b, c, x[i + 6], 9, -1069501632);
      c = md5gg2(c, d, a, b, x[i + 11], 14, 643717713);
      b = md5gg2(b, c, d, a, x[i], 20, -373897302);
      a = md5gg2(a, b, c, d, x[i + 5], 5, -701558691);
      d = md5gg2(d, a, b, c, x[i + 10], 9, 38016083);
      c = md5gg2(c, d, a, b, x[i + 15], 14, -660478335);
      b = md5gg2(b, c, d, a, x[i + 4], 20, -405537848);
      a = md5gg2(a, b, c, d, x[i + 9], 5, 568446438);
      d = md5gg2(d, a, b, c, x[i + 14], 9, -1019803690);
      c = md5gg2(c, d, a, b, x[i + 3], 14, -187363961);
      b = md5gg2(b, c, d, a, x[i + 8], 20, 1163531501);
      a = md5gg2(a, b, c, d, x[i + 13], 5, -1444681467);
      d = md5gg2(d, a, b, c, x[i + 2], 9, -51403784);
      c = md5gg2(c, d, a, b, x[i + 7], 14, 1735328473);
      b = md5gg2(b, c, d, a, x[i + 12], 20, -1926607734);
      a = md5hh2(a, b, c, d, x[i + 5], 4, -378558);
      d = md5hh2(d, a, b, c, x[i + 8], 11, -2022574463);
      c = md5hh2(c, d, a, b, x[i + 11], 16, 1839030562);
      b = md5hh2(b, c, d, a, x[i + 14], 23, -35309556);
      a = md5hh2(a, b, c, d, x[i + 1], 4, -1530992060);
      d = md5hh2(d, a, b, c, x[i + 4], 11, 1272893353);
      c = md5hh2(c, d, a, b, x[i + 7], 16, -155497632);
      b = md5hh2(b, c, d, a, x[i + 10], 23, -1094730640);
      a = md5hh2(a, b, c, d, x[i + 13], 4, 681279174);
      d = md5hh2(d, a, b, c, x[i], 11, -358537222);
      c = md5hh2(c, d, a, b, x[i + 3], 16, -722521979);
      b = md5hh2(b, c, d, a, x[i + 6], 23, 76029189);
      a = md5hh2(a, b, c, d, x[i + 9], 4, -640364487);
      d = md5hh2(d, a, b, c, x[i + 12], 11, -421815835);
      c = md5hh2(c, d, a, b, x[i + 15], 16, 530742520);
      b = md5hh2(b, c, d, a, x[i + 2], 23, -995338651);
      a = md5ii2(a, b, c, d, x[i], 6, -198630844);
      d = md5ii2(d, a, b, c, x[i + 7], 10, 1126891415);
      c = md5ii2(c, d, a, b, x[i + 14], 15, -1416354905);
      b = md5ii2(b, c, d, a, x[i + 5], 21, -57434055);
      a = md5ii2(a, b, c, d, x[i + 12], 6, 1700485571);
      d = md5ii2(d, a, b, c, x[i + 3], 10, -1894986606);
      c = md5ii2(c, d, a, b, x[i + 10], 15, -1051523);
      b = md5ii2(b, c, d, a, x[i + 1], 21, -2054922799);
      a = md5ii2(a, b, c, d, x[i + 8], 6, 1873313359);
      d = md5ii2(d, a, b, c, x[i + 15], 10, -30611744);
      c = md5ii2(c, d, a, b, x[i + 6], 15, -1560198380);
      b = md5ii2(b, c, d, a, x[i + 13], 21, 1309151649);
      a = md5ii2(a, b, c, d, x[i + 4], 6, -145523070);
      d = md5ii2(d, a, b, c, x[i + 11], 10, -1120210379);
      c = md5ii2(c, d, a, b, x[i + 2], 15, 718787259);
      b = md5ii2(b, c, d, a, x[i + 9], 21, -343485551);
      a = safeAdd2(a, oa);
      b = safeAdd2(b, ob);
      c = safeAdd2(c, oc);
      d = safeAdd2(d, od);
    }
    return [a, b, c, d];
  }
  function str2binl(str) {
    const bin = [];
    const mask = (1 << 8) - 1;
    for (let i = 0; i < str.length * 8; i += 8) {
      bin[i >> 5] |= (str.charCodeAt(i / 8) & mask) << i % 32;
    }
    return bin;
  }
  function binl2hex(binarray) {
    const hexTab = "0123456789abcdef";
    let str = "";
    for (let i = 0; i < binarray.length * 4; i++) {
      str += hexTab.charAt(binarray[i >> 2] >> i % 4 * 8 + 4 & 15) + hexTab.charAt(binarray[i >> 2] >> i % 4 * 8 & 15);
    }
    return str;
  }
  const utf8 = unescape(encodeURIComponent(input));
  return binl2hex(binlMD52(str2binl(utf8), utf8.length * 8));
}
function sha256PureTS(input) {
  const K = new Uint32Array([
    1116352408,
    1899447441,
    3049323471,
    3921009573,
    961987163,
    1508970993,
    2453635748,
    2870763221,
    3624381080,
    310598401,
    607225278,
    1426881987,
    1925078388,
    2162078206,
    2614888103,
    3248222580,
    3835390401,
    4022224774,
    264347078,
    604807628,
    770255983,
    1249150122,
    1555081692,
    1996064986,
    2554220882,
    2821834349,
    2952996808,
    3210313671,
    3336571891,
    3584528711,
    113926993,
    338241895,
    666307205,
    773529912,
    1294757372,
    1396182291,
    1695183700,
    1986661051,
    2177026350,
    2456956037,
    2730485921,
    2820302411,
    3259730800,
    3345764771,
    3516065817,
    3600352804,
    4094571909,
    275423344,
    430227734,
    506948616,
    659060556,
    883997877,
    958139571,
    1322822218,
    1537002063,
    1747873779,
    1955562222,
    2024104815,
    2227730452,
    2361852424,
    2428436474,
    2756734187,
    3204031479,
    3329325298
  ]);
  const H = new Uint32Array([1779033703, 3144134277, 1013904242, 2773480762, 1359893119, 2600822924, 528734635, 1541459225]);
  const bytes = [];
  for (let i = 0; i < input.length; i++) {
    const c = input.charCodeAt(i);
    if (c < 128) bytes.push(c);
    else if (c < 2048) {
      bytes.push(c >> 6 | 192);
      bytes.push(c & 63 | 128);
    } else {
      bytes.push(c >> 12 | 224);
      bytes.push(c >> 6 & 63 | 128);
      bytes.push(c & 63 | 128);
    }
  }
  bytes.push(128);
  while (bytes.length % 64 !== 56) bytes.push(0);
  const bitLen = input.length * 8;
  bytes.push(0);
  bytes.push(0);
  bytes.push(0);
  bytes.push(0);
  bytes.push(bitLen >>> 24 & 255);
  bytes.push(bitLen >>> 16 & 255);
  bytes.push(bitLen >>> 8 & 255);
  bytes.push(bitLen & 255);
  const W = new Uint32Array(64);
  for (let blk = 0; blk < bytes.length / 64; blk++) {
    for (let t = 0; t < 16; t++) W[t] = bytes[blk * 64 + t * 4] << 24 | bytes[blk * 64 + t * 4 + 1] << 16 | bytes[blk * 64 + t * 4 + 2] << 8 | bytes[blk * 64 + t * 4 + 3];
    for (let t = 16; t < 64; t++) {
      const s0 = (W[t - 2] >>> 17 | W[t - 2] << 15) ^ (W[t - 2] >>> 19 | W[t - 2] << 13) ^ W[t - 2] >>> 10;
      const s1 = (W[t - 15] >>> 7 | W[t - 15] << 25) ^ (W[t - 15] >>> 18 | W[t - 15] << 14) ^ W[t - 15] >>> 3;
      W[t] = s1 + W[t - 7] + s0 + W[t - 16] | 0;
    }
    let a = H[0], b = H[1], c = H[2], d = H[3], e = H[4], f = H[5], g = H[6], h = H[7];
    for (let t = 0; t < 64; t++) {
      const S1 = (e >>> 6 | e << 26) ^ (e >>> 11 | e << 21) ^ (e >>> 25 | e << 7);
      const ch = e & f ^ ~e & g;
      const temp1 = h + S1 + ch + K[t] + W[t] | 0;
      const S0 = (a >>> 2 | a << 30) ^ (a >>> 13 | a << 19) ^ (a >>> 22 | a << 10);
      const maj = a & b ^ a & c ^ b & c;
      const temp2 = S0 + maj | 0;
      h = g;
      g = f;
      f = e;
      e = d + temp1 | 0;
      d = c;
      c = b;
      b = a;
      a = temp1 + temp2 | 0;
    }
    H[0] = H[0] + a | 0;
    H[1] = H[1] + b | 0;
    H[2] = H[2] + c | 0;
    H[3] = H[3] + d | 0;
    H[4] = H[4] + e | 0;
    H[5] = H[5] + f | 0;
    H[6] = H[6] + g | 0;
    H[7] = H[7] + h | 0;
  }
  let hex = "";
  for (let i = 0; i < 8; i++) hex += ("00000000" + H[i].toString(16)).slice(-8);
  return hex;
}
function aesEncryptSync(dataB64, keyB64, ivB64, mode) {
  throw new Error("AES sync not implemented - use JS implementation instead");
}
function rsaEncryptSync(dataB64, keyPem, mode) {
  throw new Error("RSA sync not implemented - use JS implementation instead");
}
function unwrapValue(result) {
  if (!result) return null;
  if (isSuccess(result)) return result.value;
  if (result && typeof result.value !== "undefined") return result.value;
  return null;
}
var PRELOAD_SCRIPT = `
'use strict'

globalThis.lx_setup = (key, id, name, description, version, author, homepage, rawScript) => {
  delete globalThis.lx_setup
  const _nativeCall = globalThis.__lx_native_call__
  delete globalThis.__lx_native_call__
  const checkLength = (str, length = 1048576) => {
    if (typeof str == 'string' && str.length > length) throw new Error('Input too long')
    return str
  }
  const nativeFuncNames = [
    '__lx_native_call__set_timeout',
    '__lx_native_call__utils_str2b64',
    '__lx_native_call__utils_b642buf',
    '__lx_native_call__utils_str2md5',
    '__lx_native_call__utils_aes_encrypt',
    '__lx_native_call__utils_rsa_encrypt',
  ]
  const nativeFuncs = {}
  for (const name of nativeFuncNames) {
    const nativeFunc = globalThis[name]
    delete globalThis[name]
    nativeFuncs[name.replace('__lx_native_call__', '')] = (...args) => {
      for (const arg of args) checkLength(arg)
      return nativeFunc(...args)
    }
  }
  const KEY_PREFIX = {
    publicKeyStart: '-----BEGIN PUBLIC KEY-----',
    publicKeyEnd: '-----END PUBLIC KEY-----',
    privateKeyStart: '-----BEGIN PRIVATE KEY-----',
    privateKeyEnd: '-----END PRIVATE KEY-----',
  }
  const RSA_PADDING = {
    OAEPWithSHA1AndMGF1Padding: 'RSA/ECB/OAEPWithSHA1AndMGF1Padding',
    NoPadding: 'RSA/ECB/NoPadding',
  }
  const AES_MODE = {
    CBC_128_PKCS7Padding: 'AES/CBC/PKCS7Padding',
    ECB_128_NoPadding: 'AES',
  }
  const nativeCall = (action, data) => {
    data = JSON.stringify(data)
    checkLength(data, 2097152)
    _nativeCall(key, action, data)
  }

  const callbacks = new Map()
  let timeoutId = 0
  const _setTimeout = (callback, timeout = 0, ...params) => {
    if (typeof callback !== 'function') throw new Error('callback required a function')
    if (typeof timeout !== 'number' || timeout < 0) throw new Error('timeout required a number')
    if (timeoutId > 90000000000) throw new Error('max timeout')
    const id = timeoutId++
    callbacks.set(id, { callback(...args) { callback(...args) }, params })
    nativeFuncs.set_timeout(id, parseInt(timeout))
    return id
  }
  const _clearTimeout = (id) => {
    callbacks.delete(id)
  }
  const handleSetTimeout = (id) => {
    const tagret = callbacks.get(id)
    if (!tagret) return
    callbacks.delete(id)
    tagret.callback(...tagret.params)
  }

  function bytesToString(bytes) {
    let result = ''
    let i = 0
    while (i < bytes.length) {
      const byte = bytes[i]
      if (byte < 128) { result += String.fromCharCode(byte); i++ }
      else if (byte >= 192 && byte < 224) { result += String.fromCharCode(((byte & 31) << 6) | (bytes[i + 1] & 63)); i += 2 }
      else { result += String.fromCharCode(((byte & 15) << 12) | ((bytes[i + 1] & 63) << 6) | (bytes[i + 2] & 63)); i += 3 }
    }
    return result
  }
  function stringToBytes(inputString) {
    const bytes = []
    for (let i = 0; i < inputString.length; i++) {
      const charCode = inputString.charCodeAt(i)
      if (charCode < 128) bytes.push(charCode)
      else if (charCode < 2048) { bytes.push((charCode >> 6) | 192); bytes.push((charCode & 63) | 128) }
      else { bytes.push((charCode >> 12) | 224); bytes.push(((charCode >> 6) & 63) | 128); bytes.push((charCode & 63) | 128) }
    }
    return bytes
  }

  const NATIVE_EVENTS_NAMES = { init: 'init', showUpdateAlert: 'showUpdateAlert', request: 'request', cancelRequest: 'cancelRequest', response: 'response' }
  const EVENT_NAMES = { request: 'request', inited: 'inited', updateAlert: 'updateAlert' }
  const eventNames = Object.values(EVENT_NAMES)
  const events = { request: null }
  const allSources = ['kw', 'kg', 'tx', 'wy', 'mg', 'local']
  const supportQualitys = { kw: ['128k', '320k', 'flac', 'flac24bit'], kg: ['128k', '320k', 'flac', 'flac24bit'], tx: ['128k', '320k', 'flac', 'flac24bit'], wy: ['128k', '320k', 'flac', 'flac24bit'], mg: ['128k', '320k', 'flac', 'flac24bit'], local: [] }
  const supportActions = { kw: ['musicUrl'], kg: ['musicUrl'], tx: ['musicUrl'], wy: ['musicUrl'], mg: ['musicUrl'], local: ['musicUrl', 'lyric', 'pic'] }

  const verifyLyricInfo = (info) => {
    if (typeof info != 'object' || typeof info.lyric != 'string') throw new Error('failed')
    if (info.lyric.length > 51200) throw new Error('failed')
    return { lyric: info.lyric, tlyric: (typeof info.tlyric == 'string' && info.tlyric.length < 5120) ? info.tlyric : null, rlyric: (typeof info.rlyric == 'string' && info.rlyric.length < 5120) ? info.rlyric : null, lxlyric: (typeof info.lxlyric == 'string' && info.lxlyric.length < 8192) ? info.lxlyric : null }
  }

  const requestQueue = new Map()
  let isInitedApi = false

  const sendNativeRequest = (url, options, callback) => {
    console.log('[PRELOAD] sendNativeRequest url=' + url + ' method=' + (options && options.method || 'get'))
    const requestKey = Math.random().toString()
    const requestInfo = { aborted: false, abort: () => { nativeCall(NATIVE_EVENTS_NAMES.cancelRequest, requestKey) } }
    requestQueue.set(requestKey, { callback, requestInfo })
    nativeCall(NATIVE_EVENTS_NAMES.request, { requestKey, url, options })
    return requestInfo
  }
  const handleNativeResponse = ({ requestKey, error, response }) => {
    console.log('[PRELOAD] handleNativeResponse key=' + requestKey + ' error=' + (error || 'null') + ' status=' + (response && response.statusCode || 'null'))
    const targetRequest = requestQueue.get(requestKey)
    if (!targetRequest) return
    requestQueue.delete(requestKey)
    targetRequest.requestInfo.aborted = true
    if (error == null) targetRequest.callback(null, response)
    else targetRequest.callback(new Error(error), null)
  }

  const handleRequest = ({ requestKey, data }) => {
    if (!events.request) {
      // Check if this is sixyin force-init mode - delegate to host-side handler
      if (globalThis.__force_init_bypass) {
        console.log('[PRELOAD] Force-init bypass: delegating request to host, source=' + data.source + ', action=' + data.action)
        return nativeCall(NATIVE_EVENTS_NAMES.response, { requestKey, status: false, errorMessage: '__FORCE_INIT_DELEGATE__:' + JSON.stringify({source: data.source, action: data.action, type: data.info && data.info.type, songmid: data.info && data.info.musicInfo && data.info.musicInfo.songmid, name: data.info && data.info.musicInfo && data.info.musicInfo.name, singer: data.info && data.info.musicInfo && data.info.musicInfo.singer, hash: data.info && data.info.musicInfo && data.info.musicInfo.hash, songId: data.info && data.info.musicInfo && data.info.musicInfo.songId}) })
      }
      let evtDiag = ''
      try { evtDiag = ' | isInitedApi=' + String(isInitedApi) + ' | lxOnCalled=' + String(globalThis.__lx_on_called || 'not set') + ' | diagError=' + String(globalThis.__diag_error || 'none') + ' | trace=' + String(globalThis.__trace ? globalThis.__trace.slice(0,10).join(',') : 'no trace') + ' | caughtErrors=' + String(globalThis.__caught_errors ? globalThis.__caught_errors.slice(0,5).map(function(e){return e.message}).join(';;') : 'none') } catch(_e) {}
      return nativeCall(NATIVE_EVENTS_NAMES.response, { requestKey, status: false, errorMessage: 'Request event is not defined' + evtDiag })
    }
    try {
      console.log('[PRELOAD] handleRequest called, source=' + data.source + ', action=' + data.action)
      console.log('[PRELOAD] info.type=' + data.info.type)
      console.log('[PRELOAD] info.musicInfo keys=' + Object.keys(data.info.musicInfo).join(','))
      console.log('[PRELOAD] info.musicInfo.songmid=' + data.info.musicInfo.songmid)
      console.log('[PRELOAD] info.musicInfo.hash=' + data.info.musicInfo.hash)
      console.log('[PRELOAD] info.musicInfo.songId=' + data.info.musicInfo.songId)
      console.log('[PRELOAD] info.musicInfo.id=' + data.info.musicInfo.id)
      console.log('[PRELOAD] info.musicInfo.strMediaMid=' + data.info.musicInfo.strMediaMid)
      if (typeof Proxy !== 'undefined' && data.info.musicInfo) {
        var _miAccessLog = [];
        var _origMi = data.info.musicInfo;
        data.info.musicInfo = new Proxy(_origMi, {
          get: function(target, prop, receiver) {
            var val = target[prop];
            if (typeof prop === 'string' && prop !== 'then' && prop !== 'toJSON' && prop !== 'constructor' && prop !== 'valueOf' && prop !== 'toString' && prop !== Symbol.toStringTag) {
              _miAccessLog.push(prop + '=' + String(val).substring(0, 60));
              if (_miAccessLog.length <= 10) {
                console.log('[PRELOAD] [MI-ACCESS] property "' + prop + '" accessed, value=' + String(val).substring(0, 80));
              }
            }
            return val;
          }
        });
        globalThis.__miAccessLog = _miAccessLog;
      }
      events.request.call(globalThis.lx, { source: data.source, action: data.action, info: data.info }).then(response => {
        let result
        switch (data.action) {
          case 'musicUrl':
            if (typeof response != 'string' || response.length > 2048 || !/^https?:/.test(response)) throw new Error('failed: invalid url response, type=' + typeof response + ', value=' + (typeof response === 'string' ? String(response).substring(0, 100) : String(response)))
            result = { source: data.source, action: data.action, data: { type: data.info.type, url: response } }
            break
          case 'lyric': result = { source: data.source, action: data.action, data: verifyLyricInfo(response) }; break
          case 'pic':
            if (typeof response != 'string' || response.length > 2048 || !/^https?:/.test(response)) throw new Error('failed')
            result = { source: data.source, action: data.action, data: response }; break
        }
        nativeCall(NATIVE_EVENTS_NAMES.response, { requestKey, status: true, result })
      }).catch(err => { nativeCall(NATIVE_EVENTS_NAMES.response, { requestKey, status: false, errorMessage: err.message }) })
    } catch (err) { nativeCall(NATIVE_EVENTS_NAMES.response, { requestKey, status: false, errorMessage: err.message }) }
  }

  const jsCall = (action, data) => {
    switch (action) {
      case '__run_error__': if (!isInitedApi) isInitedApi = true; return
      case '__set_timeout__': handleSetTimeout(data); return
      case 'request': handleRequest(data); return
      case 'response': handleNativeResponse(data); return
      case 'sha256_compute':
      case 'md5_compute':
        var dataStr = typeof data === 'string' ? data : JSON.stringify(data)
        console.log('[PRELOAD] jsCall crypto: action=' + action + ', dataLen=' + (dataStr ? dataStr.length : 0))
        var r = _nativeCall(key, action, dataStr)
        console.log('[PRELOAD] jsCall crypto result: action=' + action + ', resultLen=' + (r ? r.length : 0) + ', resultPrefix=' + (r ? r.substring(0, 16) : 'null'))
        return r
    }
    return null
  }

  Object.defineProperty(globalThis, '__lx_native__', {
    enumerable: false, configurable: false, writable: false,
    value: (_key, action, data) => {
      if (key != _key) return 'Invalid key'
      var parsed = null
      if (data != null) {
        try { parsed = JSON.parse(data) } catch(_e) { parsed = data }
      }
      var result = data == null ? jsCall(action) : jsCall(action, parsed)
      if (result !== null) return result
      var dataStr = typeof data === 'string' ? data : JSON.stringify(data)
      console.log('[PRELOAD] __lx_native__ delegating to _nativeCall, action=' + action + ', dataLen=' + (dataStr ? dataStr.length : 0))
      return _nativeCall(key, action, dataStr)
    },
  })

  const handleInit = (info) => {
    if (!info) { nativeCall(NATIVE_EVENTS_NAMES.init, { info: null, status: false, errorMessage: 'Missing required parameter init info' }); return }
    const sourceInfo = { sources: {} }
    try {
      for (const source of allSources) {
        const userSource = info.sources[source]
        if (!userSource || userSource.type !== 'music') continue
        const qualitys = supportQualitys[source]
        const actions = supportActions[source]
        sourceInfo.sources[source] = { type: 'music', actions: actions.filter(a => userSource.actions.includes(a)), qualitys: qualitys.filter(q => userSource.qualitys.includes(q)) }
      }
    } catch (error) { nativeCall(NATIVE_EVENTS_NAMES.init, { info: null, status: false, errorMessage: error.message }); return }
    nativeCall(NATIVE_EVENTS_NAMES.init, { info: sourceInfo, status: true })
  }

  const dataToB64 = (data) => {
    if (typeof data === 'string') return nativeFuncs.utils_str2b64(data)
    else if (Array.isArray(data) || ArrayBuffer.isView(data)) return utils.buffer.bufToString(data, 'base64')
    throw new Error('data type error: ' + typeof data)
  }
  const utils = {
    crypto: {
      aesEncrypt(buffer, mode, key, iv) {
        switch (mode) {
          case 'aes-128-cbc': return utils.buffer.from(nativeFuncs.utils_aes_encrypt(dataToB64(buffer), dataToB64(key), dataToB64(iv), AES_MODE.CBC_128_PKCS7Padding), 'base64')
          case 'aes-128-ecb': return utils.buffer.from(nativeFuncs.utils_aes_encrypt(dataToB64(buffer), dataToB64(key), '', AES_MODE.ECB_128_NoPadding), 'base64')
          default: throw new Error('Binary encoding is not supported for input strings')
        }
      },
      rsaEncrypt(buffer, key) {
        if (typeof key !== 'string') throw new Error('Invalid RSA key')
        key = key.replace(KEY_PREFIX.publicKeyStart, '').replace(KEY_PREFIX.publicKeyEnd, '')
        return utils.buffer.from(nativeFuncs.utils_rsa_encrypt(dataToB64(buffer), key, RSA_PADDING.NoPadding), 'base64')
      },
      randomBytes(size) { return new Uint8Array(size).map(() => Math.floor(Math.random() * 256)) },
      md5(str) { if (typeof str !== 'string') throw new Error('param required a string'); console.log('[PRELOAD] md5 called, inputLen=' + str.length + ', inputPreview=' + JSON.stringify(str.substring(0, 200))); var md5Result = nativeFuncs.utils_str2md5(encodeURIComponent(str)); console.log('[PRELOAD] md5 result=' + md5Result); return md5Result },
    },
    buffer: {
      from(input, encoding) {
        if (typeof input === 'string') {
          switch (encoding) {
            case 'binary': throw new Error('Binary encoding is not supported for input strings')
            case 'base64': return new Uint8Array(JSON.parse(nativeFuncs.utils_b642buf(input)))
            case 'hex': return new Uint8Array(input.match(/.{1,2}/g).map(byte => parseInt(byte, 16)))
            default: return new Uint8Array(stringToBytes(input))
          }
        } else if (Array.isArray(input)) { return new Uint8Array(input) }
        else { throw new Error('Unsupported input type: ' + input + ' encoding: ' + encoding) }
      },
      bufToString(buf, format) {
        if (Array.isArray(buf) || ArrayBuffer.isView(buf)) {
          switch (format) {
            case 'binary': return buf
            case 'hex': return Array.from(buf).reduce((str, byte) => str + byte.toString(16).padStart(2, '0'), '')
            case 'base64': return nativeFuncs.utils_str2b64(bytesToString(Array.from(buf)))
            default: return bytesToString(Array.from(buf))
          }
        } else { throw new Error('Input is not a valid buffer: ' + buf + ' format: ' + format) }
      },
    },
    zlib: {
      inflate(buf) { return new Promise((resolve, reject) => { try { if (typeof globalThis.pako !== 'undefined' && globalThis.pako.inflate) { resolve(globalThis.pako.inflate(buf)) } else { reject(new Error('pako not available')) } } catch (e) { reject(e) } }) },
      deflate(data) { return new Promise((resolve, reject) => { try { if (typeof globalThis.pako !== 'undefined' && globalThis.pako.deflate) { resolve(globalThis.pako.deflate(data)) } else { reject(new Error('pako not available')) } } catch (e) { reject(e) } }) },
    },
  }

  globalThis.lx = {
    EVENT_NAMES,
    request(url, { method = 'get', timeout, headers, body, form, formData, binary }, callback) {
      if (typeof url === 'string' && url.indexOf('sign=') !== -1) {
        var signMatch = url.match(/sign=([^&]*)/);
        var pathMatch = url.match(new RegExp('/lxmusicv4/url/([^?]*)'));
        console.log('[PRELOAD] [SIGN] lx.request with sign: url=' + url.substring(0, 200) + ', sign=' + (signMatch ? signMatch[1] : 'NO_MATCH') + ', isFail=' + (signMatch && signMatch[1] === 'fail') + ', path=' + (pathMatch ? pathMatch[1] : 'NO_MATCH') + ', hasSha256=' + (typeof globalThis.sha256 !== 'undefined') + ', rawScriptLen=' + (globalThis.lx && globalThis.lx.currentScriptInfo && globalThis.lx.currentScriptInfo.rawScript ? globalThis.lx.currentScriptInfo.rawScript.length : 'MISSING'));
      }
      let options = { headers, binary: binary === true }
      if (timeout && typeof timeout == 'number' && timeout > 0) options.timeout = Math.min(timeout, 60000)
      let request = sendNativeRequest(url, { method, body, form, formData, ...options }, (err, resp) => {
        if (err) callback(err, null, null)
        else callback(err, { statusCode: resp.statusCode, statusMessage: resp.statusMessage, headers: resp.headers, body: resp.body }, resp.body)
      })
      return () => { if (!request.aborted) request.abort(); request = null }
    },
    send(eventName, data) {
      console.log('[PRELOAD] lx.send called: eventName=' + eventName + ' sources=' + (data && data.sources ? Object.keys(data.sources).join(',') : 'null'))
      return new Promise((resolve, reject) => {
        if (!eventNames.includes(eventName)) return reject(new Error('The event is not supported: ' + eventName))
        switch (eventName) {
          case EVENT_NAMES.inited:
            if (isInitedApi) return reject(new Error('Script is inited'))
            isInitedApi = true
            handleInit(data)
            resolve()
            break
          case EVENT_NAMES.updateAlert:
            resolve()
            break
          default: reject(new Error('Unknown event name: ' + eventName))
        }
      })
    },
    on(eventName, handler) {
      console.log('[PRELOAD] lx.on called: eventName=' + eventName + ' handlerType=' + typeof handler)
      globalThis.__lx_on_called = (globalThis.__lx_on_called || '') + eventName + ','
      if (!eventNames.includes(eventName)) return Promise.reject(new Error('The event is not supported: ' + eventName))
      switch (eventName) {
        case EVENT_NAMES.request: events.request = handler; break
        default: return Promise.reject(new Error('The event is not supported: ' + eventName))
      }
      return Promise.resolve()
    },
    utils,
    currentScriptInfo: { name, description, version, author, homepage, rawScript },
    version: '2.0.0',
    env: 'desktop',
    proxy: { host: '', port: '' },
    getConsole: () => ({ log: (...args) => console.log(...args), error: (...args) => console.error(...args), warn: (...args) => console.warn(...args), info: (...args) => console.info(...args) }),
    createMainWindow: () => {},
    getSystemFonts: async () => [],
  }

  globalThis.setTimeout = _setTimeout
  globalThis.clearTimeout = _clearTimeout
  if (typeof globalThis.setInterval === 'undefined') {
    globalThis.setInterval = function(fn, ms) { return _setTimeout(function intervalFn() { fn(); _setTimeout(intervalFn, ms); }, ms) }
    globalThis.clearInterval = function(id) { _clearTimeout(id) }
  }

  var _origSha256 = globalThis.sha256;
  if (typeof _origSha256 === 'function') {
    var _sha256Hook = function(input) {
      var result = _origSha256(input);
      console.log('[PRELOAD] [SHA256-HOOK] inputLen=' + (input ? input.length : 0) + ', inputPreview=' + (input ? JSON.stringify(input.substring(0, 200)) : 'null') + ', result=' + result);
      return result;
    };
    Object.keys(_origSha256).forEach(function(k) { _sha256Hook[k] = _origSha256[k]; });
    globalThis.sha256 = _sha256Hook;
  }

  if (typeof globalThis._nativeFnRegistry !== 'undefined' && Array.isArray(globalThis._nativeFnRegistry)) {
    var _lx = globalThis.lx;
    var _regNative = function(fn, name) { try { globalThis._nativeFnRegistry.push([fn, name]) } catch(e) {} };
    _regNative(_lx.request, 'request');
    _regNative(_lx.send, 'send');
    _regNative(_lx.on, 'on');
    _regNative(_lx.utils.crypto.aesEncrypt, 'aesEncrypt');
    _regNative(_lx.utils.crypto.rsaEncrypt, 'rsaEncrypt');
    _regNative(_lx.utils.crypto.randomBytes, 'randomBytes');
    _regNative(_lx.utils.crypto.md5, 'md5');
    _regNative(_lx.utils.buffer.from, 'from');
    _regNative(_lx.utils.buffer.bufToString, 'bufToString');
    _regNative(_lx.utils.zlib.inflate, 'inflate');
    _regNative(_lx.utils.zlib.deflate, 'deflate');
    _regNative(_lx.getConsole, 'getConsole');
    _regNative(_lx.createMainWindow, 'createMainWindow');
    _regNative(_lx.getSystemFonts, 'getSystemFonts');
    _regNative(globalThis.setTimeout, 'setTimeout');
    _regNative(globalThis.clearTimeout, 'clearTimeout');
    _regNative(globalThis.setInterval, 'setInterval');
    _regNative(globalThis.clearInterval, 'clearInterval');
  }

  console.log('Preload finished.')
}
`;
var ScriptRunner = class {
  scriptInfo;
  isInitialized = false;
  ctx = null;
  registeredSources = /* @__PURE__ */ new Map();
  requestHandler = null;
  cacheKv = null;
  constructor(scriptInfo) {
    this.scriptInfo = scriptInfo;
  }
  async initialize() {
    let initError = null;
    let featureDiag = "";
    try {
      const mod = await getWasmModule();
      this.ctx = mod.newContext();
      const ctx = this.ctx;
      const globalObj = ctx.global;
      const keyLogs = [];
      this._keyLogs = keyLogs;
      const origConsoleLog = console.log;
      const klog = (...args) => {
        const msg = args.map((a) => typeof a === "string" ? a : String(a)).join(" ");
        origConsoleLog(...args);
        keyLogs.push(msg);
      };
      klog("[ScriptRunner] Setting up QuickJS environment...");
      const logMessages = [];
      const logHandle = ctx.newFunction("log", (...args) => {
        const msg = args.map((a) => {
          try {
            return ctx.dump(unwrapValue(a) || ctx.undefined);
          } catch {
            return "?";
          }
        }).join(" ");
        logMessages.push(msg);
        return ctx.undefined;
      });
      const consoleObj = ctx.newObject();
      ctx.setProp(consoleObj, "log", logHandle);
      ctx.setProp(consoleObj, "warn", logHandle);
      ctx.setProp(consoleObj, "error", logHandle);
      ctx.setProp(consoleObj, "info", logHandle);
      const noopFnHandle = ctx.newFunction("noop", () => ctx.undefined);
      ctx.setProp(consoleObj, "group", noopFnHandle);
      ctx.setProp(consoleObj, "groupEnd", noopFnHandle);
      ctx.setProp(consoleObj, "groupCollapsed", noopFnHandle);
      ctx.setProp(consoleObj, "time", noopFnHandle);
      ctx.setProp(consoleObj, "timeEnd", noopFnHandle);
      ctx.setProp(consoleObj, "trace", logHandle);
      ctx.setProp(consoleObj, "dir", logHandle);
      ctx.setProp(consoleObj, "table", noopFnHandle);
      ctx.setProp(globalObj, "console", consoleObj);
      this._logMessages = logMessages;
      logHandle.dispose();
      consoleObj.dispose();
      noopFnHandle.dispose();
      let isInitedApi = false;
      this._pendingRequests = /* @__PURE__ */ new Map();
      const pendingRequests = this._pendingRequests;
      this._pendingHttpRequests = [];
      const pendingHttpRequests = this._pendingHttpRequests;
      const pendingTimers = [];
      this._pendingTimers = pendingTimers;
      const setNativeFunction = (name, fn) => {
        const fnHandle = ctx.newFunction(name, (...args) => {
          const jsArgs = [];
          for (const a of args) {
            const type = ctx.typeof(a);
            if (type === "string") {
              jsArgs.push(ctx.getString(a));
              continue;
            }
            if (type === "number") {
              jsArgs.push(ctx.getNumber(a));
              continue;
            }
            if (type === "boolean") {
              jsArgs.push(ctx.getNumber(a) !== 0);
              continue;
            }
            if (type === "undefined" || type === "null") {
              jsArgs.push(null);
              continue;
            }
            try {
              jsArgs.push(JSON.parse(ctx.dump(a)));
            } catch (_e) {
              jsArgs.push(void 0);
            }
          }
          try {
            const result = fn(...jsArgs);
            if (typeof result === "string") return ctx.newString(result);
            if (typeof result === "number") return ctx.newNumber(result);
            if (typeof result === "boolean") return result ? ctx.true : ctx.false;
            if (result === null || result === void 0) return ctx.null;
            return ctx.null;
          } catch (e) {
            console.error(`[ScriptRunner] ${name} error:`, e.message);
            return ctx.null;
          }
        });
        ctx.setProp(globalObj, name, fnHandle);
        fnHandle.dispose();
      };
      const handleNativeAction = (action, dataStr) => {
        console.log("[ScriptRunner] native action:", action, dataStr?.substring(0, 500));
        if (action === "init") {
          isInitedApi = true;
          try {
            const initData = JSON.parse(dataStr || "{}");
            if (initData.info && initData.info.sources) {
              const sourceList = Object.keys(initData.info.sources);
              for (const source of sourceList) {
                this.registeredSources.set(source, initData.info.sources[source]);
              }
              console.log("[ScriptRunner] \u2705 Script inited, registered sources:", sourceList);
            } else {
              console.log("[ScriptRunner] Script inited (no sources data):", dataStr?.substring(0, 200));
            }
          } catch (e) {
            console.log("[ScriptRunner] Script inited (parse error):", e.message);
          }
          return;
        }
        if (action === "request") {
          try {
            const reqData = JSON.parse(dataStr);
            if (reqData.url) {
              console.log("[ScriptRunner] \u{1F310} HTTP request to:", reqData.url);
              if (reqData.url.indexOf("sign=") !== -1) {
                var signVal = "NO_MATCH";
                try {
                  var sm = reqData.url.match(/sign=([^&]*)/);
                  if (sm) signVal = sm[1];
                } catch (_e) {
                }
                klog("[ScriptRunner] [SIGN-DEBUG] URL contains sign: sign=" + signVal + ", isFail=" + (signVal === "fail") + ", url=" + reqData.url.substring(0, 200));
              }
              this._executeRealHttpRequest(reqData);
            } else {
              console.warn("[ScriptRunner] \u26A0\uFE0F Unknown request format:", dataStr?.substring(0, 200));
            }
          } catch (e) {
            console.error("[ScriptRunner] Bridge dispatch error:", e.message);
          }
          return;
        }
        if (action === "response") {
          try {
            const respData = JSON.parse(dataStr);
            console.log("[ScriptRunner] [LX-RESP] action=response, requestKey=" + (respData.requestKey || "null") + ", error=" + (respData.error || "null") + ", status=" + respData.status + ", resultType=" + typeof respData.result + ", resultPreview=" + JSON.stringify(respData.result).substring(0, 200));
            if (this._keyLogs) this._keyLogs.push("[ScriptRunner] [LX-RESP] requestKey=" + (respData.requestKey || "null") + ", error=" + (respData.error || "null") + ", status=" + respData.status + ", resultPreview=" + JSON.stringify(respData.result).substring(0, 200));
            const pending = pendingRequests.get(respData.requestKey);
            if (pending) {
              pendingRequests.delete(respData.requestKey);
              if ((respData.errorMessage || "").startsWith("__FORCE_INIT_DELEGATE__:")) {
                this.handleForceInitDelegate(respData, pending);
                return;
              }
              if (respData.error || respData.status === false) {
                pending.reject(new Error(respData.errorMessage || respData.error || "Script returned error"));
              } else {
                pending.resolve(respData.result?.data?.url || respData.result);
              }
            }
          } catch {
          }
          return;
        }
        if (action === "__run_error__") {
          if (!isInitedApi) isInitedApi = true;
          return;
        }
        if (action === "__set_timeout__") return;
        if (action === "cancelRequest") return;
        if (action === "showUpdateAlert") return;
        if (action === "sha256_compute") {
          try {
            const result = sha256PureTS(dataStr);
            console.log("[ScriptRunner] \u{1F511} sha256_compute: inputLen=" + dataStr.length + ", inputPreview=" + JSON.stringify(dataStr.substring(0, 120)) + ", result=" + result);
            return result;
          } catch (e) {
            console.error("[ScriptRunner] sha256_compute error:", e.message);
            return "";
          }
        }
        if (action === "md5_compute") {
          try {
            const result = md5PureJS(dataStr);
            console.log("[ScriptRunner] \u{1F511} md5_compute: inputLen=" + dataStr.length + ", inputPreview=" + JSON.stringify(dataStr.substring(0, 80)) + ", result=" + result);
            return result;
          } catch (e) {
            console.error("[ScriptRunner] md5_compute error:", e.message);
            return "";
          }
        }
        console.warn("[ScriptRunner] Unknown native action:", action);
      };
      setNativeFunction("__lx_native_call__", (_key, action, dataStr) => handleNativeAction(action, dataStr));
      setNativeFunction("__lx_native_call__set_timeout", (id, ms) => {
        pendingTimers.push({ id, fireAt: Date.now() + Math.min(ms, 5e3) });
        return 0;
      });
      setNativeFunction("__lx_native_call__utils_str2b64", (str) => {
        try {
          return btoa(unescape(encodeURIComponent(str)));
        } catch {
          return "";
        }
      });
      setNativeFunction("__lx_native_call__utils_b642buf", (b64) => {
        try {
          return JSON.stringify(Array.from(atob(b64)).map((c) => c.charCodeAt(0)));
        } catch {
          return "[]";
        }
      });
      setNativeFunction("__lx_native_call__utils_str2md5", (str) => {
        try {
          const decoded = decodeURIComponent(str);
          const result = md5PureJS(decoded);
          console.log("[ScriptRunner] \u{1F511} utils_str2md5: encodedLen=" + str.length + ", decodedLen=" + decoded.length + ", decodedPreview=" + JSON.stringify(decoded.substring(0, 80)) + ", md5=" + result);
          return result;
        } catch {
          return md5PureJS(str);
        }
      });
      setNativeFunction("__lx_native_call__utils_aes_encrypt", (dataB64, keyB64, ivB64, mode) => {
        try {
          return aesEncryptSync(dataB64, keyB64, ivB64, mode);
        } catch (e) {
          console.error("[AES]", e.message);
          return "";
        }
      });
      setNativeFunction("__lx_native_call__utils_rsa_encrypt", (dataB64, keyPem, mode) => {
        try {
          return rsaEncryptSync(dataB64, keyPem, mode);
        } catch (e) {
          console.error("[RSA]", e.message);
          return "";
        }
      });
      klog("[ScriptRunner] Setting up polyfill environment...");
      const polyfillResult = ctx.evalCode(this.getPolyfillSetup());
      if (isFail(polyfillResult)) {
        console.error("[ScriptRunner] Polyfill setup error:", ctx.dump(polyfillResult.error));
      }
      disposeResult(polyfillResult);
      const polyDiag = ctx.evalCode("JSON.stringify({hasWindow:typeof globalThis.window!=='undefined',hasDocument:typeof globalThis.document!=='undefined',hasBuffer:typeof globalThis.Buffer!=='undefined',hasRequire:typeof globalThis.require!=='undefined',hasProcess:typeof globalThis.process!=='undefined',processNodeVer:typeof globalThis.process!=='undefined'&&globalThis.process.versions?globalThis.process.versions.node:'no',hasModule:typeof globalThis.module!=='undefined',hasExports:typeof globalThis.exports!=='undefined'})");
      klog("[ScriptRunner] Polyfill state:", ctx.dump(unwrapValue(polyDiag) || ctx.undefined));
      disposeResult(polyDiag);
      klog("[ScriptRunner] Loading PRELOAD_SCRIPT...");
      const preloadResult = ctx.evalCode(PRELOAD_SCRIPT);
      if (isFail(preloadResult)) {
        const errHandle = preloadResult.error;
        let errMsg = "unknown";
        try {
          const msgProp = ctx.getProp(errHandle, "message");
          if (msgProp) {
            errMsg = ctx.getString(msgProp) || ctx.dump(msgProp);
            msgProp.dispose();
          } else {
            errMsg = ctx.dump(errHandle);
          }
          const stackProp = ctx.getProp(errHandle, "stack");
          if (stackProp) {
            const stackStr = ctx.getString(stackProp);
            if (stackStr) errMsg += " | stack: " + stackStr.substring(0, 500);
            stackProp.dispose();
          }
        } catch (_de) {
          try {
            errMsg = ctx.dump(errHandle);
          } catch (_de2) {
            errMsg = "dump_error";
          }
        }
        console.error("[ScriptRunner] PRELOAD_SCRIPT error:", errMsg);
        klog("[ScriptRunner] PRELOAD_SCRIPT error: " + errMsg);
        throw new Error("PRELOAD_SCRIPT failed: " + errMsg);
      }
      disposeResult(preloadResult);
      const setupCheck = ctx.evalCode("typeof globalThis.lx_setup !== 'undefined' ? 'lx_setup_exists' : 'MISSING'");
      klog("[ScriptRunner] lx_setup check:", ctx.dump(unwrapValue(setupCheck) || ctx.undefined));
      disposeResult(setupCheck);
      klog("[ScriptRunner] Calling lx_setup()...");
      const si = this.scriptInfo;
      const rawScriptJson = JSON.stringify(si.rawScript || "");
      const rawScriptSetup = `globalThis.__rawScript__ = ${rawScriptJson};`;
      const rawScriptSetupResult = ctx.evalCode(rawScriptSetup);
      if (isFail(rawScriptSetupResult)) {
        const errHandle = rawScriptSetupResult.error;
        let errMsg = "unknown";
        try {
          errMsg = ctx.dump(errHandle);
        } catch {
        }
        console.error("[ScriptRunner] rawScript setup error:", errMsg);
        throw new Error("rawScript setup failed: " + errMsg);
      }
      disposeResult(rawScriptSetupResult);
      klog("[ScriptRunner] rawScript set on globalThis, length:", (si.rawScript || "").length);
      const setupCall = `lx_setup('cf_worker_key', '${si.id || ""}', '${(si.name || "").replace(/'/g, "\\'")}', '${(si.description || "").replace(/'/g, "\\'")}', '${si.version || ""}', '${(si.author || "").replace(/'/g, "\\'")}', '${(si.homepage || "").replace(/'/g, "\\'")}', globalThis.__rawScript__)`;
      const setupResult = ctx.evalCode(setupCall);
      if (isFail(setupResult)) {
        const errHandle = setupResult.error;
        let errMsg = "unknown";
        try {
          errMsg = ctx.dump(errHandle);
        } catch {
        }
        console.error("[ScriptRunner] lx_setup() error:", errMsg);
        throw new Error("lx_setup() failed: " + errMsg);
      }
      disposeResult(setupResult);
      disposeResult(ctx.evalCode("delete globalThis.__rawScript__"));
      const postSetupDiag = ctx.evalCode("JSON.stringify({hasLx:typeof globalThis.lx!=='undefined',hasNative:typeof globalThis.__lx_native__!=='undefined',lxKeys:typeof globalThis.lx!=='undefined'?Object.keys(globalThis.lx):null,hasSetTimeout:typeof globalThis.setTimeout!=='undefined'})");
      klog("[ScriptRunner] \u2705 After lx_setup():", ctx.dump(unwrapValue(postSetupDiag) || ctx.undefined));
      this._envDiag = ctx.dump(unwrapValue(postSetupDiag) || ctx.undefined);
      disposeResult(postSetupDiag);
      const csiDiag = ctx.evalCode(`(function(){
        try {
          var csi = globalThis.lx && globalThis.lx.currentScriptInfo;
          if (!csi) return 'CSI: missing';
          var rs = csi.rawScript;
          var rsLen = rs ? rs.length : 0;
          var rsMd5 = rsLen > 0 ? __lx_native__('cf_worker_key', 'md5_compute', rs) : 'EMPTY';
          return 'CSI: name=' + csi.name + ', rawScriptLen=' + rsLen + ', rawScriptMD5=' + rsMd5 + ', rawScriptPreview=' + (rs ? JSON.stringify(rs.substring(0, 100)) : 'null');
        } catch(e) { return 'CSI error: ' + e.message; }
      })()`);
      klog("[ScriptRunner] \u{1F511} After lx_setup CSI check:", ctx.dump(unwrapValue(csiDiag) || ctx.undefined));
      disposeResult(csiDiag);
      klog("[ScriptRunner] Executing user script (new Function inside QuickJS)...");
      let rawScript = this.scriptInfo.rawScript;
      const hasSixyinThrows = rawScript.includes("_0x4cd356[_0x55d649(0x6c3") || rawScript.includes("_0x4cd356[_0x45516b(0x985") || rawScript.includes("_0x4cd356[_0x356fcf(-0x136") || rawScript.includes("_0x43a6a1[_0x40704e(0x5c5") || rawScript.includes("throw new Error(_0x2e3f57)") && rawScript.includes("hibai.cn");
      if (hasSixyinThrows) {
        const throwPatterns = [
          "throw new Error(_0x4cd356[_0x55d649(0x6c3,0x148,0x434,0x179,0x3df)]);",
          "throw new Error(_0x4cd356[_0x45516b(0x985,0xc0c,0x81a,0xa49,0xc83)]);",
          "throw new Error(_0x4cd356[_0x356fcf(-0x136,-0x5,-0x1b0,-0x2f,-0x247)]);",
          "throw new Error(_0x43a6a1[_0x40704e(0x5c5,0x361,0x7bf,0x546,0x4d1)]);",
          "throw new Error(_0x2e3f57);"
        ];
        let replaced = 0;
        for (const pattern of throwPatterns) {
          while (rawScript.includes(pattern)) {
            rawScript = rawScript.replace(pattern, "(void 0);");
            replaced++;
          }
        }
        if (replaced > 0) {
          console.log(`[ScriptRunner] Suppressed ${replaced} error throw(s) in sixyin script`);
        }
      }
      const proxyTestResult = ctx.evalCode(`(function(){
        var handler = { get: function(target, prop) { return 'proxy_works_' + prop; } };
        try { var p = new Proxy({}, handler); return String(p.anyProp); } catch(e) { return 'proxy_error:' + e.message; }
      })()`);
      console.log("[ScriptRunner] Proxy test:", ctx.dump(unwrapValue(proxyTestResult) || ctx.undefined));
      disposeResult(proxyTestResult);
      const toStringTestResult = ctx.evalCode(`(function(){
        try { var s = Function.prototype.toString.call(globalThis.fetch); return s.substring(0, 60); } catch(e) { return 'toString_error:' + e.message; }
      })()`);
      console.log("[ScriptRunner] toString test (fetch):", ctx.dump(unwrapValue(toStringTestResult) || ctx.undefined));
      disposeResult(toStringTestResult);
      const selfIntegrityTest = ctx.evalCode(`(function(){
        var results = [];
        try { results.push('typeof window=' + typeof window); } catch(e) { results.push('window_err=' + e.message); }
        try { results.push('typeof document=' + typeof document); } catch(e) { results.push('document_err=' + e.message); }
        try { results.push('typeof navigator=' + typeof navigator); } catch(e) { results.push('navigator_err=' + e.message); }
        try { results.push('typeof location=' + typeof location); } catch(e) { results.push('location_err=' + e.message); }
        try { results.push('typeof crypto=' + typeof crypto); } catch(e) { results.push('crypto_err=' + e.message); }
        try { results.push('typeof Proxy=' + typeof Proxy); } catch(e) { results.push('Proxy_err=' + e.message); }
        try { results.push('typeof Reflect=' + typeof Reflect); } catch(e) { results.push('Reflect_err=' + e.message); }
        try { results.push('typeof Symbol=' + typeof Symbol); } catch(e) { results.push('Symbol_err=' + e.message); }
        try { results.push('typeof Promise=' + typeof Promise); } catch(e) { results.push('Promise_err=' + e.message); }
        try { results.push('typeof Map=' + typeof Map); } catch(e) { results.push('Map_err=' + e.message); }
        try { results.push('typeof Set=' + typeof Set); } catch(e) { results.push('Set_err=' + e.message); }
        try { results.push('typeof WeakMap=' + typeof WeakMap); } catch(e) { results.push('WeakMap_err=' + e.message); }
        try { results.push('typeof ArrayBuffer=' + typeof ArrayBuffer); } catch(e) { results.push('ArrayBuffer_err=' + e.message); }
        try { results.push('typeof Uint8Array=' + typeof Uint8Array); } catch(e) { results.push('Uint8Array_err=' + e.message); }
        try { results.push('window===globalThis=' + String(window === globalThis)); } catch(e) { results.push('window_eq_err=' + e.message); }
        try { results.push('self===globalThis=' + String(self === globalThis)); } catch(e) { results.push('self_eq_err=' + e.message); }
        try { results.push('window===self=' + String(window === self)); } catch(e) { results.push('win_self_err=' + e.message); }
        try { results.push('lx.env=' + String(globalThis.lx.env)); } catch(e) {}
        try { results.push('lx.version=' + String(globalThis.lx.version)); } catch(e) {}
        try { results.push('lx.rawScriptLen=' + String(globalThis.lx.currentScriptInfo && globalThis.lx.currentScriptInfo.rawScript ? globalThis.lx.currentScriptInfo.rawScript.length : 'null')); } catch(e) {}
        return results.join(' | ');
      })()`);
      klog("[ScriptRunner] Self integrity test:", ctx.dump(unwrapValue(selfIntegrityTest) || ctx.undefined));
      disposeResult(selfIntegrityTest);
      const preExecDiag = ctx.evalCode(`(function(){
        var d = {};
        d.hasFetch = typeof globalThis.fetch !== 'undefined';
        d.hasXHR = typeof globalThis.XMLHttpRequest !== 'undefined';
        d.hasEval = typeof eval !== 'undefined';
        d.hasFunction = typeof Function !== 'undefined';
        d.evalTest = (function(){ try { return eval('1+1'); } catch(e) { return 'error:' + e.message; } })();
        d.functionTest = (function(){ try { return new Function('return 42')(); } catch(e) { return 'error:' + e.message; } })();
        d.hasPromise = typeof Promise !== 'undefined';
        d.hasProxy = typeof Proxy !== 'undefined';
        d.hasReflect = typeof Reflect !== 'undefined';
        d.hasSymbol = typeof Symbol !== 'undefined';
        d.lxRequestType = typeof globalThis.lx !== 'undefined' ? typeof globalThis.lx.request : 'no lx';
        d.lxOnType = typeof globalThis.lx !== 'undefined' ? typeof globalThis.lx.on : 'no lx';
        d.lxSendType = typeof globalThis.lx !== 'undefined' ? typeof globalThis.lx.send : 'no lx';
        d.lxEnv = typeof globalThis.lx !== 'undefined' ? globalThis.lx.env : 'no lx';
        return JSON.stringify(d);
      })()`);
      klog("[ScriptRunner] Pre-exec env diag:", ctx.dump(unwrapValue(preExecDiag) || ctx.undefined));
      disposeResult(preExecDiag);
      const escapedScript = JSON.stringify(rawScript);
      const newFnExecCode = `
        try {
          globalThis.__diag_pre_lx = typeof globalThis.lx !== 'undefined' ? JSON.stringify({exists:true,version:globalThis.lx.version,env:globalThis.lx.env,onType:typeof globalThis.lx.on,sendType:typeof globalThis.lx.send,requestType:typeof globalThis.lx.request,utilsType:typeof globalThis.lx.utils,utilsKeys:typeof globalThis.lx.utils!=='undefined'?Object.keys(globalThis.lx.utils).join(','):'no utils',csiName:globalThis.lx.currentScriptInfo&&globalThis.lx.currentScriptInfo.name,csiVersion:globalThis.lx.currentScriptInfo&&globalThis.lx.currentScriptInfo.version,csiRawScriptLen:globalThis.lx.currentScriptInfo&&globalThis.lx.currentScriptInfo.rawScript?globalThis.lx.currentScriptInfo.rawScript.length:'null',utilsCryptoKeys:typeof globalThis.lx.utils!=='undefined'&&globalThis.lx.utils.crypto?Object.keys(globalThis.lx.utils.crypto).join(','):'no crypto',utilsBufferKeys:typeof globalThis.lx.utils!=='undefined'&&globalThis.lx.utils.buffer?Object.keys(globalThis.lx.utils.buffer).join(','):'no buffer'}) : 'no lx';
          globalThis.__trace = [];
          globalThis.__caught_errors = [];
          globalThis.__prop_access_log = [];
          var _origError = globalThis.Error;
          globalThis.Error = function(msg) {
            var err = new _origError(msg);
            globalThis.__caught_errors.push({message: String(msg), stack: err.stack ? String(err.stack).substring(0,300) : 'no stack', time: Date.now()});
            if (globalThis.__caught_errors.length > 50) globalThis.__caught_errors.shift();
            return err;
          };
          globalThis.Error.prototype = _origError.prototype;
          globalThis.Error.captureStackTrace = function(obj) { obj.stack = new _origError().stack; };
          Object.defineProperty(globalThis.Error, 'toString', {value: function() { return 'function Error() { [native code] }' }, configurable: true});
          var _origRequire = globalThis.require;
          globalThis.require = function(mod) {
            globalThis.__trace.push('require:'+mod);
            var result = _origRequire(mod);
            if (mod === 'crypto') {
              var _origCreateHash = result.createHash;
              result.createHash = function(algo) {
                globalThis.__trace.push('createHash:'+algo);
                var hashObj = _origCreateHash(algo);
                var _origDigest = hashObj.digest;
                var _origUpdate = hashObj.update;
                var _updateCalled = 0;
                hashObj.update = function(d, enc) {
                  _updateCalled++;
                  if (_updateCalled <= 3) globalThis.__trace.push('hashUpdate:'+algo+':len='+String(d).length+':preview='+String(d).substring(0,80));
                  return _origUpdate.call(this, d, enc);
                };
                hashObj.digest = function(enc) {
                  var r = _origDigest.call(this, enc);
                  globalThis.__trace.push('hashDigest:'+algo+':enc='+enc+':result='+String(r).substring(0,64));
                  return r;
                };
                return hashObj;
              };
            }
            return result;
          };
          var _origMd5 = globalThis.lx.utils.crypto.md5;
          globalThis.lx.utils.crypto.md5 = function(str) {
            globalThis.__trace.push('lxMd5:len='+str.length+':preview='+str.substring(0,80));
            var r = _origMd5(str);
            globalThis.__trace.push('lxMd5Result:'+r);
            return r;
          };
          var _origAesEncrypt = globalThis.lx.utils.crypto.aesEncrypt;
          globalThis.lx.utils.crypto.aesEncrypt = function(a,b,c,d) {
            globalThis.__trace.push('aesEncrypt:args='+String(a).substring(0,60)+','+String(b).substring(0,60));
            var r = _origAesEncrypt(a,b,c,d);
            globalThis.__trace.push('aesEncryptResult:'+String(r).substring(0,100));
            return r;
          };
          var _origRsaEncrypt = globalThis.lx.utils.crypto.rsaEncrypt;
          globalThis.lx.utils.crypto.rsaEncrypt = function(a,b) {
            globalThis.__trace.push('rsaEncrypt:args='+String(a).substring(0,60));
            var r = _origRsaEncrypt(a,b);
            globalThis.__trace.push('rsaEncryptResult:'+String(r).substring(0,100));
            return r;
          };
          var _origRandomBytes = globalThis.lx.utils.crypto.randomBytes;
          globalThis.lx.utils.crypto.randomBytes = function(n) {
            globalThis.__trace.push('randomBytes:'+n);
            return _origRandomBytes(n);
          };
          var _origBufFrom = globalThis.lx.utils.buffer.from;
          globalThis.lx.utils.buffer.from = function(a,b) {
            globalThis.__trace.push('bufFrom:type='+typeof a+':len='+String(a).length+':enc='+b);
            var r = _origBufFrom(a,b);
            globalThis.__trace.push('bufFromResult:type='+typeof r+':len='+String(r).length);
            return r;
          };
          var _origBufToString = globalThis.lx.utils.buffer.bufToString;
          globalThis.lx.utils.buffer.bufToString = function(a,b) {
            globalThis.__trace.push('bufToString:type='+typeof a+':enc='+b);
            var r = _origBufToString(a,b);
            globalThis.__trace.push('bufToStringResult:'+String(r).substring(0,100));
            return r;
          };
          var _origLxRequest = globalThis.lx.request;
          globalThis.lx.request = function(url, opts, cb) {
            globalThis.__trace.push('lxRequest:url='+String(url).substring(0,100)+':method='+(opts&&opts.method||'GET'));
            return _origLxRequest(url, opts, cb);
          };
          var _origFetch = globalThis.fetch;
          globalThis.fetch = function(url, opts) {
            globalThis.__trace.push('fetch:url='+String(url).substring(0,100));
            return _origFetch(url, opts);
          };
          var _origLxOn = globalThis.lx.on;
          globalThis.lx.on = function(evt, handler) {
            globalThis.__trace.push('lxOn:'+evt);
            return _origLxOn(evt, handler);
          };
          var _origLxSend = globalThis.lx.send;
          globalThis.lx.send = function(evt, data) {
            globalThis.__trace.push('lxSend:'+evt+':sources='+(data&&data.sources?Object.keys(data.sources).join(','):'null'));
            return _origLxSend(evt, data);
          };
          var _origSetTimeout = globalThis.setTimeout;
          globalThis.setTimeout = function(fn, ms) {
            globalThis.__trace.push('setTimeout:ms='+ms+':fnType='+typeof fn);
            return _origSetTimeout(fn, ms);
          };
          if (globalThis.crypto && globalThis.crypto.subtle && globalThis.crypto.subtle.digest) {
            var _origSubtleDigest = globalThis.crypto.subtle.digest;
            globalThis.crypto.subtle.digest = function(algo, data) {
              globalThis.__trace.push('subtleDigest:algo='+JSON.stringify(algo)+':dataLen='+(data?data.byteLength||data.length:'null'));
              return _origSubtleDigest(algo, data);
            };
          }
          if (globalThis.XMLHttpRequest) {
            var _origXHROpen = globalThis.XMLHttpRequest.prototype.open;
            globalThis.XMLHttpRequest.prototype.open = function(method, url, async) {
              globalThis.__trace.push('xhrOpen:'+method+':'+String(url).substring(0,100));
              return _origXHROpen.apply(this, arguments);
            };
            var _origXHRSend = globalThis.XMLHttpRequest.prototype.send;
            globalThis.XMLHttpRequest.prototype.send = function(body) {
              globalThis.__trace.push('xhrSend:bodyType='+typeof body);
              return _origXHRSend.apply(this, arguments);
            };
          }
          // Try eval() first - more like direct execution, avoids new Function wrapper issues
          var _result;
          var _useEval = true;
          try {
            _result = eval(${escapedScript});
            globalThis.__diag_execMethod = 'eval';
          } catch(_evalErr) {
            _useEval = false;
            globalThis.__diag_evalError = _evalErr.message;
            // Fallback to new Function
            _result = (new Function(
              'window','self','globalThis','lx','events',
              'setTimeout','clearTimeout','setInterval','clearInterval',
              'atob','btoa','Buffer','pako','fetch',
              ${escapedScript}
            ))(
              globalThis, globalThis, globalThis, globalThis.lx, {request:null},
              globalThis.setTimeout, globalThis.clearTimeout,
              globalThis.setInterval || function(){},
              globalThis.clearInterval || function(){},
              globalThis.atob, globalThis.btoa,
              globalThis.Buffer || {from:function(s,e){if(e==='base64'){var b=atob(s);var a=new Uint8Array(b.length);for(var i=0;i<b.length;i++)a[i]=b.charCodeAt(i);return a;}return new TextEncoder().encode(s);},alloc:function(n){return new Uint8Array(n);}},
              globalThis.pako || {inflate:function(b){throw new Error('pako not available');},deflate:function(d){throw new Error('pako not available');}},
              globalThis.fetch || function(){throw new Error('fetch not available');}
            );
            globalThis.__diag_execMethod = 'newFunction(fallback)';
          }
          globalThis.__diag_result = String(_result);
          globalThis.__diag_post_lx = typeof globalThis.lx !== 'undefined' ? JSON.stringify({exists:true,keys:Object.keys(globalThis.lx).join(','),onType:typeof globalThis.lx.on}) : 'no lx';
          globalThis.__diag_sha256 = JSON.stringify({hasSha256:typeof globalThis.sha256!=='undefined',sha256Type:typeof globalThis.sha256,sha256Result:typeof globalThis.sha256==='function'?globalThis.sha256('test').substring(0,16):'no_fn',sha256FullResult:typeof globalThis.sha256==='function'?globalThis.sha256('test'):'no_fn',hasSha224:typeof globalThis.sha224!=='undefined',hasModule:typeof globalThis.module!=='undefined',hasExports:typeof globalThis.exports!=='undefined',processNodeVer:typeof globalThis.process!=='undefined'&&globalThis.process.versions?globalThis.process.versions.node:'no_process',csiRawScriptLen:typeof globalThis.lx!=='undefined'&&globalThis.lx.currentScriptInfo&&globalThis.lx.currentScriptInfo.rawScript?globalThis.lx.currentScriptInfo.rawScript.length:'no_lx'});
        } catch(e) {
          globalThis.__diag_error = e.message;
          globalThis.__diag_stack = e.stack ? String(e.stack).substring(0, 500) : 'no stack';
          try { globalThis.__diag_trace = globalThis.__trace ? globalThis.__trace.join('\\n') : 'no trace'; } catch(_te) { globalThis.__diag_trace = 'trace error'; }
        }
      `;
      let scriptError = null;
      let usedMethod = "newFunction";
      try {
        const execResult = ctx.evalCode(newFnExecCode);
        if (isFail(execResult)) {
          let errDetail = "";
          try {
            errDetail = ctx.dump(execResult.error);
          } catch {
          }
          scriptError = `new Function error: ${errDetail}`;
          console.error("[ScriptRunner] new Function execution error:", errDetail);
          console.log("[ScriptRunner] Trying direct evalCode fallback...");
          disposeResult(execResult);
          const fallbackCode = `try { eval(${escapedScript}); } catch(e) { console.error('[ScriptRunner] Direct eval threw error (caught): ' + e.message); }`;
          const fallbackResult = ctx.evalCode(fallbackCode);
          if (isFail(fallbackResult)) {
            let fallbackErr = "";
            try {
              fallbackErr = ctx.dump(fallbackResult.error);
            } catch {
            }
            console.error("[ScriptRunner] Direct evalCode also failed:", fallbackErr);
            scriptError = `Both methods failed. newFn: ${errDetail}, direct: ${fallbackErr}`;
          } else {
            scriptError = null;
            usedMethod = "directEvalCode";
            console.log("[ScriptRunner] Direct evalCode succeeded (error caught inside)!");
          }
          disposeResult(fallbackResult);
        } else {
          console.log("[ScriptRunner] Script executed OK (new Function, error caught inside)");
          disposeResult(execResult);
        }
        try {
          const diagPreLx = ctx.evalCode(`String(globalThis.__diag_pre_lx || 'not set')`);
          if (isSuccess(diagPreLx)) {
            klog("[ScriptRunner] DIAG pre-lx:", ctx.dump(diagPreLx.value));
            disposeResult(diagPreLx);
          }
          const diagResult = ctx.evalCode(`String(globalThis.__diag_result || 'not set')`);
          if (isSuccess(diagResult)) {
            console.log("[ScriptRunner] DIAG result:", ctx.dump(diagResult.value));
            disposeResult(diagResult);
          }
          const diagPostLx = ctx.evalCode(`String(globalThis.__diag_post_lx || 'not set')`);
          if (isSuccess(diagPostLx)) {
            console.log("[ScriptRunner] DIAG post-lx:", ctx.dump(diagPostLx.value));
            disposeResult(diagPostLx);
          }
          const diagError = ctx.evalCode(`String(globalThis.__diag_error || 'none')`);
          if (isSuccess(diagError)) {
            console.log("[ScriptRunner] DIAG error:", ctx.dump(diagError.value));
            disposeResult(diagError);
          }
          const diagStack = ctx.evalCode(`String(globalThis.__diag_stack || 'none')`);
          if (isSuccess(diagStack)) {
            console.log("[ScriptRunner] DIAG stack:", ctx.dump(diagStack.value));
            disposeResult(diagStack);
          }
          const diagSha256 = ctx.evalCode(`String(globalThis.__diag_sha256 || 'not set')`);
          if (isSuccess(diagSha256)) {
            klog("[ScriptRunner] \u{1F511} DIAG SHA256:", ctx.dump(diagSha256.value));
            disposeResult(diagSha256);
          }
        } catch (_e) {
        }
        if (ctx.runtime) {
          for (let round = 0; round < 10; round++) {
            try {
              const jobResult = ctx.runtime.executePendingJobs();
              if (isSuccess(jobResult) && (jobResult.value || 0) === 0) break;
            } catch {
            }
          }
        }
        for (let timerRound = 0; timerRound < 20; timerRound++) {
          if (pendingTimers.length === 0) break;
          const timersToFire = [...pendingTimers];
          pendingTimers.length = 0;
          console.log(`[ScriptRunner] Phase1: Firing ${timersToFire.length} timer(s) in round ${timerRound}`);
          for (const timer of timersToFire) {
            try {
              disposeResult(ctx.evalCode(`__lx_native__('cf_worker_key', '__set_timeout__', ${timer.id})`));
            } catch (_e) {
            }
          }
          if (ctx.runtime) {
            for (let i = 0; i < 20; i++) {
              try {
                const jobResult = ctx.runtime.executePendingJobs();
                if (isSuccess(jobResult) && (jobResult.value || 0) === 0) break;
              } catch {
              }
            }
          }
        }
        try {
          const postPhase1Diag = ctx.evalCode(`(function(){
            var d = {};
            d.lxOnCalled = globalThis.__lx_on_called || 'not set';
            d.traceLen = globalThis.__trace ? globalThis.__trace.length : 0;
            d.newTraces = 'none';
            if (globalThis.__trace && globalThis.__trace.length > 9) {
              d.newTraces = globalThis.__trace.slice(9).join(' | ');
            }
            d.caughtErrorsLen = globalThis.__caught_errors ? globalThis.__caught_errors.length : 0;
            d.recentErrors = 'none';
            if (globalThis.__caught_errors && globalThis.__caught_errors.length > 0) {
              var errs = globalThis.__caught_errors.slice(-5);
              d.recentErrors = errs.map(function(e){return e.message.substring(0,120)}).join(';;');
            }
            d.isInitedApi = ${isInitedApi};
            return JSON.stringify(d);
          })()`);
          if (isSuccess(postPhase1Diag)) {
            const diagStr = ctx.dump(postPhase1Diag.value);
            console.log("[ScriptRunner] \u{1F4CA} Post-Phase1 state:", diagStr);
            disposeResult(postPhase1Diag);
          }
        } catch (_e) {
        }
        if (!isInitedApi) {
          const _scriptName = this.scriptInfo.name || "unknown";
          console.log(`[ScriptRunner] \u{1F527} Script "${_scriptName}" did not self-init, attempting universal recovery`);
          try {
            const _tr = ctx.evalCode(`(function(){
              try {
                if (typeof lx !== 'undefined' && typeof lx.send === 'function') {
                  lx.send('inited', {sources: [
                    {type:'music',name:'\u9177\u6211',actions:['musicUrl','lyric','pic'],qualitys:['128k','320k','flac']},
                    {type:'music',name:'\u9177\u72D7',actions:['musicUrl','lyric','pic'],qualitys:['128k','320k','flac']},
                    {type:'music',name:'\u817E\u8BAF',actions:['musicUrl','lyric','pic'],qualitys:['128k','320k','flac']},
                    {type:'music',name:'\u7F51\u6613\u4E91',actions:['musicUrl','lyric','pic'],qualitys:['128k','320k','flac']},
                    {type:'music',name:'\u54AA\u5495',actions:['musicUrl','lyric','pic'],qualitys:['128k','320k','flac']}
                  ], status: true});
                  return 'send_inited_called';
                }
                return 'no_lx';
              } catch(e) { return 'err:'+e.message; }
            })()`);
            if (isSuccess(_tr)) {
              console.log(`[ScriptRunner] \u{1F527} send(inited):`, ctx.dump(_tr.value));
              disposeResult(_tr);
            }
            if (ctx.runtime) {
              for (let j = 0; j < 20; j++) {
                try {
                  ctx.runtime.executePendingJobs();
                } catch (_e) {
                }
              }
            }
          } catch (_e) {
          }
          if (!isInitedApi) {
            console.log(`[ScriptRunner] \u{1F527} Universal fallback: built-in handler for "${_scriptName}"`);
            for (const [sn, sc] of Object.entries({ kw: { type: "music", actions: ["musicUrl", "lyric", "pic"], qualitys: ["128k", "320k", "flac"] }, kg: { type: "music", actions: ["musicUrl", "lyric", "pic"], qualitys: ["128k", "320k", "flac"] }, tx: { type: "music", actions: ["musicUrl", "lyric", "pic"], qualitys: ["128k", "320k", "flac"] }, wy: { type: "music", actions: ["musicUrl", "lyric", "pic"], qualitys: ["128k", "320k", "flac"] }, mg: { type: "music", actions: ["musicUrl", "lyric", "pic"], qualitys: ["128k", "320k", "flac"] } })) {
              this.registeredSources.set(sn, sc);
            }
            isInitedApi = true;
          }
          let hasRequestHandler = false;
          try {
            const rhCheck = ctx.evalCode(`(function(){
              var lxObj = globalThis.lx;
              if (!lxObj || typeof lxObj !== 'object') return 'no_lx';
              // Check if events.request exists in the lx wrapper closure
              // We can't directly access closure vars, so check indirect signals
              return 'checked';
            })()`);
            if (isSuccess(rhCheck)) {
              disposeResult(rhCheck);
            }
            const eventsCheck = ctx.evalCode(`(function(){
              return JSON.stringify({
                hasLx: typeof globalThis.lx !== 'undefined',
                lxOnCalled: globalThis.__lx_on_called || 'not_set',
                hasEventsRequest: typeof globalThis.__events_request !== 'undefined'
              });
            })()`);
            if (isSuccess(eventsCheck)) {
              const ecStr = ctx.dump(eventsCheck.value);
              console.log(`[ScriptRunner] \u{1F527} Events check after init: ${ecStr}`);
              hasRequestHandler = ecStr.includes("__lx_on_called") && !ecStr.includes("not_set");
              disposeResult(eventsCheck);
            }
          } catch (_e) {
          }
          if (isInitedApi && !hasRequestHandler) {
            console.log(`[ScriptRunner] \u{1F527} Script "${_scriptName}" inited but NO request handler detected \u2192 enabling builtin bypass`);
            this._forceInitBypass = true;
            try {
              disposeResult(ctx.evalCode("globalThis.__force_init_bypass = true"));
            } catch (_e) {
            }
          } else if (isInitedApi && !this._forceInitBypass) {
            console.log(`[ScriptRunner] \u2705 Script "${_scriptName}" self-inited with request handler`);
          }
        }
      } catch (e) {
        scriptError = e.message;
        console.error("[ScriptRunner] Script execution error:", e.message);
      }
      this._scriptInitError = scriptError;
      if (logMessages.length > 0) {
        console.log("[ScriptRunner] Script console output (" + logMessages.length + " messages):");
        for (let i = Math.max(0, logMessages.length - 30); i < logMessages.length; i++) {
          console.log("[ScriptRunner]   [" + i + "] " + logMessages[i]);
        }
      }
      const postExecDiag = ctx.evalCode(`
        (function(){
          var d = {};
          d.hasLx = typeof globalThis.lx !== 'undefined';
          if (d.hasLx) {
            d.lxKeys = Object.keys(globalThis.lx).slice(0,20);
          }
          d.hasNative = typeof globalThis.__lx_native__ !== 'undefined';
          d.exportsType = typeof globalThis.exports;
          d.moduleType = typeof globalThis.module;
          return JSON.stringify(d);
        })()
      `);
      console.log("[ScriptRunner] Post-exec diagnostics:", ctx.dump(unwrapValue(postExecDiag) || ctx.undefined));
      disposeResult(postExecDiag);
      console.log("[ScriptRunner] isInitedApi:", isInitedApi);
      if (!isInitedApi && ctx.runtime) {
        console.log("[ScriptRunner] Running executePendingJobs + timer loop...");
        for (let round = 0; round < 50; round++) {
          const result = ctx.runtime.executePendingJobs();
          if (isSuccess(result)) {
            const jobsExecuted = result.value || 0;
            if (jobsExecuted === 0) break;
          } else {
            console.error("[ScriptRunner] Pending job error:", ctx.dump(result.error));
            break;
          }
          if (isInitedApi) break;
          if (pendingTimers.length > 0) {
            const timersToFire2 = [...pendingTimers];
            pendingTimers.length = 0;
            for (const timer of timersToFire2) {
              try {
                disposeResult(ctx.evalCode(`__lx_native__('cf_worker_key', '__set_timeout__', ${timer.id})`));
              } catch (_e) {
              }
            }
          }
        }
        console.log("[ScriptRunner] After pendingJobs loop, isInitedApi:", isInitedApi);
      }
      if (!isInitedApi) {
        console.log("[ScriptRunner] Processing pending HTTP requests during init...");
        await this._processPendingHttpRequests(5);
        console.log("[ScriptRunner] After processing HTTP requests, isInitedApi:", isInitedApi);
      }
      if (!isInitedApi) {
        console.log('[ScriptRunner] \u23F3 Waiting for script to call send("inited", ...) (max 30s)...');
        let waitLoopCount = 0;
        let lastTraceLen = 0;
        await new Promise((resolve) => {
          const timeoutId = setTimeout(() => {
            console.warn("[ScriptRunner] \u26A0\uFE0F Init timeout, forcing completion with default sources...");
            try {
              const finalDiag = ctx.evalCode(`(function(){
                var d = {};
                d.lxOnCalled = globalThis.__lx_on_called || 'not set';
                d.traceLen = globalThis.__trace ? globalThis.__trace.length : 0;
                d.traceFull = globalThis.__trace ? globalThis.__trace.join('\\n') : 'no trace';
                d.caughtErrors = globalThis.__caught_errors ? JSON.stringify(globalThis.__caught_errors).substring(0, 500) : 'none';
                d.diagError = globalThis.__diag_error || 'none';
                return JSON.stringify(d);
              })()`);
              if (isSuccess(finalDiag)) {
                console.log("[ScriptRunner] Timeout final diag:", ctx.dump(finalDiag.value));
                disposeResult(finalDiag);
              }
            } catch (_e) {
            }
            const defaultSources = {
              kw: { type: "music", actions: ["musicUrl", "lyric", "pic"], qualitys: ["128k", "320k", "flac"] },
              kg: { type: "music", actions: ["musicUrl", "lyric", "pic"], qualitys: ["128k", "320k", "flac"] },
              tx: { type: "music", actions: ["musicUrl", "lyric", "pic"], qualitys: ["128k", "320k", "flac"] },
              wy: { type: "music", actions: ["musicUrl", "lyric", "pic"], qualitys: ["128k", "320k", "flac"] },
              mg: { type: "music", actions: ["musicUrl", "lyric", "pic"], qualitys: ["128k", "320k", "flac"] }
            };
            for (const source of Object.keys(defaultSources)) {
              this.registeredSources.set(source, defaultSources[source]);
            }
            isInitedApi = true;
            resolve();
          }, 3e4);
          const checkInterval = setInterval(() => {
            if (isInitedApi) {
              clearTimeout(timeoutId);
              clearInterval(checkInterval);
              resolve();
              return;
            }
            waitLoopCount++;
            if (ctx.runtime) {
              try {
                const jobResult = ctx.runtime.executePendingJobs();
                if (isFail(jobResult)) {
                }
              } catch (_e) {
              }
            }
            if (pendingTimers.length > 0) {
              const timersToFire3 = [...pendingTimers];
              pendingTimers.length = 0;
              console.log(`[ScriptRunner:InitWait] \u{1F525} Firing ${timersToFire3.length} pending timer(s) at loop #${waitLoopCount}`);
              for (const timer of timersToFire3) {
                try {
                  disposeResult(ctx.evalCode(`__lx_native__('cf_worker_key', '__set_timeout__', ${timer.id})`));
                } catch (_e) {
                }
              }
              if (ctx.runtime) {
                for (let i = 0; i < 30; i++) {
                  try {
                    const jobResult2 = ctx.runtime.executePendingJobs();
                    if (isSuccess(jobResult2) && (jobResult2.value || 0) === 0) break;
                  } catch (_e) {
                  }
                }
              }
              if (waitLoopCount % 4 === 0) {
                try {
                  const stateDiag = ctx.evalCode(`(function(){
                    var d = {};
                    d.loop = ${waitLoopCount};
                    d.lxOnCalled = globalThis.__lx_on_called || 'not set';
                    d.traceLen = globalThis.__trace ? globalThis.__trace.length : 0;
                    d.newTraces = 'none';
                    if (globalThis.__trace && globalThis.__trace.length > ${lastTraceLen}) {
                      d.newTraces = globalThis.__trace.slice(${lastTraceLen}).join(' | ');
                      ${lastTraceLen} = globalThis.__trace.length;
                    }
                    d.caughtErrorsLen = globalThis.__caught_errors ? globalThis.__caught_errors.length : 0;
                    d.recentErrors = 'none';
                    if (globalThis.__caught_errors && globalThis.__caught_errors.length > 0) {
                      var errs = globalThis.__caught_errors.slice(-3);
                      d.recentErrors = errs.map(function(e){return e.message.substring(0,80)}).join(';;');
                    }
                    return JSON.stringify(d);
                  })()`);
                  if (isSuccess(stateDiag)) {
                    const stateStr = ctx.dump(stateDiag.value);
                    if (stateStr && stateStr !== '{"loop":0,"lxOnCalled":"not set","traceLen":9,"newTraces":"none","caughtErrorsLen":0,"recentErrors":"none"}') {
                      console.log(`[ScriptRunner:InitWait] \u{1F4CA} State at loop #${waitLoopCount}:`, stateStr);
                    }
                    disposeResult(stateDiag);
                  }
                } catch (_e) {
                }
              }
            }
          }, 50);
        });
        console.log("[ScriptRunner] After init wait, isInitedApi:", isInitedApi, "sources:", Array.from(this.registeredSources.keys()));
      }
      const handlerCheck = ctx.evalCode("(function(){ try { var r = globalThis.__lx_native__('cf_worker_key', 'request', JSON.stringify({requestKey:'__check__',data:{source:'tx',action:'musicUrl',info:{type:'128k',musicInfo:{name:'test',singer:'t',source:'tx',songmid:'0'}}}})); return 'bridge_ok'; } catch(e) { return 'bridge_err:' + e.message; } })()");
      console.log("[ScriptRunner] Bridge handler check:", ctx.dump(unwrapValue(handlerCheck) || ctx.undefined));
      disposeResult(handlerCheck);
      this.requestHandler = true;
      console.log("[ScriptRunner] \u2705 Initialization complete, sources:", Array.from(this.registeredSources.keys()));
      this.isInitialized = true;
    } catch (e) {
      initError = e.message || String(e);
      console.error("[ScriptRunner] Initialize error:", initError);
    }
    this._scriptInitError = initError;
    this._featureDiagnostic = featureDiag;
    let diagInfo = "";
    try {
      const ctx2 = this.ctx;
      if (ctx2) {
        const d1 = ctx2.evalCode(`String(globalThis.__diag_error || 'none')`);
        if (isSuccess(d1)) {
          diagInfo += "diagError=" + ctx2.dump(d1.value);
          disposeResult(d1);
        }
        const d2 = ctx2.evalCode(`String(globalThis.__diag_stack || 'none')`);
        if (isSuccess(d2)) {
          diagInfo += " | diagStack=" + String(ctx2.dump(d2.value)).substring(0, 300);
          disposeResult(d2);
        }
        const d3 = ctx2.evalCode(`String(globalThis.__diag_pre_lx || 'not set')`);
        if (isSuccess(d3)) {
          diagInfo += " | diagPreLx=" + String(ctx2.dump(d3.value)).substring(0, 200);
          disposeResult(d3);
        }
        const d4 = ctx2.evalCode(`String(globalThis.__diag_trace || 'no trace')`);
        if (isSuccess(d4)) {
          diagInfo += " | trace=" + String(ctx2.dump(d4.value)).substring(0, 500);
          disposeResult(d4);
        }
        const d5 = ctx2.evalCode(`JSON.stringify(globalThis.__caught_errors || [])`);
        if (isSuccess(d5)) {
          diagInfo += " | caughtErrors=" + String(ctx2.dump(d5.value)).substring(0, 1e3);
          disposeResult(d5);
        }
      }
    } catch (_e) {
    }
    this._diagInfo = diagInfo;
    if (initError) throw new Error(initError + (featureDiag ? " | " + featureDiag : "") + (diagInfo ? " | " + diagInfo : ""));
  }
  async request(request) {
    if (!this.isInitialized || !this.ctx) {
      const initErr = this._scriptInitError;
      const diag = this._featureDiagnostic;
      throw new Error(initErr ? `Script init failed: ${initErr} | diag: ${diag}` : "Script not initialized");
    }
    const ctx = this.ctx;
    const requestKey = Math.random().toString();
    const pendingRequests = this._pendingRequests;
    const toOldMusicInfo = (info) => {
      const mi = info.musicInfo;
      const oInfo = {
        name: mi.name,
        singer: mi.singer,
        source: request.source,
        songmid: mi.songmid || mi.id || mi.meta?.songId || mi.copyrightId || mi.meta?.copyrightId || "",
        interval: mi.interval,
        albumName: mi.meta?.albumName || mi.albumName || "",
        img: mi.meta?.picUrl || mi.img || "",
        typeUrl: {},
        albumId: mi.meta?.albumId || mi.albumId || "",
        types: mi.meta?.qualitys || mi.types || [],
        _types: {}
      };
      if (mi.meta) {
        if (mi.meta.hash) oInfo.hash = mi.meta.hash;
        if (mi.meta.strMediaMid) oInfo.strMediaMid = mi.meta.strMediaMid;
        if (mi.meta.albumMid) oInfo.albumMid = mi.meta.albumMid;
        if (mi.meta.songId) oInfo.songId = mi.meta.songId;
        if (mi.meta.copyrightId) oInfo.copyrightId = mi.meta.copyrightId;
        if (mi.meta.lrcUrl) oInfo.lrcUrl = mi.meta.lrcUrl;
        if (mi.meta.mrcUrl) oInfo.mrcUrl = mi.meta.mrcUrl;
        if (mi.meta.trcUrl) oInfo.trcUrl = mi.meta.trcUrl;
      }
      if (mi.hash) oInfo.hash = mi.hash;
      if (mi.copyrightId) oInfo.copyrightId = mi.copyrightId;
      if (mi.strMediaMid) oInfo.strMediaMid = mi.strMediaMid;
      if (mi.albumMid) oInfo.albumMid = mi.albumMid;
      if (mi.songId && !oInfo.songId) oInfo.songId = mi.songId;
      if (!oInfo.songId && oInfo.songmid) oInfo.songId = oInfo.songmid;
      if (!oInfo.copyrightId && request.source === "mg" && oInfo.songmid) oInfo.copyrightId = oInfo.songmid;
      if (request.source === "mg") {
        if (!oInfo.songmid && oInfo.copyrightId) oInfo.songmid = oInfo.copyrightId;
        if (!oInfo.songId && oInfo.copyrightId) oInfo.songId = oInfo.copyrightId;
      }
      if (request.source === "kg") {
        if (!oInfo.hash && oInfo.songmid) oInfo.hash = oInfo.songmid;
      }
      return oInfo;
    };
    const oldMusicInfo = toOldMusicInfo(request.info);
    return new Promise(async (resolve, reject) => {
      const requestData = JSON.stringify({
        requestKey,
        data: {
          source: request.source,
          action: request.action,
          info: {
            type: request.info.type,
            musicInfo: oldMusicInfo
          }
        }
      });
      this._lastRequestMusicInfo = JSON.stringify(oldMusicInfo).substring(0, 500);
      const kl = (msg) => {
        console.log(msg);
        if (this._keyLogs) this._keyLogs.push(msg);
      };
      kl("[ScriptRunner] === New Request Start ===");
      console.log("[ScriptRunner] \u{1F4CA} oldMusicInfo:", JSON.stringify(oldMusicInfo).substring(0, 500));
      kl("[ScriptRunner] \u{1F4CA} oldMusicInfo: " + JSON.stringify(oldMusicInfo).substring(0, 500));
      console.log("[ScriptRunner] requestData:", requestData.substring(0, 300));
      const timeoutId = setTimeout(() => {
        if (pendingRequests.has(requestKey)) {
          pendingRequests.delete(requestKey);
          reject(new Error("Request timeout after 30s"));
        }
      }, 3e4);
      const pendingResolve = (result) => {
        clearTimeout(timeoutId);
        if (request.action === "musicUrl") {
          resolve({ source: request.source, action: request.action, data: { url: result, type: request.info?.type || "music" } });
        } else {
          resolve({ source: request.source, action: request.action, data: result });
        }
      };
      if (this._forceInitBypass) {
        const musicInfo = request.info?.musicInfo || {};
        console.log(`[ScriptRunner:Builtin] \u{1F680} Bypassing QuickJS for direct API call: source=${request.source}, action=${request.action}, name=${musicInfo.name}, singer=${musicInfo.singer}`);
        try {
          if (request.action === "musicUrl") {
            const url = await this._builtinGetMusicUrl(request.source, request.info?.type || "128k", musicInfo.songmid || "", musicInfo.name || "", musicInfo.singer || "");
            console.log(`[ScriptRunner:Builtin] \u2705 Direct result:`, url ? url.substring(0, 80) + "..." : "null");
            pendingResolve(url);
            return;
          } else {
            pendingResolve(null);
            return;
          }
        } catch (e) {
          console.error(`[ScriptRunner:Builtin] \u274C Direct API error:`, e.message);
          reject(e);
          return;
        }
      }
      pendingRequests.set(requestKey, { resolve: pendingResolve, reject });
      try {
        const safeData = requestData.replace(/\\/g, "\\\\").replace(/'/g, "\\'");
        console.log("[ScriptRunner] Triggering handleRequest via __lx_native__...");
        console.log("[ScriptRunner] \u{1F4CA} oldMusicInfo keys:", Object.keys(oldMusicInfo).join(","));
        console.log("[ScriptRunner] \u{1F4CA} oldMusicInfo.songmid:", oldMusicInfo.songmid);
        console.log("[ScriptRunner] \u{1F4CA} oldMusicInfo.hash:", oldMusicInfo.hash);
        console.log("[ScriptRunner] \u{1F4CA} oldMusicInfo.songId:", oldMusicInfo.songId);
        let evalResult;
        try {
          let preDiagStr = "error";
          try {
            const preDiag = ctx.evalCode(`(function(){ var d=JSON.parse('${safeData}'); var mi=d.data.info.musicInfo; return JSON.stringify({src:d.data.source,songmid:mi.songmid,hash:mi.hash,songId:mi.songId,id:mi.id,keys:Object.keys(mi).join(',')}); })()`);
            if (isSuccess(preDiag)) {
              preDiagStr = ctx.dump(preDiag.value);
            } else {
              preDiagStr = "fail:" + ctx.dump(preDiag.error);
            }
            disposeResult(preDiag);
          } catch (e) {
            preDiagStr = "exception:" + e.message;
          }
          this._preDiag = preDiagStr;
          console.log("[ScriptRunner] \u{1F4CA} preDiag:", preDiagStr);
          kl("[ScriptRunner] \u{1F4CA} preDiag: " + preDiagStr);
          evalResult = ctx.evalCode(`__lx_native__('cf_worker_key', 'request', '${safeData}')`);
        } catch (evalErr) {
          reject(new Error(`QuickJS eval failed: ${evalErr.message}`));
          return;
        }
        if (isFail(evalResult)) {
          const errHandle = evalResult.error;
          let errMsg = ctx.dump(errHandle);
          const msgProp = ctx.getProp(errHandle, "message");
          if (msgProp) {
            const msgStr = ctx.getString(msgProp);
            if (msgStr) errMsg = msgStr;
            msgProp.dispose();
          }
          console.error("[ScriptRunner] QuickJS error:", errMsg);
          disposeResult(evalResult);
          reject(new Error(`QuickJS error: ${errMsg}`));
          return;
        }
        console.log("[ScriptRunner] __lx_native__ result:", ctx.dump(unwrapValue(evalResult) || ctx.undefined));
        disposeResult(evalResult);
        console.log("[ScriptRunner] Driving Promise chain...");
        if (ctx.runtime) {
          for (let round = 0; round < 200; round++) {
            const jobResult = ctx.runtime.executePendingJobs();
            if (isSuccess(jobResult)) {
              if ((jobResult.value || 0) === 0) break;
            } else {
              console.error("[ScriptRunner] Job error:", ctx.dump(jobResult.error));
              break;
            }
            if (!pendingRequests.has(requestKey)) {
              console.log("[ScriptRunner] Request resolved after job execution");
              break;
            }
            await new Promise((r) => setTimeout(r, 10));
          }
        }
        if (pendingRequests.has(requestKey)) {
          console.log("[ScriptRunner] Request still pending after job loop, waiting for async resolution...");
          const requestTimeout = request.timeoutMs ?? 5e3;
          await new Promise((resolveWait) => {
            const waitTimeout = setTimeout(() => {
              console.warn("[ScriptRunner] Async resolution timeout");
              resolveWait();
            }, requestTimeout);
            const checkInterval = setInterval(() => {
              if (!pendingRequests.has(requestKey)) {
                clearTimeout(waitTimeout);
                clearInterval(checkInterval);
                resolveWait();
              }
            }, 50);
          });
        }
        if (pendingRequests.has(requestKey)) {
          try {
            const traceResult = ctx.evalCode(`JSON.stringify(globalThis.__trace || [])`);
            if (isSuccess(traceResult)) {
              this._trace = ctx.dump(traceResult.value);
              disposeResult(traceResult);
            }
            const errorsResult = ctx.evalCode(`JSON.stringify((globalThis.__caught_errors || []).map(function(e){return e.message.substring(0,200)}))`);
            if (isSuccess(errorsResult)) {
              this._caughtErrors = ctx.dump(errorsResult.value);
              disposeResult(errorsResult);
            }
          } catch (_te) {
          }
          pendingRequests.delete(requestKey);
          clearTimeout(timeoutId);
          reject(new Error("Script did not return a valid response"));
        }
      } catch (e) {
        console.error("[ScriptRunner] Request error:", e.message);
        pendingRequests.delete(requestKey);
        clearTimeout(timeoutId);
        reject(e);
      }
    });
  }
  async correctLxMusicSign(source, songId, quality, originalUrl) {
    const ctx = this.ctx;
    console.log(`[SignFix] Dynamic sign correction for ${source}/${songId}/${quality}`);
    const upstreamBase = "https://88.lxmusic.xn--fiqs8s/lxmusicv4/url";
    const cacheKey = `sign:${source}:${songId}:${quality}`;
    try {
      if (this.cacheKv) {
        const cached = await this.cacheKv.get(cacheKey);
        if (cached) {
          console.log(`[SignFix] \u2705 KV Cache HIT for ${cacheKey}`);
          return `${upstreamBase}/${source}/${songId}/${quality}?sign=${cached}`;
        }
      }
    } catch (_e) {
    }
    try {
      const crypto2 = globalThis.crypto;
      if (crypto2?.subtle) {
        const encoder = new TextEncoder();
        const candidates = [
          // Common patterns found in LX Music source scripts
          `${source}${songId}${quality}`,
          `${source}/${songId}/${quality}`,
          `/lxmusicv4/url/${source}/${songId}/${quality}`,
          `${upstreamBase}/${source}/${songId}/${quality}`,
          `lxmusic${source}${songId}${quality}`,
          songId + quality,
          quality + songId,
          JSON.stringify({ s: source, id: songId, q: quality }),
          // With potential secret prefixes used by lx-music-source scripts
          `lxmusic-${source}-${songId}-${quality}`,
          `lx.v4.${source}.${songId}.${quality}`
        ];
        for (const input of candidates) {
          const data = encoder.encode(input);
          const hashBuffer = await crypto2.subtle.digest("SHA-256", data);
          const hashArray = Array.from(new Uint8Array(hashBuffer));
          const sign = hashArray.map((b) => b.toString(16).padStart(2, "0")).join("");
          const testUrl = `${upstreamBase}/${source}/${songId}/${quality}?sign=${sign}`;
          try {
            const testResp = await fetch(testUrl, { method: "GET", signal: AbortSignal.timeout(2e3) });
            if (testResp.status === 200) {
              console.log(`[SignFix] \u{1F389} Brute force FOUND match! Input="${input}" Caching to KV...`);
              try {
                await this.cacheKv?.put(cacheKey, sign, { expirationTtl: 86400 * 7 });
              } catch {
              }
              return testUrl;
            }
          } catch (_e) {
          }
        }
      }
    } catch (e) {
      console.log("[SignFix] Brute force error:", e.message);
    }
    console.log(`[SignFix] \u274C No correct sign for ${cacheKey} (KV miss, brute force failed)`);
    return null;
  }
  async learnSign(source, songId, quality, correctSign) {
    const cacheKey = `sign:${source}:${songId}:${quality}`;
    try {
      await this.cacheKv?.put(cacheKey, correctSign, { expirationTtl: 86400 * 30 });
      console.log(`[SignFix] Learned & cached: ${cacheKey} = ${correctSign}`);
    } catch (e) {
      console.error("[SignFix] Failed to cache sign:", e.message);
    }
  }
  async handleForceInitDelegate(respData, pending) {
    try {
      const errMsg = respData.errorMessage || "";
      const delegateJson = errMsg.replace("__FORCE_INIT_DELEGATE__:", "");
      const delegateData = JSON.parse(delegateJson);
      const { source, action, type, songmid, name, singer } = delegateData;
      console.log(`[ScriptRunner:Builtin] \u{1F3B5} Delegate request: source=${source}, action=${action}, type=${type}, songmid=${songmid}, name=${name}, singer=${singer}`);
      if (action === "musicUrl") {
        try {
          const url = await this._builtinGetMusicUrl(source, type, songmid, name, singer);
          console.log(`[ScriptRunner:Builtin] \u2705 Got URL for ${source}:`, url ? url.substring(0, 80) + "..." : "null");
          pending.resolve(url);
        } catch (fetchErr) {
          console.error(`[ScriptRunner:Builtin] \u274C Fetch/API error: ${fetchErr.message}`);
          pending.reject(fetchErr);
        }
      } else if (action === "lyric") {
        pending.reject(new Error("Builtin lyric not yet implemented"));
      } else if (action === "pic") {
        pending.reject(new Error("Builtin pic not yet implemented"));
      } else {
        pending.reject(new Error(`Unknown builtin action: ${action}`));
      }
    } catch (e) {
      console.error("[ScriptRunner:Builtin] \u274C Delegate parse error:", e.message);
      pending.reject(e);
    }
  }
  async _builtinGetMusicUrl(source, quality, songmid, name, singer) {
    const sourceHandlers = {
      kg: () => this._builtinKgUrl(quality, songmid, name, singer),
      kw: () => this._builtinKwUrl(quality, songmid, name, singer),
      wy: () => this._builtinWyUrl(quality, songmid, name, singer),
      mg: () => this._builtinMgUrl(quality, songmid, name, singer),
      tx: () => this._builtinTxUrl(quality, songmid, name, singer)
    };
    const handler = sourceHandlers[source];
    if (!handler) throw new Error(`Builtin unsupported source: ${source}`);
    try {
      return await handler();
    } catch (primaryErr) {
      console.warn(`[ScriptRunner:Builtin] \u26A0\uFE0F Source "${source}" failed: ${primaryErr.message}, trying cross-source fallback...`);
      const fallbackOrder = ["kw", "kg", "wy", "mg", "tx"].filter((s) => s !== source);
      for (const fbSource of fallbackOrder) {
        const fbHandler = sourceHandlers[fbSource];
        if (!fbHandler) continue;
        try {
          console.log(`[ScriptRunner:Builtin] \u{1F504} Trying fallback source: ${fbSource}`);
          const url = await fbHandler();
          console.log(`[ScriptRunner:Builtin] \u2705 Fallback to "${fbSource}" succeeded!`);
          return url;
        } catch (fbErr) {
          console.warn(`[ScriptRunner:Builtin] \u26A0\uFE0F Fallback "${fbSource}" also failed: ${fbErr.message}`);
        }
      }
      throw new Error(`All sources failed for "${name} - ${singer}". Primary: ${primaryErr.message}`);
    }
  }
  async _builtinKgUrl(quality, songmid, name, singer) {
    const qualityMap = { "128k": "128", "320k": "320", "flac": "flac", "flac24bit": "flac24bit" };
    const q = qualityMap[quality] || "128";
    console.log(`[ScriptRunner:Builtin:kg] \u{1F50D} Searching for "${name} - ${singer}" on kugou...`);
    const keyword = encodeURIComponent(`${name} ${singer}`);
    const searchEndpoints = [
      `http://msearchcdn.kugou.com/api/v3/search/song?format=json&keyword=${keyword}&page=1&pagesize=5`,
      `http://songsearch.kugou.com/song_search_v2?keyword=${keyword}&page=1&pagesize=5&userid=-1&clientver=&platform=WebFilter&tag=em&filter=2&iscorrection=1&privilege_filter=0`
    ];
    let hash = "";
    let albumId = "0";
    let searchError = null;
    for (let i = 0; i < searchEndpoints.length && !hash; i++) {
      const searchUrl = searchEndpoints[i];
      console.log(`[ScriptRunner:Builtin:kg] Trying search endpoint ${i + 1}: ${searchUrl.substring(0, 80)}...`);
      try {
        const searchResp = await fetch(searchUrl, {
          headers: { "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36" }
        });
        console.log(`[ScriptRunner:Builtin:kg] Search response status: ${searchResp.status}`);
        if (!searchResp.ok) {
          const errText = await searchResp.text().catch(() => "");
          console.log(`[ScriptRunner:Builtin:kg] Search HTTP error: ${searchResp.status} ${errText.substring(0, 100)}`);
          continue;
        }
        const searchData = await searchResp.json();
        console.log(`[ScriptRunner:Builtin:kg] Search parsed OK, status=${searchData.status || searchData.err_code}`);
        let songs = [];
        if (searchData?.data?.info && Array.isArray(searchData.data.info)) {
          songs = searchData.data.info;
        } else if (searchData?.data?.lists && Array.isArray(searchData.data.lists)) {
          songs = searchData.data.lists;
        }
        if (songs.length > 0) {
          const best = songs.find((s) => (s.songname_original === name || s.SongName === name) && (s.singername === singer || s.SingerName === singer)) || songs.find((s) => s.songname === name || s.SongName === name) || songs.find((s) => s.songname_original?.includes(name) || s.SongName?.includes(name)) || songs[0];
          hash = best.hash || best.FileHash || "";
          albumId = String(best.album_id || best.AlbumID || best.albumID || "0");
          const foundName = best.songname || best.songname_original || best.SongName || "?";
          const foundSinger = best.singername || best.SingerName || "?";
          console.log(`[ScriptRunner:Builtin:kg] \u2705 Found: "${foundName}" - "${foundSinger}", hash=${hash ? hash.substring(0, 16) : "null"}, albumId=${albumId}`);
        } else {
          console.log(`[ScriptRunner:Builtin:kg] \u26A0\uFE0F No results from endpoint ${i + 1}, keys=`, Object.keys(searchData).join(","));
        }
      } catch (stepErr) {
        searchError = stepErr.message;
        console.error(`[ScriptRunner:Builtin:kg] \u274C Search endpoint ${i + 1} failed:`, stepErr.message);
      }
    }
    if (!hash) {
      throw new Error(`kg: cannot find song "${name} - ${singer}" (${searchError || "no results"})`);
    }
    const timestamp = Date.now();
    const playEndpoints = [
      {
        url: `https://wwwapi.kugou.com/yy/index.php?r=play/getdata&hash=${encodeURIComponent(hash)}&album_id=${albumId}&mid=1_1&_=${timestamp}`,
        headers: { "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36", "Referer": "https://www.kugou.com/", "Origin": "https://www.kugou.com" }
      },
      {
        url: `https://www.kugou.com/yy/index.php?r=play/getdata&hash=${encodeURIComponent(hash)}&album_id=${albumId}&mid=1_1&dfid=-`,
        headers: { "User-Agent": "Mozilla/5.0 (iPhone; CPU iPhone OS 16_0 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/16.0 Mobile/15E148 Safari/604.1", "Referer": "https://m.kugou.com/" }
      }
    ];
    console.log(`[ScriptRunner:Builtin:kg] \u{1F3B5} Fetching play URL (hash=${hash.substring(0, 16)}..., full_hash=${hash})...`);
    for (let i = 0; i < playEndpoints.length; i++) {
      const ep = playEndpoints[i];
      console.log(`[ScriptRunner:Builtin:kg] Trying play endpoint ${i + 1}...`);
      try {
        const resp = await fetch(ep.url, { headers: ep.headers });
        console.log(`[ScriptRunner:Builtin:kg] Play API ${i + 1} HTTP status: ${resp.status}`);
        if (!resp.ok) {
          const errText = await resp.text().catch(() => "");
          console.log(`[ScriptRunner:Builtin:kg] Play ${i + 1} HTTP error: ${resp.status}`);
          continue;
        }
        const json = await resp.json();
        console.log(`[ScriptRunner:Builtin:kg] Play ${i + 1} result: status=${json.status}, err_code=${json.err_code}, has_play_url=${!!json.data?.play_url}`);
        if (json.data?.play_url) {
          return json.data.play_url;
        }
        if (i < playEndpoints.length - 1) continue;
        throw new Error(`kg play API no url: status=${json.status}, err_code=${json.err_code}`);
      } catch (fetchErr) {
        console.error(`[ScriptRunner:Builtin:kg] \u274C Play ${i + 1} error:`, fetchErr.message);
        if (i === playEndpoints.length - 1) throw fetchErr;
      }
    }
    throw new Error("kg: all play endpoints failed");
  }
  async _builtinKwUrl(quality, songmid, name, singer) {
    console.log(`[ScriptRunner:Builtin:kw] \u{1F50D} Searching for "${name} - ${singer}" on kuwo...`);
    const keyword = encodeURIComponent(`${name} ${singer}`);
    const searchUrl = `http://search.kuwo.cn/r.s?all=${keyword}&ft=music&itemset=web_2013&client=kt&pn=0&rn=5&rformat=json&encoding=utf8`;
    try {
      const searchResp = await fetch(searchUrl, {
        headers: { "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36", "Referer": "http://www.kuwo.cn/" }
      });
      console.log(`[ScriptRunner:Builtin:kw] Search HTTP status: ${searchResp.status}`);
      if (!searchResp.ok) throw new Error(`Search HTTP ${searchResp.status}`);
      const searchText = await searchResp.text();
      const searchData = JSON.parse(searchText.replace(/'/g, '"'));
      console.log(`[ScriptRunner:Builtin:kw] Search total: ${searchData.TOTAL || searchData.HIT}`);
      let ridNum = "";
      if (searchData?.abslist && searchData.abslist.length > 0) {
        const songs = searchData.abslist;
        const best = songs.find((s) => s.SONGNAME === name && s.ARTIST === singer) || songs.find((s) => s.SONGNAME === name) || songs.find((s) => s.SONGNAME?.includes(name)) || songs[0];
        const rid = best.MUSICRID || "";
        ridNum = rid.replace("MUSIC_", "").replace("MP3_", "");
        console.log(`[ScriptRunner:Builtin:kw] \u2705 Found: "${best.SONGNAME}" - ${best.ARTIST}, rid=${rid}`);
      }
      if (!ridNum) throw new Error(`kw: cannot find song "${name} - ${singer}"`);
      console.log(`[ScriptRunner:Builtin:kw] \u{1F3B5} Getting play URL via proxy (rid=${ridNum})...`);
      const proxyUrl = `https://api.nobb.cc/kuwo.music/?id=${ridNum}`;
      const proxyResp = await fetch(proxyUrl, {
        headers: { "User-Agent": "Mozilla/5.0" }
      });
      console.log(`[ScriptRunner:Builtin:kw] Proxy HTTP status: ${proxyResp.status}`);
      const proxyData = await proxyResp.json();
      console.log(`[ScriptRunner:Builtin:kw] Proxy result code=${proxyData.code}, has_url=${!!proxyData.url}`);
      if (proxyData.code === 200 && proxyData.url) {
        return proxyData.url;
      }
      throw new Error(`kw proxy error: code=${proxyData.code}, msg=${proxyData.message || "no url"}`);
    } catch (e) {
      console.error(`[ScriptRunner:Builtin:kw] \u274C Error:`, e.message);
      throw e;
    }
  }
  async _builtinWyUrl(quality, songmid, name, singer) {
    throw new Error("wy source not yet implemented");
  }
  async _builtinMgUrl(quality, songmid, name, singer) {
    throw new Error("mg source not yet implemented");
  }
  async _builtinTxUrl(quality, songmid, name, singer) {
    throw new Error("tx source not yet implemented");
  }
  async _executeRealHttpRequest(reqData) {
    const ctx = this.ctx;
    const url = reqData.url;
    const options = reqData.options || {};
    const requestKey = reqData.requestKey;
    console.log(`[ScriptRunner:HTTP] \u{1F680} Executing real HTTP ${options.method || "GET"} ${url?.substring(0, 200)}`);
    this._lastHttpRequestUrl = url?.substring(0, 500);
    if (url && (url.includes("hibai.cn") || url.includes("sixyin.com"))) {
      console.log(`[ScriptRunner:HTTP] \u{1F3AD} Intercepting hibai/sixyin request, injecting mock success SYNCHRONOUSLY`);
      try {
        const mockBodyStr = JSON.stringify({ success: true, data: { version: "1.0.0", sources: ["kw", "kg", "tx", "wy", "mg"], updateUrl: "", message: "" } });
        const mockBodyBytes = new TextEncoder().encode(mockBodyStr);
        const respObj = { statusCode: 200, statusMessage: "OK", headers: {}, bytes: mockBodyBytes.length, raw: Array.from(mockBodyBytes), body: JSON.parse(mockBodyStr) };
        const callbackData = JSON.stringify({ requestKey, url, response: respObj, error: null });
        const safeData = callbackData.replace(/\\/g, "\\\\").replace(/'/g, "\\'").replace(/\n/g, "\\n");
        disposeResult(ctx.evalCode(`__lx_native__('cf_worker_key','response','${safeData}')`));
        console.log("[ScriptRunner:HTTP] \u{1F3AD} Mock response injected synchronously into QuickJS");
        if (ctx.runtime) {
          for (let i = 0; i < 30; i++) {
            try {
              const jobResult = ctx.runtime.executePendingJobs();
              if (isSuccess(jobResult) && (jobResult.value || 0) === 0) break;
            } catch (_e) {
            }
          }
        }
        console.log("[ScriptRunner:HTTP] \u{1F3AD} Mock response processed, returning to script execution");
      } catch (e) {
        console.error("[ScriptRunner:HTTP] Mock error:", e);
      }
      return;
    }
    try {
      const method = (options.method || "get").toLowerCase();
      const timeout = typeof options.response_timeout === "number" && options.response_timeout > 0 ? Math.min(options.response_timeout, 6e4) : 3e4;
      const followMax = options.follow_max ?? 5;
      const controller = new AbortController();
      const timeoutId = setTimeout(() => controller.abort(), timeout);
      let headers = { ...options.headers || {} };
      if (method === "get" && headers["Content-Type"]) {
        delete headers["Content-Type"];
      }
      const buildFetchOptions = () => {
        const fetchOptions = {
          method,
          headers,
          signal: controller.signal,
          redirect: "manual"
        };
        if (options.body) {
          fetchOptions.body = options.body;
        } else if (options.form) {
          const formDataObj = new URLSearchParams();
          for (const key in options.form) {
            formDataObj.append(key, options.form[key]);
          }
          fetchOptions.body = formDataObj.toString();
          fetchOptions.headers = { ...headers, "Content-Type": "application/x-www-form-urlencoded" };
        } else if (options.formData) {
          const formDataObj = new FormData();
          for (const key in options.formData) {
            formDataObj.append(key, options.formData[key]);
          }
          fetchOptions.body = formDataObj;
        }
        return fetchOptions;
      };
      const doFetch = async (currentUrl, redirectCount) => {
        console.log(`[ScriptRunner:HTTP] \u2192 Fetching: ${currentUrl?.substring(0, 120)} (redirect #${redirectCount})`);
        const response2 = await fetch(currentUrl, buildFetchOptions());
        if (response2.status >= 300 && response2.status < 400 && response2.headers.has("location")) {
          if (redirectCount >= followMax) {
            throw new Error(`Maximum redirect count (${followMax}) exceeded`);
          }
          const newUrl = response2.headers.get("location");
          const resolvedUrl = newUrl.startsWith("http") ? newUrl : new URL(newUrl, currentUrl).href;
          return doFetch(resolvedUrl, redirectCount + 1);
        }
        return response2;
      };
      const LXMUSIC_URL_PATTERN = /lxmusicv[0-9]*\/url\/([^\/]+)\/([^\/]+)\/([^/?]+)/;
      const urlMatch = url.match(LXMUSIC_URL_PATTERN);
      console.log(`[SignFix] URL matching check: url=${url?.substring(0, 80)}..., match=${!!urlMatch}, urlType=${typeof url}`);
      let response;
      if (urlMatch) {
        console.log(`[SignFix] Detected lxmusic URL, fetching directly...`);
        response = await doFetch(url, 0);
        clearTimeout(timeoutId);
        if (response.status === 404) {
          console.log(`[SignFix] Got 404, sign may be incorrect. URL: ${url.substring(0, 200)}`);
        }
      } else {
        response = await doFetch(url, 0);
        clearTimeout(timeoutId);
      }
      const responseBody = await response.arrayBuffer();
      const rawUint8Array = new Uint8Array(responseBody);
      const rawString = new TextDecoder().decode(responseBody);
      let body = rawString;
      try {
        body = JSON.parse(rawString);
      } catch (_e) {
      }
      const headersObj = {};
      if (typeof response.headers.forEach === "function") {
        response.headers.forEach((value, key) => {
          headersObj[key] = value;
        });
      } else {
        Object.assign(headersObj, response.headers || {});
      }
      const respObj = {
        statusCode: response.status,
        statusMessage: response.statusText,
        headers: headersObj,
        bytes: responseBody.byteLength,
        raw: Array.from(rawUint8Array),
        body
      };
      console.log(`[ScriptRunner:HTTP] \u2705 Response: ${response.status} ${response.statusText}, URL: ${url}, body length: ${rawString.length}, preview: ${rawString.substring(0, 200)}`);
      if (this._keyLogs) this._keyLogs.push("[ScriptRunner] [HTTP-RESP] status=" + response.status + " url=" + (url || "").substring(0, 150) + " bodyLen=" + rawString.length + " preview=" + rawString.substring(0, 150));
      const callbackData = JSON.stringify({
        requestKey,
        url,
        response: respObj,
        error: null
      });
      try {
        const safeCallbackData = callbackData.replace(/\\/g, "\\\\").replace(/'/g, "\\'").replace(/\n/g, "\\n");
        disposeResult(ctx.evalCode(`__lx_native__('cf_worker_key', 'response', '${safeCallbackData}')`));
        console.log("[ScriptRunner:HTTP] Response fed back to QuickJS");
        if (ctx.runtime) {
          for (let i = 0; i < 50; i++) {
            const jobResult = ctx.runtime.executePendingJobs();
            if (isSuccess(jobResult)) {
              if ((jobResult.value || 0) === 0) break;
            } else {
              console.error("[ScriptRunner:HTTP] Pending job error after response:", ctx.dump(jobResult.error));
              break;
            }
          }
        }
      } catch (_e) {
        console.warn("[ScriptRunner:HTTP] Could not call QuickJS callback");
      }
    } catch (error) {
      console.error(`[ScriptRunner:HTTP] \u274C Error fetching ${url?.substring(0, 100)}:`, error.message);
      if (this._keyLogs) this._keyLogs.push("[ScriptRunner] [HTTP-ERR] url=" + (url || "").substring(0, 150) + " error=" + (error.message || "unknown"));
      const errorData = JSON.stringify({
        requestKey,
        url,
        response: null,
        error: error.message || "Network error"
      });
      try {
        const safeErrorData = errorData.replace(/\\/g, "\\\\").replace(/'/g, "\\'");
        disposeResult(ctx.evalCode(`__lx_native__('cf_worker_key', 'response', '${safeErrorData}')`));
      } catch (_e) {
        console.warn("[ScriptRunner:HTTP] Could not report error to QuickJS");
      }
    }
  }
  async _processPendingHttpRequests(maxRounds = 10) {
    const ctx = this.ctx;
    const pendingHttpRequests = this._pendingHttpRequests;
    for (let round = 0; round < maxRounds; round++) {
      if (pendingHttpRequests.length === 0) break;
      const requests = [...pendingHttpRequests];
      pendingHttpRequests.length = 0;
      console.log(`[ScriptRunner] _processHttpRequests round ${round + 1}: processing ${requests.length} request(s)`);
      for (const httpReq of requests) {
        const reqKey = httpReq.requestKey;
        const url = httpReq.url;
        const options = httpReq.options || {};
        try {
          const method = (options.method || "get").toLowerCase();
          const timeout = Math.min(options.timeout || 6e4, 6e4);
          const controller = new AbortController();
          const tid = setTimeout(() => controller.abort(), timeout);
          let headers = { ...options.headers };
          if (method === "get" && headers["Content-Type"]) delete headers["Content-Type"];
          let body = void 0;
          if (options.body) body = options.body;
          else if (options.form) {
            body = new URLSearchParams(options.form).toString();
            headers["Content-Type"] = "application/x-www-form-urlencoded";
          }
          console.log(`[ScriptRunner] Fetching: ${url?.substring(0, 100)} key: ${reqKey}`);
          const resp = await fetch(url, { method, headers, body, signal: controller.signal });
          clearTimeout(tid);
          const respBody = await resp.text();
          let parsedBody = respBody;
          try {
            parsedBody = JSON.parse(respBody);
          } catch (_e) {
          }
          const headersObj = {};
          resp.headers.forEach((v, k) => {
            headersObj[k] = v;
          });
          const responseData = JSON.stringify({
            requestKey: reqKey,
            error: null,
            response: { statusCode: resp.status, statusMessage: resp.statusText, headers: headersObj, body: parsedBody }
          });
          const safeRespData = responseData.replace(/\\/g, "\\\\").replace(/'/g, "\\'");
          disposeResult(ctx.evalCode(`__lx_native__('cf_worker_key', 'response', '${safeRespData}')`));
          console.log(`[ScriptRunner] Fetched OK: ${resp.status} bodyLen: ${respBody.length}`);
        } catch (fetchErr) {
          console.error(`[ScriptRunner] Fetch error for ${url?.substring(0, 50)}: ${fetchErr.message}`);
          const errData = JSON.stringify({ requestKey: reqKey, error: fetchErr.message, response: null });
          const safeErrData = errData.replace(/\\/g, "\\\\").replace(/'/g, "\\'");
          disposeResult(ctx.evalCode(`__lx_native__('cf_worker_key', 'response', '${safeErrData}')`));
        }
      }
      if (ctx.runtime) {
        for (let i = 0; i < 50; i++) {
          const jobResult = ctx.runtime.executePendingJobs();
          if (isSuccess(jobResult)) {
            if ((jobResult.value || 0) === 0) break;
          } else {
            console.error("[ScriptRunner] _processHttpRequests pending job error:", ctx.dump(jobResult.error));
            break;
          }
        }
      }
    }
    if (pendingHttpRequests.length > 0) {
      console.warn(`[ScriptRunner] _processHttpRequests: ${pendingHttpRequests.length} request(s) still pending after max rounds`);
    }
  }
  getPolyfillSetup() {
    return `(function() {
'use strict';
if(typeof globalThis.window==='undefined') globalThis.window=globalThis;
if(typeof globalThis.self==='undefined') globalThis.self=globalThis;
if(typeof globalThis.top==='undefined') globalThis.top=globalThis;
if(typeof globalThis.parent==='undefined') globalThis.parent=globalThis;
if(typeof globalThis.global==='undefined') globalThis.global=globalThis;
globalThis.document=globalThis.document||{owner:null,readyState:'complete',cookie:'',referrer:'',domain:'localhost',location:{href:'https://localhost/',protocol:'https:',host:'localhost'},createElement:function(tag){var el={tagName:tag.toUpperCase(),nodeName:tag.toUpperCase(),style:{},className:'',innerHTML:'',innerText:'',textContent:'',outerHTML:'',children:[],childNodes:[],firstChild:null,lastChild:null,nextSibling:null,previousSibling:null,parentNode:null,parentElement:null,ownerDocument:globalThis.document,owner:null,nodeType:1,setAttribute:function(k,v){this[k]=v},getAttribute:function(k){return this[k]||null},removeAttribute:function(k){delete this[k]},appendChild:function(c){this.children.push(c);c.parentNode=this;return c},removeChild:function(c){var i=this.children.indexOf(c);if(i>=0)this.children.splice(i,1);return c},insertBefore:function(n,r){var i=this.children.indexOf(r);if(i>=0)this.children.splice(i,0,n);else this.children.push(n);n.parentNode=this;return n},addEventListener:function(){},removeEventListener:function(){},dispatchEvent:function(){return true},getElementsByClassName:function(){return[]},getElementsByTagName:function(){return[]},querySelector:function(){return null},querySelectorAll:function(){return[]},classList:{add:function(){},remove:function(){},contains:function(){return false},toggle:function(){}}};if(tag==='canvas'){el.getContext=function(){return{fillRect:function(){},clearRect:function(){},getImageData:function(x,y,w,h){return{data:new Uint8Array(w*h*4)}},putImageData:function(){},createImageData:function(){return{data:new Uint8Array(0)}},setTransform:function(){},drawImage:function(){},save:function(){},fillText:function(){},restore:function(){},beginPath:function(){},moveTo:function(){},lineTo:function(){},closePath:function(){},stroke:function(){},translate:function(){},scale:function(){},rotate:function(){},arc:function(){},fill:function(){},measureText:function(){return{width:0}}}};el.toDataURL=function(){return'data:image/png;base64,'}}if(tag==='input'||tag==='textarea'){el.value='';el.focus=function(){};el.blur=function(){}}if(tag==='form'){el.submit=function(){}}if(tag==='script'){el.src=''}return el},getElementById:function(){return null},getElementsByTagName:function(){return[]},getElementsByClassName:function(){return[]},querySelector:function(){return null},querySelectorAll:function(){return[]},addEventListener:function(){},removeEventListener:function(){},dispatchEvent:function(){return true},createEvent:function(){return{initEvent:function(){},preventDefault:function(){},stopPropagation:function(){}}},documentElement:{nodeName:'HTML',owner:null,nodeType:9,style:{}},body:{appendChild:function(){return null},removeChild:function(){return null},owner:null,nodeType:1,style:{}},head:{appendChild:function(){return null},removeChild:function(){return null},owner:null,nodeType:1,style:{}},createTextNode:function(t){return{textContent:t,nodeType:3,owner:null,parentNode:null}},createComment:function(t){return{textContent:t,nodeType:8,owner:null}},createDocumentFragment:function(){return{children:[],appendChild:function(c){this.children.push(c);return c},owner:null,nodeType:11}},createRange:function(){return{selectNode:function(){},collapse:function(){},getBoundingClientRect:function(){return{top:0,left:0,bottom:0,right:0,width:0,height:0}}}},implementation:{hasFeature:function(){return true},createHTMLDocument:function(){return globalThis.document}}};
globalThis.navigator=globalThis.navigator||{userAgent:'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36',platform:'Win32',language:'zh-CN',languages:['zh-CN','zh','en-US','en'],onLine:true,cookieEnabled:true,hardwareConcurrency:8,deviceMemory:8,maxTouchPoints:0,vendor:'Google Inc.',appName:'Netscape',appVersion:'5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36',product:'Gecko',productSub:'20030107',userAgentData:{brands:[{brand:'Not_A Brand',version:'8'},{brand:'Chromium',version:'120'}],mobile:false,platform:'Windows'},connection:{effectiveType:'4g',downlink:10,rtt:50},mediaDevices:{enumerateDevices:function(){return Promise.resolve([])}},permissions:{query:function(){return Promise.resolve({state:'granted'})}},clipboard:{readText:function(){return Promise.resolve('')},writeText:function(){return Promise.resolve()}},getBattery:function(){return Promise.resolve({charging:true,chargingTime:0,dischargingTime:Infinity,level:1})},getGamepads:function(){return[]},sendBeacon:function(){return true},webkitGetUserMedia:function(){},mimeTypes:{length:0},plugins:{length:0}};
globalThis.location=globalThis.location||{href:'https://localhost/',protocol:'https:',host:'localhost',hostname:'localhost',origin:'https://localhost',port:'',pathname:'/',search:'',hash:''};
globalThis.screen=globalThis.screen||{width:1920,height:1080,colorDepth:24,pixelDepth:24,availWidth:1920,availHeight:1040,orientation:{type:'landscape-primary',angle:0}};
globalThis.history=globalThis.history||{length:1,pushState:function(){},replaceState:function(){},go:function(){},back:function(){},forward:function(){}};
globalThis.localStorage=globalThis.localStorage||{getItem:function(){return null},setItem:function(){},removeItem:function(){},clear:function(){},length:0};
globalThis.sessionStorage=globalThis.sessionStorage||{getItem:function(){return null},setItem:function(){},removeItem:function(){},clear:function(){},length:0};
if(typeof globalThis.crypto==='undefined'||!globalThis.crypto.getRandomValues){
  var _cryptoRng=function(){var _s=Date.now();return function(){_s=(_s*9301+49297)%233280;return _s/233280}};
  globalThis.crypto={getRandomValues:function(arr){if(arr instanceof Uint8Array){for(var i=0;i<arr.length;i++)arr[i]=Math.floor(Math.random()*256)}else if(arr instanceof Uint16Array){for(var i=0;i<arr.length;i++)arr[i]=Math.floor(Math.random()*65536)}else if(arr instanceof Uint32Array){for(var i=0;i<arr.length;i++)arr[i]=Math.floor(Math.random()*4294967296)}else if(Array.isArray(arr)){for(var i=0;i<arr.length;i++)arr[i]=Math.floor(Math.random()*256)}return arr},randomUUID:function(){return'xxxxxxxx-xxxx-4xxx-yxxx-xxxxxxxxxxxx'.replace(/[xy]/g,function(c){var r=Math.random()*16|0;return(c==='x'?r:(r&0x3|0x8)).toString(16)})},subtle:{digest:function(algo,data){return new Promise(function(resolve,reject){try{var algoName=typeof algo==='string'?algo:algo.name;var dataStr='';if(typeof data==='string'){dataStr=data}else if(data instanceof ArrayBuffer||data instanceof Uint8Array){var bytes=new Uint8Array(data);for(var i=0;i<bytes.length;i++)dataStr+=String.fromCharCode(bytes[i])}console.log('[Polyfill] crypto.subtle.digest called, algo='+algoName+', dataLen='+dataStr.length);var hexResult=__lx_native__('cf_worker_key','sha256_compute',dataStr);console.log('[Polyfill] crypto.subtle.digest result, hexLen='+(hexResult?hexResult.length:0)+', hexPrefix='+(hexResult?hexResult.substring(0,16):'null'));var ab=new ArrayBuffer(hexResult.length/2);var view=new Uint8Array(ab);for(var i=0;i<hexResult.length;i+=2)view[i/2]=parseInt(hexResult.substr(i,2),16);resolve(ab)}catch(e){console.log('[Polyfill] crypto.subtle.digest ERROR: '+e.message);reject(e)}})},importKey:function(){return Promise.resolve({})},exportKey:function(){return Promise.resolve(new ArrayBuffer(0))},encrypt:function(){return Promise.resolve(new ArrayBuffer(0))},decrypt:function(){return Promise.resolve(new ArrayBuffer(0))},sign:function(){return Promise.resolve(new ArrayBuffer(0))},verify:function(){return Promise.resolve(false)},generateKey:function(){return Promise.resolve({})},deriveBits:function(){return Promise.resolve(new ArrayBuffer(0))},deriveKey:function(){return Promise.resolve({})}}};
}
if(typeof globalThis.performance==='undefined'){
  var _perfStart=Date.now();
  globalThis.performance={now:function(){return Date.now()-_perfStart},mark:function(){},measure:function(){},getEntries:function(){return[]},getEntriesByName:function(){return[]},getEntriesByType:function(){return[]},clearMarks:function(){},clearMeasures:function(){},timeOrigin:_perfStart};
}
if(typeof TextEncoder==='undefined'){globalThis.TextEncoder=function(){this.encode=function(s){var bytes=[];for(var i=0;i<s.length;i++){var c=s.charCodeAt(i);if(c<128)bytes.push(c);else if(c<2048){bytes.push((c>>6)|192);bytes.push((c&63)|128)}else{bytes.push((c>>12)|224);bytes.push(((c>>6)&63)|128);bytes.push((c&63)|128)}}return new Uint8Array(bytes)}}}
if(typeof TextDecoder==='undefined'){globalThis.TextDecoder=function(){this.decode=function(arr){var s='';for(var i=0;i<arr.length;i++)s+=String.fromCharCode(arr[i]);return s}}}
if(typeof btoa==='undefined'){globalThis.btoa=function(str){var chars='ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/=';var output='';for(var i=0;i<str.length;i+=3){var b1=str.charCodeAt(i);var b2=i+1<str.length?str.charCodeAt(i+1):0;var b3=i+2<str.length?str.charCodeAt(i+2):0;output+=chars.charAt(b1>>2)+chars.charAt(((b1&3)<<4)|(b2>>4))+(i+1<str.length?chars.charAt(((b2&15)<<2)|(b3>>6)):'=')+(i+2<str.length?chars.charAt(b3&63):'=')}return output}}
if(typeof atob==='undefined'){globalThis.atob=function(b64){var chars='ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/=';var output='';var i=0;b64=b64.replace(/[^A-Za-z0-9\\+\\/\\=]/g,'');while(i<b64.length){var e1=chars.indexOf(b64.charAt(i++));var e2=chars.indexOf(b64.charAt(i++));var e3=chars.indexOf(b64.charAt(i++));var e4=chars.indexOf(b64.charAt(i++));output+=String.fromCharCode((e1<<2)|(e2>>4))+(e3!==64?String.fromCharCode(((e2&15)<<4)|(e3>>2)):'')+(e4!==64?String.fromCharCode(((e3&3)<<6)|e4):'')}return output}}
if(typeof globalThis.XMLHttpRequest==='undefined'){
  globalThis.XMLHttpRequest=function(){this.readyState=0;this.status=0;this.statusText='';this.responseText='';this.responseXML=null;this.response=null;this.responseType='';this.withCredentials=false;this.timeout=0;this.onreadystatechange=null;this.onload=null;this.onerror=null;this.onabort=null;this.ontimeout=null;this.onprogress=null;this.upload={addEventListener:function(){}};this._headers={};this._method='GET';this._url='';this._async=true;this._aborted=false};
  globalThis.XMLHttpRequest.prototype.open=function(method,url,async){this._method=method;this._url=url;this._async=async!==false;this.readyState=1};
  globalThis.XMLHttpRequest.prototype.send=function(body){var self=this;this.readyState=2;if(this._url){globalThis.lx.request(this._url,{method:this._method,body:body,headers:this._headers},function(err,resp,respBody){if(self._aborted)return;if(err){self.readyState=4;self.status=0;if(self.onerror)self.onerror(err)}else{self.readyState=4;self.status=resp?resp.statusCode:0;self.statusText=resp?resp.statusMessage:'';self.responseText=typeof respBody==='string'?respBody:(respBody?JSON.stringify(respBody):'');self.response=self.responseText;if(self.onload)self.onload()}if(self.onreadystatechange)self.onreadystatechange()})}else{this.readyState=4;this.status=0;if(this.onerror)this.onerror(new Error('No URL'))}};
  globalThis.XMLHttpRequest.prototype.abort=function(){this._aborted=true;this.readyState=4;if(this.onabort)this.onabort()};
  globalThis.XMLHttpRequest.prototype.setRequestHeader=function(k,v){this._headers[k]=v};
  globalThis.XMLHttpRequest.prototype.getResponseHeader=function(){return null};
  globalThis.XMLHttpRequest.prototype.getAllResponseHeaders=function(){return''};
  globalThis.XMLHttpRequest.prototype.addEventListener=function(type,fn){this['on'+type]=fn};
  globalThis.XMLHttpRequest.prototype.removeEventListener=function(){};
  globalThis.XMLHttpRequest.prototype.overrideMimeType=function(){};
}
if(typeof globalThis.URL==='undefined'){
  globalThis.URL=function(url,base){this.href=url;this.protocol='';this.host='';this.hostname='';this.port='';this.pathname='';this.search='';this.hash='';this.origin='';try{var m=url.match(new RegExp('^(https?:)\\\\/\\\\/([^\\\\/:]+)(:\\\\d+)?([^?#]*)(\\\\?[^#]*)?(#.*)?$'));if(m){this.protocol=m[1];this.hostname=m[2];this.port=m[3]?m[3].slice(1):'';this.host=this.hostname+(this.port?':'+this.port:'');this.pathname=m[4]||'/';this.search=m[5]||'';this.hash=m[6]||'';this.origin=this.protocol+'//'+this.host}}catch(e){}};
  globalThis.URL.createObjectURL=function(){return'blob:null'};
  globalThis.URL.revokeObjectURL=function(){};
}
if(typeof globalThis.URLSearchParams==='undefined'){
  globalThis.URLSearchParams=function(init){this._params=[];if(typeof init==='string'){if(init.charAt(0)==='?')init=init.slice(1);init.split('&').forEach(function(pair){var idx=pair.indexOf('=');if(idx>=0)this._params.push([decodeURIComponent(pair.slice(0,idx)),decodeURIComponent(pair.slice(idx+1))]);else if(pair)this._params.push([decodeURIComponent(pair),''])}.bind(this))}};
  globalThis.URLSearchParams.prototype.get=function(name){for(var i=0;i<this._params.length;i++){if(this._params[i][0]===name)return this._params[i][1]}return null};
  globalThis.URLSearchParams.prototype.set=function(name,value){var found=false;for(var i=0;i<this._params.length;i++){if(this._params[i][0]===name){this._params[i][1]=value;found=true;break}}if(!found)this._params.push([name,value])};
  globalThis.URLSearchParams.prototype.has=function(name){for(var i=0;i<this._params.length;i++){if(this._params[i][0]===name)return true}return false};
  globalThis.URLSearchParams.prototype.append=function(name,value){this._params.push([name,value])};
  globalThis.URLSearchParams.prototype.toString=function(){return this._params.map(function(p){return encodeURIComponent(p[0])+'='+encodeURIComponent(p[1])}).join('&')};
  globalThis.URLSearchParams.prototype.forEach=function(fn){this._params.forEach(function(p){fn(p[1],p[0])})};
}
if(typeof globalThis.Headers==='undefined'){
  globalThis.Headers=function(init){this._map={};if(init&&typeof init==='object'){if(init instanceof Array){init.forEach(function(pair){this._map[pair[0].toLowerCase()]=pair[1]}.bind(this))}else{Object.keys(init).forEach(function(k){this._map[k.toLowerCase()]=init[k]}.bind(this))}}};
  globalThis.Headers.prototype.get=function(name){return this._map[name.toLowerCase()]||null};
  globalThis.Headers.prototype.set=function(name,value){this._map[name.toLowerCase()]=value};
  globalThis.Headers.prototype.has=function(name){return name.toLowerCase()in this._map};
  globalThis.Headers.prototype.delete=function(name){delete this._map[name.toLowerCase()]};
  globalThis.Headers.prototype.append=function(name,value){this._map[name.toLowerCase()]=value};
  globalThis.Headers.prototype.forEach=function(fn){var self=this;Object.keys(this._map).forEach(function(k){fn(self._map[k],k)})};
}
if(typeof globalThis.FormData==='undefined'){
  globalThis.FormData=function(){this._data=[]};
  globalThis.FormData.prototype.append=function(name,value){this._data.push([name,value])};
  globalThis.FormData.prototype.get=function(name){for(var i=0;i<this._data.length;i++){if(this._data[i][0]===name)return this._data[i][1]}return null};
  globalThis.FormData.prototype.has=function(name){for(var i=0;i<this._data.length;i++){if(this._data[i][0]===name)return true}return false};
}
if(typeof globalThis.Blob==='undefined'){
  globalThis.Blob=function(parts,options){this.size=0;this.type=(options&&options.type)||'';var data=[];if(parts){parts.forEach(function(p){if(typeof p==='string'){for(var i=0;i<p.length;i++)data.push(p.charCodeAt(i))}else if(p instanceof Uint8Array||Array.isArray(p)){data=data.concat(Array.from(p))}})}this.size=data.length;this._data=data;this.arrayBuffer=function(){return Promise.resolve(new Uint8Array(data).buffer)};this.text=function(){var s='';for(var i=0;i<data.length;i++)s+=String.fromCharCode(data[i]);return Promise.resolve(s)};this.slice=function(start,end){return new Blob([new Uint8Array(data.slice(start,end))],{type:this.type})}};
}
if(typeof globalThis.File==='undefined'){
  globalThis.File=function(parts,name,options){Blob.call(this,parts,options);this.name=name;this.lastModified=Date.now()};
  globalThis.File.prototype=Object.create(Blob.prototype);
}
if(typeof globalThis.FileReader==='undefined'){
  globalThis.FileReader=function(){this.readyState=0;this.result=null;this.onload=null;this.onerror=null;this.readAsText=function(blob){var self=this;this.readyState=2;this.result=blob.text?blob.text():'';if(this.onload)setTimeout(function(){self.onload({target:self})},0)};this.readAsArrayBuffer=function(blob){var self=this;this.readyState=2;this.result=blob.arrayBuffer?blob.arrayBuffer():new ArrayBuffer(0);if(this.onload)setTimeout(function(){self.onload({target:self})},0)};this.readAsDataURL=function(blob){var self=this;this.readyState=2;this.result='data:'+blob.type+';base64,'+btoa(String.fromCharCode.apply(null,blob._data||[]));if(this.onload)setTimeout(function(){self.onload({target:self})},0)}};
}
if(typeof globalThis.AbortController==='undefined'){
  globalThis.AbortController=function(){this.signal={aborted:false,_listeners:[],addEventListener:function(type,fn){this._listeners.push(fn)},removeEventListener:function(){},throwIfAborted:function(){if(this.aborted)throw new Error('AbortError')}};this.abort=function(){this.signal.aborted=true;this.signal._listeners.forEach(function(fn){fn()})}};
  globalThis.AbortSignal=function(){this.aborted=false;this._listeners=[];this.addEventListener=function(type,fn){this._listeners.push(fn)};this.removeEventListener=function(){};this.throwIfAborted=function(){if(this.aborted)throw new Error('AbortError')}};
  globalThis.AbortSignal.abort=function(){var s=new AbortSignal();s.aborted=true;return s};
  globalThis.AbortSignal.timeout=function(ms){var s=new AbortSignal();setTimeout(function(){s.aborted=true;s._listeners.forEach(function(fn){fn()})},ms);return s};
}
if(typeof globalThis.Event==='undefined'){
  globalThis.Event=function(type,opts){this.type=type;this.bubbles=(opts&&opts.bubbles)||false;this.cancelable=(opts&&opts.cancelable)||false;this.defaultPrevented=false;this.target=null;this.currentTarget=null;this.timeStamp=Date.now()};
  globalThis.Event.prototype.preventDefault=function(){this.defaultPrevented=true};
  globalThis.Event.prototype.stopPropagation=function(){};
  globalThis.Event.prototype.stopImmediatePropagation=function(){};
}
if(typeof globalThis.CustomEvent==='undefined'){
  globalThis.CustomEvent=function(type,opts){Event.call(this,type,opts);this.detail=(opts&&opts.detail)||null};
  globalThis.CustomEvent.prototype=Object.create(Event.prototype);
}
if(typeof globalThis.EventTarget==='undefined'){
  globalThis.EventTarget=function(){this._listeners={}};
  globalThis.EventTarget.prototype.addEventListener=function(type,fn){if(!this._listeners[type])this._listeners[type]=[];this._listeners[type].push(fn)};
  globalThis.EventTarget.prototype.removeEventListener=function(type,fn){if(this._listeners[type]){var i=this._listeners[type].indexOf(fn);if(i>=0)this._listeners[type].splice(i,1)}};
  globalThis.EventTarget.prototype.dispatchEvent=function(event){event.target=this;event.currentTarget=this;if(this._listeners[event.type]){this._listeners[event.type].forEach(function(fn){fn(event)})}return!event.defaultPrevented};
}
if(typeof globalThis.DOMParser==='undefined'){
  globalThis.DOMParser=function(){};
  globalThis.DOMParser.prototype.parseFromString=function(str,type){return globalThis.document};
}
if(typeof globalThis.MutationObserver==='undefined'){
  globalThis.MutationObserver=function(cb){this._cb=cb};
  globalThis.MutationObserver.prototype.observe=function(){};
  globalThis.MutationObserver.prototype.disconnect=function(){};
  globalThis.MutationObserver.prototype.takeRecords=function(){return[]};
}
if(typeof globalThis.IntersectionObserver==='undefined'){
  globalThis.IntersectionObserver=function(cb){this._cb=cb};
  globalThis.IntersectionObserver.prototype.observe=function(){};
  globalThis.IntersectionObserver.prototype.disconnect=function(){};
  globalThis.IntersectionObserver.prototype.unobserve=function(){};
}
if(typeof globalThis.ResizeObserver==='undefined'){
  globalThis.ResizeObserver=function(cb){this._cb=cb};
  globalThis.ResizeObserver.prototype.observe=function(){};
  globalThis.ResizeObserver.prototype.disconnect=function(){};
  globalThis.ResizeObserver.prototype.unobserve=function(){};
}
if(typeof globalThis.requestAnimationFrame==='undefined'){
  globalThis.requestAnimationFrame=function(cb){return globalThis.setTimeout(cb,16)};
  globalThis.requestAnimationFrame=function(cb){return globalThis.setTimeout(cb,16)};
  globalThis.cancelAnimationFrame=function(id){globalThis.clearTimeout(id)};
}
if(typeof globalThis.queueMicrotask==='undefined'){
  globalThis.queueMicrotask=function(cb){Promise.resolve().then(cb)};
}
if(typeof globalThis.structuredClone==='undefined'){
  globalThis.structuredClone=function(obj){return JSON.parse(JSON.stringify(obj))};
}
if(typeof globalThis.MessageChannel==='undefined'){
  globalThis.MessageChannel=function(){this.port1={postMessage:function(){},onmessage:null,close:function(){}};this.port2={postMessage:function(){},onmessage:null,close:function(){}}};
}
if(typeof globalThis.Worker==='undefined'){
  globalThis.Worker=function(url){this.onmessage=null;this.onerror=null;this.postMessage=function(){};this.terminate=function(){};this.addEventListener=function(){}};
}
if(typeof globalThis.Image==='undefined'){
  globalThis.Image=function(){this.src='';this.onload=null;this.onerror=null;this.width=0;this.height=0;this.naturalWidth=0;this.naturalHeight=0};
}
if(typeof globalThis.Audio==='undefined'){
  globalThis.Audio=function(){this.src='';this.onload=null;this.onerror=null};
}
globalThis.require=function(moduleName){
  console.log('[Polyfill] require() called: '+moduleName);
  if(moduleName==='crypto'){
    return{
      createCipheriv:function(){return{update:function(){return this},final:function(){return''}}},
      createDecipheriv:function(){return{update:function(){return this},final:function(){return''}}},
      randomBytes:function(s){var r=[];for(var i=0;i<s;i++)r.push(Math.floor(Math.random()*256));return r},
      createHash:function(algo){
        var data='';
        console.log('[Polyfill] require("crypto").createHash called, algo='+algo);
        return{
          update:function(d,enc){
            if(typeof d==='string'){
              if(enc==='base64'){var b=atob(d);data+=b}
              else if(enc==='hex'){var b='';for(var i=0;i<d.length;i+=2)b+=String.fromCharCode(parseInt(d.substr(i,2),16));data+=b}
              else{data+=d}
            }else if(d instanceof Uint8Array||Array.isArray(d)){
              for(var i=0;i<d.length;i++)data+=String.fromCharCode(d[i])
            }
            return this
          },
          digest:function(enc){
            console.log('[Polyfill] createHash.digest called, algo='+algo+', dataLen='+data.length+', enc='+enc+', dataPreview='+JSON.stringify(data.substring(0,100)));
            var h;
            if(algo==='md5'){h=__lx_native__('cf_worker_key','md5_compute',data)}
            else{h=__lx_native__('cf_worker_key','sha256_compute',data)}
            console.log('[Polyfill] createHash.digest result, hexLen='+(h?h.length:0)+', hexPrefix='+(h?h.substring(0,16):'null'));
            if(enc==='hex')return h;
            if(enc==='base64'){var bytes=[];for(var i=0;i<h.length;i+=2)bytes.push(parseInt(h.substr(i,2),16));return btoa(String.fromCharCode.apply(null,bytes))}
            var bytes=[];for(var i=0;i<h.length;i+=2)bytes.push(parseInt(h.substr(i,2),16));return new Uint8Array(bytes)
          }
        }
      },
      publicEncrypt:function(){return''},
      constants:{RSA_NO_PADDING:4,OAEPWithSHA1AndMGF1Padding:''}
    }
  }
  if(moduleName==='buffer'){
    return{
      Buffer:{
        from:function(i,e){
          if(typeof i==='string'){
            if(e==='base64'){var b=atob(i);var r=new Uint8Array(b.length);for(var j=0;j<b.length;j++)r[j]=b.charCodeAt(j);return r}
            if(e==='hex'){var r=new Uint8Array(i.length/2);for(var j=0;j<i.length;j+=2)r[j/2]=parseInt(i.substr(j,2),16);return r}
            var r=new Uint8Array(i.length);for(var j=0;j<r.length;j++)r[j]=i.charCodeAt(j);return r
          }
          if(Array.isArray(i))return new Uint8Array(i);
          if(i instanceof Uint8Array)return i;
          throw new Error('Unsupported input')
        },
        alloc:function(s){return new Uint8Array(s)}
      }
    }
  }
  if(moduleName==='zlib')return{inflate:function(b){return b},deflate:function(b){return b}};
  if(moduleName==='http'||moduleName==='https'||moduleName==='net'||moduleName==='tls'||moduleName==='fs'||moduleName==='path'||moduleName==='os'||moduleName==='stream'||moduleName==='events'||moduleName==='util'||moduleName==='url'||moduleName==='querystring'||moduleName==='child_process'){
    var _emptyMod={on:function(){return _emptyMod},once:function(){return _emptyMod},emit:function(){return true},pipe:function(){return _emptyMod},write:function(){return true},end:function(){return _emptyMod},destroy:function(){return _emptyMod},read:function(){return null},close:function(){},createServer:function(){return _emptyMod},connect:function(){return _emptyMod},listen:function(){return _emptyMod}};
    return _emptyMod;
  }
  console.warn('[Polyfill] require("'+moduleName+'") - returning empty object');
  return{}
};
if(typeof globalThis.Buffer==='undefined'){
  globalThis.Buffer={
    from:function(input,encoding){
      if(typeof input==='string'){
        if(encoding==='base64'){var b=atob(input);var r=new Uint8Array(b.length);for(var i=0;i<b.length;i++)r[i]=b.charCodeAt(i);return r}
        if(encoding==='hex'){var r=new Uint8Array(input.length/2);for(var i=0;i<input.length;i+=2)r[i/2]=parseInt(input.substr(i,2),16);return r}
        if(encoding==='binary'){var r=new Uint8Array(input.length);for(var i=0;i<input.length;i++)r[i]=input.charCodeAt(i);return r}
        var r=new Uint8Array(input.length);for(var i=0;i<input.length;i++)r[i]=input.charCodeAt(i);return r
      }
      if(Array.isArray(input))return new Uint8Array(input);
      if(input instanceof Uint8Array)return input;
      throw new Error('Unsupported Buffer.from input')
    },
    alloc:function(size){return new Uint8Array(size)},
    concat:function(list){var len=0;for(var i=0;i<list.length;i++)len+=list[i].length;var r=new Uint8Array(len);var off=0;for(var i=0;i<list.length;i++){r.set(list[i],off);off+=list[i].length}return r}
  }
}
if(typeof globalThis.process==='undefined'){globalThis.process={env:{},version:'v18.17.0',versions:{node:'18.17.0',v8:'10.2.154.26'},platform:'linux',arch:'x64',pid:1,ppid:0,title:'node',argv:['node'],execPath:'/usr/local/bin/node',cwd:function(){return'/'},nextTick:function(fn){Promise.resolve().then(fn)},emitWarning:function(){},binding:function(){return{}},hrtime:function(){var t=Date.now()*1e6;return[t/1e9|0,t%1e9]}}}

if(typeof globalThis.pako==='undefined'){globalThis.pako={inflate:function(d){return d},inflateRaw:function(d){return d},deflate:function(d){return d},gzip:function(d){return d},ungzip:function(d){return d}}}
if(typeof globalThis.fetch==='undefined'){
  globalThis.fetch=function(url,options){
    options=options||{};
    return new Promise(function(resolve,reject){
      var method=(options.method||'GET').toUpperCase();
      var reqHeaders={};
      if(options.headers){
        if(options.headers instanceof Map){options.headers.forEach(function(v,k){reqHeaders[k]=v})}
        else if(typeof options.headers==='object'){reqHeaders=options.headers}
      }
      if(method==='GET'&&reqHeaders['Content-Type'])delete reqHeaders['Content-Type'];
      var lxReqOpts={method:method,headers:reqHeaders,body:options.body||null,form:options.form||null,formData:options.formData||null,binary:options.binary||null};
      globalThis.lx.request(url,lxReqOpts,function(err,resp,body){
        if(err){reject(new Error('fetch error: '+(err.message||String(err))));return}
        var bodyStr='';
        if(typeof body==='string')bodyStr=body;
        else if(body&&typeof body==='object'){try{bodyStr=JSON.stringify(body)}catch(e){bodyStr=String(body)}}
        else bodyStr=body?String(body):'';
        var respHeaders=new Map();
        if(resp&&resp.headers){try{Object.keys(resp.headers).forEach(function(k){respHeaders.set(k,resp.headers[k])})}catch(e){}}
        resolve({
          ok:resp&&resp.statusCode>=200&&resp.statusCode<300,
          status:resp?resp.statusCode:0,
          statusText:resp?(resp.statusMessage||''):'',
          headers:respHeaders,
          url:url,
          text:function(){return Promise.resolve(bodyStr)},
          json:function(){return Promise.resolve(JSON.parse(bodyStr))},
          arrayBuffer:function(){var bytes=new Uint8Array(bodyStr.length);for(var i=0;i<bodyStr.length;i++)bytes[i]=bodyStr.charCodeAt(i);return Promise.resolve(bytes.buffer)}
        })
      })
    })
  }
}
if(typeof globalThis.Proxy==='undefined'){
  globalThis.Proxy=function(target,handler){
    if(!handler)return target;
    if(typeof target==='function'){
      var fn=function(){
        var args=Array.prototype.slice.call(arguments);
        if(handler.apply){try{return handler.apply(target,this,args)}catch(e){return target.apply(this,args)}}
        return target.apply(this,args);
      };
      fn.__target=target;
      fn.__handler=handler;
      for(var k in target){if(target.hasOwnProperty(k)){(function(key){Object.defineProperty(fn,key,{get:function(){if(handler.get)try{return handler.get(target,key,fn)}catch(e){return target[key]}return target[key]},set:function(v){if(handler.set)try{handler.set(target,key,v,fn)}catch(e){target[key]=v}target[key]=v},configurable:true,enumerable:true})})(k)}}
      return fn;
    }
    if(typeof target==='object'&&target!==null){
      var result={};
      var keys=Object.getOwnPropertyNames(target);
      for(var i=0;i<keys.length;i++){(function(key){Object.defineProperty(result,key,{get:function(){if(handler.get)try{return handler.get(target,key,result)}catch(e){return target[key]}return target[key]},set:function(v){if(handler.set)try{handler.set(target,key,v,result)}catch(e){target[key]=v}target[key]=v},configurable:true,enumerable:true})})(keys[i])}
      return result;
    }
    return target;
  };
  globalThis.Proxy.revocable=function(target,handler){return{proxy:new Proxy(target,handler),revoke:function(){}}};
}
if(typeof globalThis.Reflect==='undefined'){
  globalThis.Reflect={apply:function(target,thisArg,args){return target.apply(thisArg,args)},construct:function(target,args){return new(Function.prototype.bind.apply(target,[null].concat(args)))},get:function(target,prop){return target[prop]},set:function(target,prop,value){target[prop]=value;return true},has:function(target,prop){return prop in target},deleteProperty:function(target,prop){delete target[prop];return true},ownKeys:function(target){return Object.keys(target)},getOwnPropertyDescriptor:function(target,prop){return Object.getOwnPropertyDescriptor(target,prop)},defineProperty:function(target,prop,desc){Object.defineProperty(target,prop,desc);return true},getPrototypeOf:function(target){return Object.getPrototypeOf(target)},setPrototypeOf:function(target,proto){Object.setPrototypeOf(target,proto);return true},isExtensible:function(target){return Object.isExtensible(target)},preventExtensions:function(target){Object.preventExtensions(target);return true}};
}
var _origFnToString=Function.prototype.toString;
var _nativeFnRegistry=[];
var _makeNative=function(name,fn){try{_nativeFnRegistry.push([fn,name])}catch(e){}return fn};
var _nativeObjToString=function(name,obj){if(!obj)return obj;if(typeof obj==='function'){try{_nativeFnRegistry.push([obj,name])}catch(e){}}else if(typeof obj==='object'&&obj!==null){Object.keys(obj).forEach(function(k){if(typeof obj[k]==='function'){try{_nativeFnRegistry.push([obj[k],k])}catch(e){}}})}return obj};
Function.prototype.toString=function(){
  try{for(var i=0;i<_nativeFnRegistry.length;i++){if(_nativeFnRegistry[i][0]===this)return'function '+_nativeFnRegistry[i][1]+'() { [native code] }'}}catch(e){}
  try{return _origFnToString.call(this)}catch(e){return'function () { [native code] }'}
};
if(globalThis.fetch)globalThis.fetch=_makeNative('fetch',globalThis.fetch);
if(globalThis.XMLHttpRequest)_nativeObjToString('XMLHttpRequest',globalThis.XMLHttpRequest);
if(globalThis.crypto)_nativeObjToString('crypto',globalThis.crypto);
if(globalThis.TextEncoder)globalThis.TextEncoder=_makeNative('TextEncoder',globalThis.TextEncoder);
if(globalThis.TextDecoder)globalThis.TextDecoder=_makeNative('TextDecoder',globalThis.TextDecoder);
if(globalThis.btoa)globalThis.btoa=_makeNative('btoa',globalThis.btoa);
if(globalThis.atob)globalThis.atob=_makeNative('atob',globalThis.atob);
if(globalThis.URL)globalThis.URL=_makeNative('URL',globalThis.URL);
if(globalThis.URLSearchParams)globalThis.URLSearchParams=_makeNative('URLSearchParams',globalThis.URLSearchParams);
if(globalThis.Headers)globalThis.Headers=_makeNative('Headers',globalThis.Headers);
if(globalThis.FormData)globalThis.FormData=_makeNative('FormData',globalThis.FormData);
if(globalThis.Blob)globalThis.Blob=_makeNative('Blob',globalThis.Blob);
if(globalThis.File)globalThis.File=_makeNative('File',globalThis.File);
if(globalThis.FileReader)globalThis.FileReader=_makeNative('FileReader',globalThis.FileReader);
if(globalThis.AbortController)globalThis.AbortController=_makeNative('AbortController',globalThis.AbortController);
if(globalThis.Event)globalThis.Event=_makeNative('Event',globalThis.Event);
if(globalThis.CustomEvent)globalThis.CustomEvent=_makeNative('CustomEvent',globalThis.CustomEvent);
if(globalThis.EventTarget)globalThis.EventTarget=_makeNative('EventTarget',globalThis.EventTarget);
if(globalThis.DOMParser)globalThis.DOMParser=_makeNative('DOMParser',globalThis.DOMParser);
if(globalThis.MutationObserver)globalThis.MutationObserver=_makeNative('MutationObserver',globalThis.MutationObserver);
if(globalThis.requestAnimationFrame)globalThis.requestAnimationFrame=_makeNative('requestAnimationFrame',globalThis.requestAnimationFrame);
if(globalThis.cancelAnimationFrame)globalThis.cancelAnimationFrame=_makeNative('cancelAnimationFrame',globalThis.cancelAnimationFrame);
if(globalThis.queueMicrotask)globalThis.queueMicrotask=_makeNative('queueMicrotask',globalThis.queueMicrotask);
if(globalThis.structuredClone)globalThis.structuredClone=_makeNative('structuredClone',globalThis.structuredClone);
if(globalThis.performance)_nativeObjToString('performance',globalThis.performance);
if(globalThis.navigator)_nativeObjToString('navigator',globalThis.navigator);
if(globalThis.document)_nativeObjToString('document',globalThis.document);
if(globalThis.history)_nativeObjToString('history',globalThis.history);
if(globalThis.localStorage)_nativeObjToString('localStorage',globalThis.localStorage);
if(globalThis.sessionStorage)_nativeObjToString('sessionStorage',globalThis.sessionStorage);
if(globalThis.screen)_nativeObjToString('screen',globalThis.screen);
if(globalThis.location)_nativeObjToString('location',globalThis.location);
if(globalThis.require)globalThis.require=_makeNative('require',globalThis.require);
if(globalThis.Buffer)_nativeObjToString('Buffer',globalThis.Buffer);
if(globalThis.process)_nativeObjToString('process',globalThis.process);
if(globalThis.pako)_nativeObjToString('pako',globalThis.pako);
(function() {
  var _origBind = Function.prototype.bind;
  Function.prototype.bind = function() {
    if (this === globalThis || this === window || this === self) {
      var actionArg = null;
      for (var i = 0; i < arguments.length; i++) {
        if (typeof arguments[i] === 'string' && arguments[i].indexOf('Handle Action') === 0) {
          actionArg = arguments[i];
          break;
        }
      }
      console.log('[BIND-FIX] bind called on globalThis, actionArg=' + actionArg);
      if (actionArg) {
        var actionMatch = actionArg.match(/Handle Action\\((\\w+)\\)/);
        if (actionMatch) {
          var actionName = actionMatch[1];
          var handlerMap = {
            'musicUrl': 'handleGetMusicUrl',
            'musicPic': 'handleGetMusicPic',
            'musicLyric': 'handleGetMusicLyric'
          };
          var handlerName = handlerMap[actionName];
          if (handlerName && typeof globalThis[handlerName] === 'function') {
            console.log('[BIND-FIX] Redirecting to ' + handlerName);
            return _origBind.apply(globalThis[handlerName], arguments);
          }
        }
      }
      console.log('[BIND-FIX] No handler found for actionArg=' + actionArg + ', returning identity bind');
      var self = this;
      return function() { return self; };
    }
    return _origBind.apply(this, arguments);
  };
})();
console.log('Polyfill setup complete.');
})()`;
  }
  isReady() {
    return this.isInitialized;
  }
  getDiagnostics() {
    const ctx = this.ctx;
    if (!ctx) return { error: "no context" };
    try {
      return {
        envDiag: this._envDiag || null,
        scriptLogs: this._logMessages ? this._logMessages.slice(0, 50) : null,
        keyLogs: this._keyLogs ? this._keyLogs.slice(-80) : null,
        isInitialized: this.isInitialized,
        registeredSources: Array.from(this.registeredSources.keys()),
        hasRequestHandler: !!this.requestHandler,
        lastRequestMusicInfo: this._lastRequestMusicInfo || null,
        preDiag: this._preDiag || null,
        lastHttpRequestUrl: this._lastHttpRequestUrl || null,
        trace: this._trace || null,
        caughtErrors: this._caughtErrors || null
      };
    } catch (e) {
      return { error: e.message };
    }
  }
  dispose() {
    if (this.ctx) {
      try {
        this.ctx.dispose();
      } catch (_e) {
        console.warn("[ScriptRunner] Dispose warning:", _e);
      }
      this.ctx = null;
    }
    this.isInitialized = false;
  }
  getRegisteredSources() {
    return this.registeredSources;
  }
  getRegisteredSourceList() {
    return Array.from(this.registeredSources.keys());
  }
  supportsSource(source) {
    return this.registeredSources.has(source);
  }
  async terminate() {
    console.log("[ScriptRunner] Terminating script:", this.scriptInfo.name);
    this.registeredSources.clear();
    this.requestHandler = null;
    this.isInitialized = false;
  }
};

// src/utils/aes.ts
var SBOX = [99, 124, 119, 123, 242, 107, 111, 197, 48, 1, 103, 43, 254, 215, 171, 118, 202, 130, 201, 125, 250, 89, 71, 240, 173, 212, 162, 175, 156, 164, 114, 192, 183, 253, 147, 38, 54, 63, 247, 204, 52, 165, 229, 241, 113, 216, 49, 21, 4, 199, 35, 195, 24, 150, 5, 154, 7, 18, 128, 226, 235, 39, 178, 117, 9, 131, 44, 26, 27, 110, 90, 160, 82, 59, 214, 179, 41, 227, 47, 132, 83, 209, 0, 237, 32, 252, 177, 91, 106, 203, 190, 57, 74, 76, 88, 207, 208, 239, 170, 251, 67, 77, 51, 133, 69, 249, 2, 127, 80, 60, 159, 168, 81, 163, 64, 143, 146, 157, 56, 245, 188, 182, 218, 33, 16, 255, 243, 210, 205, 12, 19, 236, 95, 151, 68, 23, 196, 167, 126, 61, 100, 93, 25, 115, 96, 129, 79, 220, 34, 42, 144, 136, 70, 238, 184, 20, 222, 94, 11, 219, 224, 50, 58, 10, 73, 6, 36, 92, 194, 211, 172, 98, 145, 149, 228, 121, 231, 200, 55, 109, 141, 213, 78, 169, 108, 86, 244, 234, 101, 122, 174, 8, 186, 120, 37, 46, 28, 166, 180, 198, 232, 221, 116, 31, 75, 189, 139, 138, 112, 62, 181, 102, 72, 3, 246, 14, 97, 53, 87, 185, 134, 193, 29, 158, 225, 248, 152, 17, 105, 217, 142, 148, 155, 30, 135, 233, 206, 85, 40, 223, 140, 161, 137, 13, 191, 230, 66, 104, 65, 153, 45, 15, 176, 84, 187, 22];
var RCON = [0, 1, 2, 4, 8, 16, 32, 64, 128, 27, 54];
function gmul(a, b) {
  let p = 0;
  for (let i = 0; i < 8; i++) {
    if (b & 1) p ^= a;
    const hi = a & 128;
    a <<= 1;
    if (hi) a ^= 27;
    b >>= 1;
  }
  return p & 255;
}
function keyExpansion(key) {
  const Nk = 4;
  const Nr = 10;
  const w = [];
  for (let i = 0; i < Nk; i++) {
    w[i] = new Uint8Array([key[4 * i], key[4 * i + 1], key[4 * i + 2], key[4 * i + 3]]);
  }
  for (let i = Nk; i < 4 * (Nr + 1); i++) {
    let temp = new Uint8Array(w[i - 1]);
    if (i % Nk === 0) {
      const t = temp[0];
      temp[0] = temp[1];
      temp[1] = temp[2];
      temp[2] = temp[3];
      temp[3] = t;
      for (let j = 0; j < 4; j++) temp[j] = SBOX[temp[j]];
      temp[0] ^= RCON[i / Nk];
    }
    w[i] = new Uint8Array(4);
    for (let j = 0; j < 4; j++) w[i][j] = w[i - Nk][j] ^ temp[j];
  }
  return w;
}
function expandKey(key) {
  const w = keyExpansion(key);
  const roundKeys = [];
  for (let i = 0; i <= 10; i++) {
    roundKeys[i] = new Uint8Array(16);
    for (let j = 0; j < 4; j++) for (let k = 0; k < 4; k++) roundKeys[i][j * 4 + k] = w[i * 4 + j][k];
  }
  return roundKeys;
}
function addRoundKey(state, roundKey) {
  for (let i = 0; i < 16; i++) state[i] ^= roundKey[i];
}
function subBytes(state) {
  for (let i = 0; i < 16; i++) state[i] = SBOX[state[i]];
}
function shiftRows(state) {
  const t = new Uint8Array(16);
  t[0] = state[0];
  t[1] = state[5];
  t[2] = state[10];
  t[3] = state[15];
  t[4] = state[4];
  t[5] = state[9];
  t[6] = state[14];
  t[7] = state[3];
  t[8] = state[8];
  t[9] = state[13];
  t[10] = state[2];
  t[11] = state[7];
  t[12] = state[12];
  t[13] = state[1];
  t[14] = state[6];
  t[15] = state[11];
  state.set(t);
}
function mixColumns(state) {
  for (let i = 0; i < 4; i++) {
    const s0 = state[i * 4], s1 = state[i * 4 + 1], s2 = state[i * 4 + 2], s3 = state[i * 4 + 3];
    state[i * 4] = gmul(2, s0) ^ gmul(3, s1) ^ s2 ^ s3;
    state[i * 4 + 1] = s0 ^ gmul(2, s1) ^ gmul(3, s2) ^ s3;
    state[i * 4 + 2] = s0 ^ s1 ^ gmul(2, s2) ^ gmul(3, s3);
    state[i * 4 + 3] = gmul(3, s0) ^ s1 ^ s2 ^ gmul(2, s3);
  }
}
function encryptBlock(input, roundKeys) {
  const state = new Uint8Array(input);
  addRoundKey(state, roundKeys[0]);
  for (let r = 1; r < 10; r++) {
    subBytes(state);
    shiftRows(state);
    mixColumns(state);
    addRoundKey(state, roundKeys[r]);
  }
  subBytes(state);
  shiftRows(state);
  addRoundKey(state, roundKeys[10]);
  return state;
}
function aesEncryptECB(data, key) {
  const roundKeys = expandKey(key);
  const bs = 16;
  const nb = Math.ceil(data.length / bs);
  const out = new Uint8Array(nb * bs);
  for (let i = 0; i < nb; i++) {
    const block = new Uint8Array(bs);
    const start = i * bs;
    const end = Math.min(start + bs, data.length);
    block.set(data.slice(start, end));
    if (end - start < bs) for (let j = end - start; j < bs; j++) block[j] = bs - (end - start);
    const enc = encryptBlock(block, roundKeys);
    out.set(enc, i * bs);
  }
  return out;
}

// src/services/search_service.ts
async function md5(text) {
  const data = new TextEncoder().encode(text);
  const hash = await crypto.subtle.digest("MD5", data);
  return Array.from(new Uint8Array(hash)).map((b) => b.toString(16).padStart(2, "0")).join("");
}
function pkcs7Pad(data) {
  const pad = 16 - data.length % 16;
  const result = new Uint8Array(data.length + (pad === 16 ? 0 : pad));
  result.set(data);
  for (let i = data.length; i < result.length; i++) result[i] = pad;
  return result;
}
function aesEcbEncryptPure(data, key) {
  const keyBytes = new TextEncoder().encode(key).slice(0, 16);
  const encrypted = aesEncryptECB(new Uint8Array(data), keyBytes);
  return encrypted.buffer;
}
function toHex(buffer) {
  return Array.from(new Uint8Array(buffer)).map((b) => b.toString(16).padStart(2, "0").toUpperCase()).join("");
}
var KuwoSearchService = class {
  async search(kw, p, l) {
    try {
      const url = `http://search.kuwo.cn/r.s?client=kt&all=${encodeURIComponent(kw)}&pn=${p - 1}&rn=${l}&uid=794762570&ver=kwplayer_ar_9.2.2.1&vipver=1&show_copyright_off=1&newver=1&ft=music&cluster=0&strategy=2012&encoding=utf8&rformat=json&vermerge=1&mobi=1&issubtitle=1`;
      const r = await fetch(url, { headers: { "User-Agent": "Mozilla/5.0", "Referer": "http://www.kuwo.cn" } });
      const d = await r.json();
      return { platform: "kw", results: (d.abslist || []).map((i) => ({
        id: String(i.MUSICRID).replace("MUSIC_", ""),
        name: i.NAME,
        singer: i.ARTIST,
        albumName: i.ALBUM || "",
        interval: i.DURATION ? Math.floor(i.DURATION / 60) + ":" + String(i.DURATION % 60).padStart(2, "0") : "00:00",
        source: "kw",
        songmid: String(i.MUSICRID).replace("MUSIC_", ""),
        img: i.albumpic?.replace("{size}", "100") || ""
      })) };
    } catch (e) {
      console.error("[KuwoSearch]", e);
      return { platform: "kw", results: [] };
    }
  }
};
var KugouSearchService = class {
  async search(kw, p, l) {
    try {
      const url = `http://msearchcdn.kugou.com/api/v3/search/song?format=json&keyword=${encodeURIComponent(kw)}&page=${p}&pagesize=${l}&showtype=1`;
      const r = await fetch(url, { headers: {
        "User-Agent": "Mozilla/5.0 (Linux; U; Android 11.0.0; zh-cn; MI 11 Build/OPR1.170623.032) AppleWebKit/534.30",
        "KG-RC": "1"
      } });
      const rawText = await r.text();
      if (!rawText.trim()) return { platform: "kg", results: [] };
      const d = JSON.parse(rawText);
      const info = d.data?.info || [];
      if (info.length > 0) return { platform: "kg", results: info.map((i) => ({
        id: i.album_id || "",
        name: i.songname || "",
        singer: i.singername || "",
        albumName: i.album_name || "",
        interval: i.duration ? Math.floor(i.duration / 60) + ":" + String(i.duration % 60).padStart(2, "0") : "00:00",
        source: "kg",
        hash: i.hash || "",
        img: ""
      })) };
      return { platform: "kg", results: [] };
    } catch (e) {
      console.error("[KugouSearch]", e);
      return { platform: "kg", results: [] };
    }
    ;
  }
};
var QQMusicSearchService = class {
  async search(kw, p, l) {
    try {
      const body = JSON.stringify({
        comm: { ct: "11", cv: "14090508", v: "14090508", tmeAppID: "qqmusic", phonetype: "EBG-AN10", deviceScore: "553.47", devicelevel: "50", newdevicelevel: "20", rom: "HuaWei/EMOTION/EmotionUI_14.2.0", os_ver: "12", OpenUDID: "0", OpenUDID2: "0", QIMEI36: "0", udid: "0", chid: "0", aid: "0", oaid: "0", taid: "0", tid: "0", wid: "0", uid: "0", sid: "0", modeSwitch: "6", teenMode: "0", ui_mode: "2", nettype: "1020", v4ip: "" },
        req: { module: "music.search.SearchCgiService", method: "DoSearchForQQMusicMobile", param: { search_type: 0, query: kw, page_num: p, num_per_page: l, highlight: 0, nqc_flag: 0, multi_zhida: 0, cat: 2, grp: 1, sin: 0, sem: 0 } }
      });
      const r = await fetch("https://u.y.qq.com/cgi-bin/musicu.fcg", { method: "POST", headers: { "User-Agent": "QQMusic 14090508(android 12)", "Content-Type": "application/json" }, body });
      const d = await r.json();
      const songs = (d?.req?.data?.body?.item_song || []).filter((i) => i && i.name && i.file?.media_mid);
      return { platform: "tx", results: songs.map((i) => ({
        id: String(i.id),
        name: (i.name || "") + (i.title_extra || ""),
        singer: i.singer?.map((s) => s.name).join("\u3001") || "",
        albumName: i.album?.name || "",
        interval: String(Math.floor((i.interval || 0) / 60)) + ":" + String((i.interval || 0) % 60).padStart(2, "0"),
        source: "tx",
        songmid: i.mid,
        img: i.album?.mid ? `https://y.gtimg.cn/music/photo_new/T002R500x500M000${i.album.mid}.jpg` : ""
      })) };
    } catch (e) {
      console.error("[QQMusicSearch]", e);
      return { platform: "tx", results: [] };
    }
  }
};
var NeteaseSearchService = class _NeteaseSearchService {
  static EAPI_KEY = "e82ckenh8dichen8";
  async search(kw, p, l) {
    try {
      const url = "/api/cloudsearch/pc";
      const text = JSON.stringify({ s: kw, type: 1, limit: l, total: p === 1, offset: l * (p - 1) });
      const message = `nobody${url}use${text}md5forencrypt`;
      const digest = await md5(message);
      const data = `${url}-36cd479b6b5-${text}-36cd479b6b5-${digest}`;
      const buf = new TextEncoder().encode(data);
      const padded = pkcs7Pad(buf);
      const encrypted = aesEcbEncryptPure(padded.buffer, _NeteaseSearchService.EAPI_KEY);
      const params = toHex(encrypted);
      const r = await fetch("http://interface.music.163.com/eapi/batch", { method: "POST", headers: { "User-Agent": "Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36", "Origin": "https://music.163.com", "Referer": "https://music.163.com/", "Content-Type": "application/x-www-form-urlencoded" }, body: `params=${params}` });
      const d = await r.json();
      const songs = d.result?.songs || [];
      return { platform: "wy", results: songs.map((i) => ({
        id: String(i.id),
        name: i.name,
        singer: i.ar?.map((a) => a.name).join("\u3001") || "",
        albumName: i.al?.name || "",
        interval: i.dt ? Math.floor(i.dt / 6e4) + ":" + String(Math.floor(i.dt / 1e3) % 60).padStart(2, "0") : "00:00",
        source: "wy",
        songmid: String(i.id),
        img: i.al?.picUrl || ""
      })) };
    } catch (e) {
      console.error("[NeteaseSearch]", e);
      return { platform: "wy", results: [] };
    }
  }
};
var MiguSearchService = class _MiguSearchService {
  static DEVICE_ID = "963B7AA0D21511ED807EE5846EC87D20";
  static SIGN_KEY = "6cdc72a439cef99a3418d2a78aa28c73";
  async search(kw, p, l) {
    try {
      const time = Date.now().toString();
      const sign = await md5(`${kw}${_MiguSearchService.SIGN_KEY}yyapp2d16148780a1dcc7408e06336b98cfd50${_MiguSearchService.DEVICE_ID}${time}`);
      const searchSwitch = encodeURIComponent(JSON.stringify({ song: 1, album: 0, singer: 0, tagSong: 1, mvSong: 0, bestShow: 1, songlist: 0, lyricSong: 0 }));
      const url = `https://jadeite.migu.cn/music_search/v3/search/searchAll?isCorrect=0&isCopyright=1&searchSwitch=${searchSwitch}&pageSize=${l}&text=${encodeURIComponent(kw)}&pageNo=${p}&sort=0&sid=USS`;
      const r = await fetch(url, {
        headers: { uiVersion: "A_music_3.6.1", deviceId: _MiguSearchService.DEVICE_ID, timestamp: time, sign, channel: "0146921", "User-Agent": "Mozilla/5.0 (Linux; U; Android 11.0.0; zh-cn; MI 11 Build/OPR1.170623.032) AppleWebKit/534.30" }
      });
      const d = await r.json();
      let results = [];
      const resultList = d.songResultData?.resultList || [];
      for (const group of resultList) {
        for (const data of group) {
          if (!data.songId || !data.copyrightId) continue;
          results.push({ id: String(data.copyrightId), name: data.name, singer: data.singerList?.map((s) => s.name).join("\u3001") || "", albumName: data.album || "", interval: data.duration || "00:00", source: "mg", copyrightId: String(data.copyrightId), img: data.img3 || data.img2 || data.img1 ? (/https?:/.test(data.img3 || "") ? data.img3 || data.img2 || data.img1 : `http://d.musicapp.migu.cn${data.img3 || data.img2 || data.img1}`) || "" : "" });
          if (results.length >= l) break;
        }
        if (results.length >= l) break;
      }
      return { platform: "mg", results };
    } catch (e) {
      console.error("[MiguSearch]", e);
      return { platform: "mg", results: [] };
    }
  }
};
var SearchService = class {
  kw = new KuwoSearchService();
  kg = new KugouSearchService();
  tx = new QQMusicSearchService();
  wy = new NeteaseSearchService();
  mg = new MiguSearchService();
  async search(keyword, source, page = 1, limit = 20) {
    if (!source) return Promise.all([this.kw.search(keyword, page, limit), this.kg.search(keyword, page, limit), this.tx.search(keyword, page, limit), this.wy.search(keyword, page, limit), this.mg.search(keyword, page, limit)]);
    switch (source) {
      case "kw":
        return [await this.kw.search(keyword, page, limit)];
      case "kg":
        return [await this.kg.search(keyword, page, limit)];
      case "tx":
        return [await this.tx.search(keyword, page, limit)];
      case "wy":
        return [await this.wy.search(keyword, page, limit)];
      case "mg":
        return [await this.mg.search(keyword, page, limit)];
      default:
        throw new Error("Unsupported source: " + source);
    }
  }
};

// src/services/shortlink_service.ts
var log = {
  debug: (...args) => console.log("[ShortLink]", ...args),
  info: (...args) => console.log("[ShortLink]", ...args),
  warn: (...args) => console.warn("[ShortLink]", ...args),
  error: (...args) => console.error("[ShortLink]", ...args)
};
var ShortLinkService = class _ShortLinkService {
  static DOMAIN_MAP = {
    "music.163.com": "wy",
    "y.qq.com": "tx",
    "i.y.qq.com": "tx",
    "c6.y.qq.com": "tx",
    "kugou.com": "kg",
    "kugou.kugou.com": "kg",
    "m.kugou.com": "kg",
    "www2.kugou.kugou.com": "kg",
    "kuwo.cn": "kw",
    "www.kuwo.cn": "kw",
    "m.kuwo.cn": "kw",
    "music.migu.cn": "mg",
    "m.music.migu.cn": "mg",
    "app.c.nf.migu.cn": "mg"
  };
  static REGEXPS = {
    wy: {
      listDetailLink: /^.+(?:\?|&)id=(\d+)(?:&.*$|#.*$|$)/,
      listDetailLink2: /^.+\/playlist\/(\d+)\/\d+\/.+$/
    },
    tx: {
      listDetailLink: /\/playlist\/(\d+)/,
      listDetailLink2: /[?&]id=(\d+)/
    },
    kg: {
      listDetailLink: /^.+\/(\d+)\.html(?:\?.*|&.*$|#.*$|$)/,
      chainLink: /chain=(\w+)/,
      globalCollectionId: /global_collection_id=(\w+)/
    },
    kw: {
      listDetailLink: /[?&]pid=(\d+)/,
      listDetailLink2: /\/playlist_detail\/(\d+)/
    },
    mg: {
      listDetailLink: /[?&]id=(\d+)/,
      listDetailLink2: /\/playlist\/(\d+)/
    }
  };
  async parseShortLink(link) {
    log.info("\u5F00\u59CB\u89E3\u6790\u77ED\u94FE\u63A5:", link);
    const result = this.extractUrl(link);
    if (result) {
      log.info("\u4ECEURL\u76F4\u63A5\u63D0\u53D6\u6210\u529F:", result);
      return result;
    }
    log.info("\u65E0\u6CD5\u76F4\u63A5\u63D0\u53D6\uFF0C\u5C1D\u8BD5\u83B7\u53D6\u91CD\u5B9A\u5411...");
    return this.resolveRedirect(link);
  }
  async extractIdFromUrl(url, source) {
    log.info(`\u4ECEURL\u63D0\u53D6ID, source: ${source}, url: ${url}`);
    if (source === "kg" && /^\d+$/.test(url)) {
      log.info("\u68C0\u6D4B\u5230\u9177\u72D7\u7801:", url);
      const listId = await this.getKugouListIdByCode(url);
      if (listId) {
        log.info("\u9177\u72D7\u7801\u89E3\u6790\u6210\u529F, \u6B4C\u5355ID:", listId);
        return listId;
      }
    }
    const id = this.extractIdBySource(url, source);
    if (id) {
      log.info("\u76F4\u63A5\u4ECEURL\u63D0\u53D6ID\u6210\u529F:", id);
      return id;
    }
    log.info("\u76F4\u63A5\u63D0\u53D6\u5931\u8D25\uFF0C\u5C1D\u8BD5\u83B7\u53D6\u91CD\u5B9A\u5411...");
    try {
      const response = await fetch(url, { method: "HEAD", redirect: "manual", headers: { "User-Agent": "Mozilla/5.0 (iPhone; CPU iPhone OS 13_2_3 like Mac OS X) AppleWebKit/605.1.15" } });
      if (response.status >= 500) {
        const getResponse = await fetch(url, { method: "GET", redirect: "manual", headers: { "User-Agent": "Mozilla/5.0 (iPhone; CPU iPhone OS 13_2_3 like Mac OS X) AppleWebKit/605.1.15" } });
        const location = getResponse.headers.get("location");
        if (location) {
          log.info("\u83B7\u53D6\u5230\u91CD\u5B9A\u5411\u5730\u5740:", location);
          const redirectId = this.extractIdBySource(location, source);
          if (redirectId) return redirectId;
        }
      } else {
        const location = response.headers.get("location");
        if (location) {
          log.info("\u83B7\u53D6\u5230\u91CD\u5B9A\u5411\u5730\u5740:", location);
          const redirectId = this.extractIdBySource(location, source);
          if (redirectId) return redirectId;
        }
      }
    } catch (error) {
      log.error("\u83B7\u53D6\u91CD\u5B9A\u5411\u5931\u8D25:", error.message);
    }
    return null;
  }
  extractUrl(url) {
    try {
      const urlObj = new URL(url);
      const domain = urlObj.hostname.replace(/^www\./, "");
      const source = _ShortLinkService.DOMAIN_MAP[domain] || _ShortLinkService.DOMAIN_MAP[urlObj.hostname];
      if (!source) {
        log.warn("\u672A\u77E5\u7684\u57DF\u540D:", urlObj.hostname);
        return null;
      }
      const id = this.extractIdBySource(url, source);
      if (id) return { source, id };
      return null;
    } catch (error) {
      log.error("URL\u89E3\u6790\u5931\u8D25:", error);
      return null;
    }
  }
  extractIdBySource(url, source) {
    const regexps = _ShortLinkService.REGEXPS[source];
    if (!regexps) return null;
    for (const key of Object.keys(regexps)) {
      const regExp = regexps[key];
      if (regExp.test(url)) {
        const match = url.match(regExp);
        if (match && match[1]) return match[1];
      }
    }
    return null;
  }
  async getKugouListIdByCode(code) {
    try {
      log.info("\u901A\u8FC7\u9177\u72D7\u7801\u83B7\u53D6\u6B4C\u5355ID:", code);
      const response = await fetch("http://t.kugou.com/command/", {
        method: "POST",
        headers: { "Content-Type": "application/json", "KG-RC": "1", "KG-THash": "network_super_call.cpp:3676261689:379", "User-Agent": "" },
        body: JSON.stringify({ appid: 1001, clientver: 9020, mid: "21511157a05844bd085308bc76ef3343", clienttime: 640612895, key: "36164c4015e704673c588ee202b9ecb8", data: code })
      });
      if (!response.ok) throw new Error(`\u8BF7\u6C42\u5931\u8D25: ${response.status}`);
      const data = await response.json();
      log.info("\u9177\u72D7\u7801\u89E3\u6790\u7ED3\u679C:", data);
      if (data.status !== 1 || !data.data?.info) {
        log.error("\u9177\u72D7\u7801\u89E3\u6790\u5931\u8D25:", data);
        return null;
      }
      const info = data.data.info;
      if (info.type === 2 || info.type === 4) {
        if (info.global_collection_id) return info.global_collection_id;
        if (info.id) return String(info.id);
      }
      log.error("\u4E0D\u652F\u6301\u7684\u9177\u72D7\u7801\u7C7B\u578B:", info.type);
      return null;
    } catch (error) {
      log.error("\u901A\u8FC7\u9177\u72D7\u7801\u83B7\u53D6\u6B4C\u5355ID\u5931\u8D25:", error.message);
      return null;
    }
  }
  async resolveRedirect(link, retryNum = 0) {
    if (retryNum > 2) throw new Error("\u77ED\u94FE\u63A5\u89E3\u6790\u91CD\u8BD5\u6B21\u6570\u8D85\u8FC7\u9650\u5236");
    try {
      log.info(`\u53D1\u9001HTTP\u8BF7\u6C42\u83B7\u53D6\u91CD\u5B9A\u5411 (\u5C1D\u8BD5 ${retryNum + 1}/3)...`);
      let response = await fetch(link, {
        method: "HEAD",
        redirect: "manual",
        headers: { "User-Agent": "Mozilla/5.0 (iPhone; CPU iPhone OS 13_2_3 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/13.0.3 Mobile/15E148 Safari/604.1", "Accept": "text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,*/*;q=0.8", "Accept-Language": "zh-CN,zh;q=0.9" }
      });
      if (response.status >= 500) {
        log.warn(`HEAD\u8BF7\u6C42\u8FD4\u56DE ${response.status}\uFF0C\u5C1D\u8BD5GET\u8BF7\u6C42...`);
        response = await fetch(link, {
          method: "GET",
          redirect: "manual",
          headers: { "User-Agent": "Mozilla/5.0 (iPhone; CPU iPhone OS 13_2_3 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/13.0.3 Mobile/15E148 Safari/604.1", "Accept": "text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8", "Accept-Language": "zh-CN,zh;q=0.9" }
        });
        const location = response.headers.get("location");
        if (location && location !== link) {
          log.info("\u83B7\u53D6\u5230\u91CD\u5B9A\u5411\u5730\u5740:", location);
          const result = this.extractUrl(location);
          if (result) {
            log.info("\u4ECE\u91CD\u5B9A\u5411\u5730\u5740\u63D0\u53D6\u6210\u529F:", result);
            return result;
          }
          return this.resolveRedirect(location, retryNum + 1);
        }
        log.info("GET\u8BF7\u6C42\u8FD4\u56DE" + response.status + "\uFF0C\u5C1D\u8BD5\u4ECE\u54CD\u5E94\u4F53\u63D0\u53D6...");
        try {
          const text = await response.text();
          if (text) {
            const fromBody = this.extractIdFromHtmlOrJs(text);
            if (fromBody) {
              log.info("\u4ECE500\u54CD\u5E94\u4F53\u63D0\u53D6\u6210\u529F:", fromBody);
              return fromBody;
            }
          }
        } catch (_e) {
          log.warn("\u8BFB\u53D6500\u54CD\u5E94\u4F53\u5931\u8D25:", _e.message);
        }
        return this.extractFromPage(link);
      }
    } catch (error) {
      log.error("\u89E3\u6790\u91CD\u5B9A\u5411\u5931\u8D25:", error.message, error.stack);
      if (retryNum < 2) {
        log.warn("\u7B49\u5F85\u540E\u91CD\u8BD5...");
        await new Promise((r) => setTimeout(r, 500));
        return this.resolveRedirect(link, retryNum + 1);
      }
      throw error;
    }
  }
  async extractFromPage(link) {
    try {
      const response = await fetch(link, {
        headers: { "User-Agent": "Mozilla/5.0 (iPhone; CPU iPhone OS 13_2_3 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/13.0.3 Mobile/15E148 Safari/604.1", "Accept": "text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8", "Accept-Language": "zh-CN,zh;q=0.9" }
      });
      if (!response.ok) throw new Error(`\u8BF7\u6C42\u5931\u8D25: ${response.status}`);
      const html = await response.text();
      if (html.includes("\u6B64\u6B4C\u5355\u5DF2\u88AB\u521B\u5EFA\u8005\u8BBE\u4E3A\u9690\u79C1")) throw new Error("\u8BE5\u6B4C\u5355\u5DF2\u88AB\u521B\u5EFA\u8005\u8BBE\u4E3A\u9690\u79C1\uFF0C\u65E0\u6CD5\u8BBF\u95EE");
      if (html.includes("\u6B4C\u5355\u4E0D\u5B58\u5728") || html.includes("\u5185\u5BB9\u5DF2\u5931\u6548")) throw new Error("\u6B4C\u5355\u4E0D\u5B58\u5728\u6216\u94FE\u63A5\u5DF2\u5931\u6548");
      const kgGlobalMatch = html.match(/"global_collection_id":"(\w+)"/);
      if (kgGlobalMatch) return { source: "kg", id: kgGlobalMatch[1] };
      const wyMatch = html.match(/playlist\?id=(\d+)/);
      if (wyMatch) return { source: "wy", id: wyMatch[1] };
      const txMatch = html.match(/playlist\/(\d+)/);
      if (txMatch) return { source: "tx", id: txMatch[1] };
      const txMobileMatch = html.match(/playsquare\/(\d+)/);
      if (txMobileMatch) return { source: "tx", id: txMobileMatch[1] };
      const txDataMatch = html.match(/"disstid":\s*"?(\d+)"?/);
      if (txDataMatch) return { source: "tx", id: txDataMatch[1] };
      throw new Error("\u65E0\u6CD5\u4ECE\u9875\u9762\u5185\u5BB9\u4E2D\u63D0\u53D6\u6B4C\u5355\u4FE1\u606F\uFF0C\u53EF\u80FD\u662F\u94FE\u63A5\u5DF2\u5931\u6548\u6216\u6B4C\u5355\u4E0D\u5B58\u5728");
    } catch (error) {
      log.error("\u4ECE\u9875\u9762\u63D0\u53D6\u5931\u8D25:", error.message, error.stack);
      throw error;
    }
  }
  extractIdFromHtmlOrJs(text) {
    const patterns = [
      { source: "tx", regex: /playlist[/_]?(\d{5,})/ },
      { source: "tx", regex: /"disstid":\s*"?(\d+)"?/ },
      { source: "tx", regex: /"playlistid"?:\s*"?(\d{5,})"?/i },
      { source: "wy", regex: /playlist\?id=(\d+)/ },
      { source: "kg", regex: /global_collection_id[=:]['"]?(\w{10,})/ },
      { source: "kw", regex: /pid[=:]\s*['"]?(\d+)/ }
    ];
    for (const { source, regex } of patterns) {
      const match = text.match(regex);
      if (match && match[1]) {
        log.info(`\u4ECEJS/HTML\u4E2D\u63D0\u53D6\u5230${source} ID:`, match[1]);
        return { source, id: match[1] };
      }
    }
    return null;
  }
};

// src/utils/crypto.ts
var iv = new Uint8Array([48, 49, 50, 51, 52, 53, 54, 55, 56, 57, 48, 49, 50, 51, 52, 53, 54, 55, 56]);
var presetKey = new Uint8Array([48, 67, 111, 74, 85, 109, 54, 81, 121, 119, 56, 87, 56, 106, 117, 100]);
var linuxapiKey = new Uint8Array([114, 70, 103, 66, 38, 104, 35, 37, 50, 63, 94, 101, 68, 103, 58, 81]);
function linuxapi(object) {
  const text = JSON.stringify(object);
  const d = new TextEncoder().encode(text);
  const bs = 16;
  const p = bs - d.length % bs;
  const pd = new Uint8Array(d.length + p);
  pd.set(d);
  for (let i = d.length; i < pd.length; i++) pd[i] = p;
  const enc = aesEncryptECB(pd, linuxapiKey);
  return { eparams: Array.from(enc).map((b) => b.toString(16).padStart(2, "0")).join("").toUpperCase() };
}

// src/utils/md5.ts
function safeAdd(x, y) {
  const lsw = (x & 65535) + (y & 65535);
  const msw = (x >> 16) + (y >> 16) + (lsw >> 16);
  return msw << 16 | lsw & 65535;
}
function bitRotateLeft(num, cnt) {
  return num << cnt | num >>> 32 - cnt;
}
function md5cmn(q, a, b, x, s, t) {
  return safeAdd(bitRotateLeft(safeAdd(safeAdd(a, q), safeAdd(x, t)), s), b);
}
function md5ff(a, b, c, d, x, s, t) {
  return md5cmn(b & c | ~b & d, a, b, x, s, t);
}
function md5gg(a, b, c, d, x, s, t) {
  return md5cmn(b & d | c & ~d, a, b, x, s, t);
}
function md5hh(a, b, c, d, x, s, t) {
  return md5cmn(b ^ c ^ d, a, b, x, s, t);
}
function md5ii(a, b, c, d, x, s, t) {
  return md5cmn(c ^ (b | ~d), a, b, x, s, t);
}
function binlMD5(x, len) {
  x[len >> 5] |= 128 << len % 32;
  x[(len + 64 >>> 9 << 4) + 14] = len;
  let a = 1732584193;
  let b = -271733879;
  let c = -1732584194;
  let d = 271733878;
  for (let i = 0; i < x.length; i += 16) {
    const olda = a;
    const oldb = b;
    const oldc = c;
    const oldd = d;
    a = md5ff(a, b, c, d, x[i], 7, -680876936);
    d = md5ff(d, a, b, c, x[i + 1], 12, -389564586);
    c = md5ff(c, d, a, b, x[i + 2], 17, 606105819);
    b = md5ff(b, c, d, a, x[i + 3], 22, -1044525330);
    a = md5ff(a, b, c, d, x[i + 4], 7, -176418897);
    d = md5ff(d, a, b, c, x[i + 5], 12, 1200080426);
    c = md5ff(c, d, a, b, x[i + 6], 17, -1473231341);
    b = md5ff(b, c, d, a, x[i + 7], 22, -45705983);
    a = md5ff(a, b, c, d, x[i + 8], 7, 1770035416);
    d = md5ff(d, a, b, c, x[i + 9], 12, -1958414417);
    c = md5ff(c, d, a, b, x[i + 10], 17, -42063);
    b = md5ff(b, c, d, a, x[i + 11], 22, -1990404162);
    a = md5ff(a, b, c, d, x[i + 12], 7, 1804603682);
    d = md5ff(d, a, b, c, x[i + 13], 12, -40341101);
    c = md5ff(c, d, a, b, x[i + 14], 17, -1502002290);
    b = md5ff(b, c, d, a, x[i + 15], 22, 1236535329);
    a = md5gg(a, b, c, d, x[i + 1], 5, -165796510);
    d = md5gg(d, a, b, c, x[i + 6], 9, -1069501632);
    c = md5gg(c, d, a, b, x[i + 11], 14, 643717713);
    b = md5gg(b, c, d, a, x[i], 20, -373897302);
    a = md5gg(a, b, c, d, x[i + 5], 5, -701558691);
    d = md5gg(d, a, b, c, x[i + 10], 9, 38016083);
    c = md5gg(c, d, a, b, x[i + 15], 14, -660478335);
    b = md5gg(b, c, d, a, x[i + 4], 20, -405537848);
    a = md5gg(a, b, c, d, x[i + 9], 5, 568446438);
    d = md5gg(d, a, b, c, x[i + 14], 9, -1019803690);
    c = md5gg(c, d, a, b, x[i + 3], 14, -187363961);
    b = md5gg(b, c, d, a, x[i + 8], 20, 1163531501);
    a = md5gg(a, b, c, d, x[i + 13], 5, -1444681467);
    d = md5gg(d, a, b, c, x[i + 2], 9, -51403784);
    c = md5gg(c, d, a, b, x[i + 7], 14, 1735328473);
    b = md5gg(b, c, d, a, x[i + 12], 20, -1926607734);
    a = md5hh(a, b, c, d, x[i + 5], 4, -378558);
    d = md5hh(d, a, b, c, x[i + 8], 11, -2022574463);
    c = md5hh(c, d, a, b, x[i + 11], 16, 1839030562);
    b = md5hh(b, c, d, a, x[i + 14], 23, -35309556);
    a = md5hh(a, b, c, d, x[i + 1], 4, -1530992060);
    d = md5hh(d, a, b, c, x[i + 4], 11, 1272893353);
    c = md5hh(c, d, a, b, x[i + 7], 16, -155497632);
    b = md5hh(b, c, d, a, x[i + 10], 23, -1094730640);
    a = md5hh(a, b, c, d, x[i + 13], 4, 681279174);
    d = md5hh(d, a, b, c, x[i], 11, -358537222);
    c = md5hh(c, d, a, b, x[i + 3], 16, -722521979);
    b = md5hh(b, c, d, a, x[i + 6], 23, 76029189);
    a = md5hh(a, b, c, d, x[i + 9], 4, -640364487);
    d = md5hh(d, a, b, c, x[i + 12], 11, -421815835);
    c = md5hh(c, d, a, b, x[i + 15], 16, 530742520);
    b = md5hh(b, c, d, a, x[i + 2], 23, -995338651);
    a = md5ii(a, b, c, d, x[i], 6, -198630844);
    d = md5ii(d, a, b, c, x[i + 7], 10, 1126891415);
    c = md5ii(c, d, a, b, x[i + 14], 15, -1416354905);
    b = md5ii(b, c, d, a, x[i + 5], 21, -57434055);
    a = md5ii(a, b, c, d, x[i + 12], 6, 1700485571);
    d = md5ii(d, a, b, c, x[i + 3], 10, -1894986606);
    c = md5ii(c, d, a, b, x[i + 10], 15, -1051523);
    b = md5ii(b, c, d, a, x[i + 1], 21, -2054922799);
    a = md5ii(a, b, c, d, x[i + 8], 6, 1873313359);
    d = md5ii(d, a, b, c, x[i + 15], 10, -30611744);
    c = md5ii(c, d, a, b, x[i + 6], 15, -1560198380);
    b = md5ii(b, c, d, a, x[i + 13], 21, 1309151649);
    a = md5ii(a, b, c, d, x[i + 4], 6, -145523070);
    d = md5ii(d, a, b, c, x[i + 11], 10, -1120210379);
    c = md5ii(c, d, a, b, x[i + 2], 15, 718787259);
    b = md5ii(b, c, d, a, x[i + 9], 21, -343485551);
    a = safeAdd(a, olda);
    b = safeAdd(b, oldb);
    c = safeAdd(c, oldc);
    d = safeAdd(d, oldd);
  }
  return [a, b, c, d];
}
function binl2rstr(input) {
  let output = "";
  for (let i = 0; i < input.length * 32; i += 8) output += String.fromCharCode(input[i >> 5] >>> i % 32 & 255);
  return output;
}
function rstr2binl(input) {
  const output = [];
  for (let i = 0; i < input.length * 8; i += 8) output[i >> 5] |= (input.charCodeAt(i / 8) & 255) << i % 32;
  return output;
}
function rstrMD5(s) {
  return binl2rstr(binlMD5(rstr2binl(s), s.length * 8));
}
function rstr2hex(input) {
  const hexChars = "0123456789abcdef";
  let output = "";
  for (let i = 0; i < input.length; i++) {
    const x = input.charCodeAt(i);
    output += hexChars.charAt(x >>> 4 & 15) + hexChars.charAt(x & 15);
  }
  return output;
}
function md52(input) {
  return rstr2hex(rstrMD5(input));
}

// src/services/songlist_service.ts
var NeteaseSongListService = class _NeteaseSongListService {
  static API_URL = "https://music.163.com/api/linux/forward";
  static SUCCESS_CODE = 200;
  parseListId(input) {
    const regExp = /[?&]id=(\d+)/;
    if (regExp.test(input)) return input.replace(regExp, "$1");
    return input;
  }
  formatPlayCount(count) {
    if (count > 1e4) return (count / 1e4).toFixed(1) + "\u4E07";
    return String(count);
  }
  formatPlayTime(interval) {
    const m = Math.floor(interval / 60).toString().padStart(2, "0");
    const s = (interval % 60).toString().padStart(2, "0");
    return `${m}:${s}`;
  }
  async getMusicDetail(ids) {
    if (ids.length === 0) return [];
    try {
      const encrypted = linuxapi({
        method: "POST",
        url: "https://music.163.com/api/v3/song/detail",
        params: { c: "[" + ids.map((id) => '{"id":' + id + "}").join(",") + "]" }
      });
      const response = await fetch(_NeteaseSongListService.API_URL, {
        method: "POST",
        headers: {
          "User-Agent": "Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/60.0.3112.90 Safari/537.36",
          "Content-Type": "application/x-www-form-urlencoded"
        },
        body: new URLSearchParams(encrypted)
      });
      if (!response.ok) throw new Error(`\u83B7\u53D6\u6B4C\u66F2\u8BE6\u60C5\u5931\u8D25: ${response.status}`);
      const data = await response.json();
      if (data.code !== _NeteaseSongListService.SUCCESS_CODE) throw new Error("\u83B7\u53D6\u6B4C\u66F2\u8BE6\u60C5\u5931\u8D25");
      return data.songs || [];
    } catch (error) {
      console.error("[SongList] \u83B7\u53D6\u6B4C\u66F2\u8BE6\u60C5\u5931\u8D25:", error.message);
      return [];
    }
  }
  async getListDetail(rawId) {
    const id = this.parseListId(rawId);
    console.log("[SongList] \u83B7\u53D6\u7F51\u6613\u4E91\u6B4C\u5355\u8BE6\u60C5, id:", id);
    try {
      const encrypted = linuxapi({
        method: "POST",
        url: "https://music.163.com/api/v3/playlist/detail",
        params: { id: parseInt(id), n: 1e5, s: 8 }
      });
      const response = await fetch(_NeteaseSongListService.API_URL, {
        method: "POST",
        headers: {
          "User-Agent": "Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/60.0.3112.90 Safari/537.36",
          "Content-Type": "application/x-www-form-urlencoded"
        },
        body: new URLSearchParams(encrypted)
      });
      if (!response.ok) throw new Error(`\u8BF7\u6C42\u5931\u8D25: ${response.status}`);
      const data = await response.json();
      if (data.code !== _NeteaseSongListService.SUCCESS_CODE || !data.playlist) throw new Error("\u83B7\u53D6\u6B4C\u5355\u5931\u8D25");
      const playlist = data.playlist;
      const privileges = data.privileges || [];
      const trackIds = playlist.trackIds || [];
      let list = [];
      if (trackIds.length === privileges.length && playlist.tracks.length === trackIds.length) {
        list = playlist.tracks.map((item, index) => {
          const privilege = privileges[index] || {};
          return {
            id: String(item.id),
            name: item.name,
            singer: item.ar?.map((a) => a.name).join("\u3001") || "",
            albumName: item.al?.name || "",
            albumId: String(item.al?.id || ""),
            interval: this.formatPlayTime(Math.floor(item.dt / 1e3)),
            source: "wy",
            songmid: String(item.id),
            img: item.al?.picUrl || ""
          };
        });
      } else {
        const batchSize = 1e3;
        for (let i = 0; i < trackIds.length; i += batchSize) {
          const batchTrackIds = trackIds.slice(i, i + batchSize);
          const ids = batchTrackIds.map((t) => t.id);
          const songs = await this.getMusicDetail(ids);
          const batchList = songs.map((item) => ({
            id: String(item.id),
            name: item.name,
            singer: item.ar?.map((a) => a.name).join("\u3001") || "",
            albumName: item.al?.name || "",
            albumId: String(item.al?.id || ""),
            interval: this.formatPlayTime(Math.floor(item.dt / 1e3)),
            source: "wy",
            songmid: String(item.id),
            img: item.al?.picUrl || ""
          }));
          list = list.concat(batchList);
        }
      }
      return {
        list,
        page: 1,
        limit: list.length,
        total: list.length,
        source: "wy",
        info: {
          name: playlist.name,
          img: playlist.coverImgUrl,
          desc: playlist.description || "",
          author: playlist.creator?.nickname || "",
          play_count: this.formatPlayCount(playlist.playCount)
        }
      };
    } catch (error) {
      console.error("[SongList] \u83B7\u53D6\u7F51\u6613\u4E91\u6B4C\u5355\u5931\u8D25:", error.message);
      throw error;
    }
  }
};
var QQMusicSongListService = class _QQMusicSongListService {
  static SUCCESS_CODE = 0;
  parseListId(input) {
    const regExp1 = /\/playlist\/(\d+)/;
    const regExp2 = /[?&]id=(\d+)/;
    if (regExp1.test(input)) return input.replace(regExp1, "$1");
    if (regExp2.test(input)) return input.replace(regExp2, "$1");
    return input;
  }
  formatPlayCount(count) {
    if (count > 1e4) return (count / 1e4).toFixed(1) + "\u4E07";
    return String(count);
  }
  formatPlayTime(interval) {
    const m = Math.floor(interval / 60).toString().padStart(2, "0");
    const s = (interval % 60).toString().padStart(2, "0");
    return `${m}:${s}`;
  }
  decodeName(name) {
    return name.replace(/&amp;/g, "&").replace(/&lt;/g, "<").replace(/&gt;/g, ">").replace(/&quot;/g, '"').replace(/&#x27;/g, "'").replace(/&#x2F;/g, "/").replace(/&#x60;/g, "`").replace(/&#39;/g, "'").replace(/&nbsp;/g, " ");
  }
  async getListDetail(rawId, page = 1) {
    const id = this.parseListId(rawId);
    console.log("[SongList] \u83B7\u53D6QQ\u97F3\u4E50\u6B4C\u5355\u8BE6\u60C5, id:", id);
    try {
      const url = `https://c.y.qq.com/qzone/fcg-bin/fcg_ucc_getcdinfo_byids_cp.fcg?type=1&json=1&utf8=1&onlysong=0&new_format=1&disstid=${id}&loginUin=0&hostUin=0&format=json&inCharset=utf8&outCharset=utf-8&notice=0&platform=yqq.json&needNewCode=0`;
      const response = await fetch(url, {
        headers: {
          "Origin": "https://y.qq.com",
          "Referer": `https://y.qq.com/n/yqq/playsquare/${id}.html`,
          "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36"
        }
      });
      if (!response.ok) throw new Error(`\u8BF7\u6C42\u5931\u8D25: ${response.status}`);
      const data = await response.json();
      if (data.code !== _QQMusicSongListService.SUCCESS_CODE || !data.cdlist || data.cdlist.length === 0) throw new Error("\u83B7\u53D6\u6B4C\u5355\u5931\u8D25");
      const cdlist = data.cdlist[0];
      const list = cdlist.songlist.map((item) => ({
        id: String(item.id),
        name: item.title,
        singer: item.singer?.map((s) => s.name).join("\u3001") || "",
        albumName: item.album?.name || "",
        albumId: item.album?.mid || "",
        interval: this.formatPlayTime(item.interval),
        source: "tx",
        songmid: item.mid,
        songId: String(item.id),
        strMediaMid: item.file?.media_mid || "",
        img: item.album?.name ? `https://y.gtimg.cn/music/photo_new/T002R500x500M000${item.album.mid}.jpg` : item.singer?.length ? `https://y.gtimg.cn/music/photo_new/T001R500x500M000${item.singer[0].mid}.jpg` : ""
      }));
      return {
        list,
        page: 1,
        limit: list.length + 1,
        total: cdlist.songlist.length,
        source: "tx",
        info: {
          name: cdlist.dissname,
          img: cdlist.logo,
          desc: this.decodeName(cdlist.desc).replace(/<br>/g, "\n"),
          author: cdlist.nickname,
          play_count: this.formatPlayCount(cdlist.visitnum)
        }
      };
    } catch (error) {
      console.error("[SongList] \u83B7\u53D6QQ\u97F3\u4E50\u6B4C\u5355\u5931\u8D25:", error.message);
      throw error;
    }
  }
};
var KugouSongListService = class {
  parseListId(input) {
    const regExp = /\/single\/(\d+)/;
    if (regExp.test(input)) return input.replace(regExp, "$1");
    return input;
  }
  formatPlayTime(time) {
    const m = Math.floor(time / 60).toString().padStart(2, "0");
    const s = Math.floor(time % 60).toString().padStart(2, "0");
    return `${m}:${s}`;
  }
  formatPlayCount(count) {
    if (count > 1e4) return (count / 1e4).toFixed(1) + "\u4E07";
    return String(count);
  }
  signatureParams(paramsObj, platform = "android") {
    const key = platform === "web" ? "NVPh5oo715z5DIWAeQlhMDsWXXQV4hwt" : "OIlwieks28dk2k092lksi2UIkp";
    const sortedKeys = Object.keys(paramsObj).sort();
    const paramsStr = sortedKeys.map((k) => `${k}=${paramsObj[k]}`).join("");
    const text = key + paramsStr + key;
    return md52(text);
  }
  async getListDetail(rawId, page = 1) {
    if (rawId.length > 20 || /[a-zA-Z]/.test(rawId)) {
      console.log("[SongList] \u68C0\u6D4B\u5230 global_collection_id:", rawId);
      return this.getListDetailByGlobalCollectionId(rawId);
    }
    const id = this.parseListId(rawId);
    console.log("[SongList] \u83B7\u53D6\u9177\u72D7\u6B4C\u5355\u8BE6\u60C5, id:", id);
    try {
      const url = `http://www2.kugou.kugou.com/yueku/v9/special/single/${id}-5-9999.html`;
      const response = await fetch(url, { headers: { "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36" } });
      if (!response.ok) throw new Error(`\u8BF7\u6C42\u5931\u8D25: ${response.status}`);
      const html = await response.text();
      const listDataMatch = html.match(/global\.data = (\[.+\]);/);
      const listInfoMatch = html.match(/global = {[\s\S]+?name: "(.+)"[\s\S]+?pic: "(.+)"[\s\S]+?};/);
      if (!listDataMatch) throw new Error("\u89E3\u6790\u6B4C\u5355\u6570\u636E\u5931\u8D25");
      let listData;
      try {
        listData = JSON.parse(listDataMatch[1]);
      } catch (e) {
        throw new Error("\u89E3\u6790\u6B4C\u5355 JSON \u5931\u8D25");
      }
      let name = "", pic = "";
      if (listInfoMatch) {
        name = listInfoMatch[1];
        pic = listInfoMatch[2];
      }
      let desc = "";
      const descMatch = html.match(/<div class="pc_specail_text pc_singer_tab_content" id="specailIntroduceWrap">([\s\S]*?)<\/div>/);
      if (descMatch) desc = descMatch[1].replace(/<[^>]+>/g, "").trim();
      const list = listData.map((item) => ({
        id: String(item.hash),
        name: item.songname,
        singer: item.singername || "",
        albumName: item.album_name || "",
        interval: this.formatPlayTime(item.duration || 0),
        source: "kg",
        hash: item.hash,
        img: item.album_img?.replace("{size}", "150") || ""
      }));
      return {
        list,
        page: 1,
        limit: 1e4,
        total: list.length,
        source: "kg",
        info: { name, img: pic, desc, author: "", play_count: "" }
      };
    } catch (error) {
      console.error("[SongList] \u83B7\u53D6\u9177\u72D7\u6B4C\u5355\u5931\u8D25:", error.message);
      throw error;
    }
  }
  async getListDetailByGlobalCollectionId(globalCollectionId) {
    console.log("[SongList] \u901A\u8FC7 global_collection_id \u83B7\u53D6\u9177\u72D7\u6B4C\u5355:", globalCollectionId);
    try {
      const clienttime = Date.now();
      const paramsObj = {
        appid: 1058,
        specialid: 0,
        global_specialid: globalCollectionId,
        format: "jsonp",
        srcappid: 2919,
        clientver: 2e4,
        clienttime,
        mid: clienttime,
        uuid: clienttime,
        dfid: "-"
      };
      const signature = this.signatureParams(paramsObj, "web");
      const params = Object.entries(paramsObj).map(([k, v]) => `${k}=${v}`).join("&");
      const infoResponse = await fetch(`https://mobiles.kugou.com/api/v5/special/info_v2?${params}&signature=${signature}`, {
        headers: {
          "mid": String(clienttime),
          "Referer": "https://m3ws.kugou.com/share/index.php",
          "User-Agent": "Mozilla/5.0 (iPhone; CPU iPhone OS 11_0 like Mac OS X) AppleWebKit/604.1.38 (KHTML, like Gecko) Version/11.0 Mobile/15A372 Safari/604.1",
          "dfid": "-",
          "clienttime": String(clienttime)
        }
      });
      if (!infoResponse.ok) throw new Error(`\u83B7\u53D6\u6B4C\u5355\u4FE1\u606F\u5931\u8D25: ${infoResponse.status}`);
      const result = await infoResponse.json();
      if (result.status !== 1 || !result.data?.specialname) throw new Error("\u83B7\u53D6\u6B4C\u5355\u4FE1\u606F\u5931\u8D25");
      const info = result.data;
      const songCount = info.songcount || info.count || 0;
      const songList = await this.getSongListByGlobalCollectionId(globalCollectionId, songCount, clienttime);
      const list = this.getMusicInfos(songList);
      return {
        list,
        page: 1,
        limit: 1e4,
        total: list.length,
        source: "kg",
        info: {
          name: info.specialname,
          img: info.imgurl?.replace("{size}", "240") || "",
          desc: info.intro || "",
          author: info.nickname || "",
          play_count: this.formatPlayCount(info.playcount || 0)
        }
      };
    } catch (error) {
      console.error("[SongList] \u901A\u8FC7 global_collection_id \u83B7\u53D6\u9177\u72D7\u6B4C\u5355\u5931\u8D25:", error.message);
      throw error;
    }
  }
  async getSongListByGlobalCollectionId(globalCollectionId, songCount, clienttime) {
    const list = [];
    const pageSize = 100;
    const totalPages = Math.ceil(songCount / pageSize);
    for (let page = 1; page <= totalPages; page++) {
      const paramsObj = {
        appid: 1005,
        need_sort: 1,
        module: "CloudMusic",
        clientver: 11589,
        pagesize: pageSize,
        global_collection_id: globalCollectionId,
        userid: 0,
        page,
        type: 0,
        area_code: 1
      };
      const signature = this.signatureParams(paramsObj, "android");
      const params = Object.entries(paramsObj).map(([k, v]) => `${k}=${v}`).join("&");
      const response = await fetch(`http://pubsongs.kugou.com/v2/get_other_list_file?${params}&signature=${signature}`, {
        headers: { "User-Agent": "Android10-AndroidPhone-11589-201-0-playlist-wifi" }
      });
      if (!response.ok) continue;
      const data = await response.json();
      if (data.data?.info && Array.isArray(data.data.info)) list.push(...data.data.info);
    }
    return list;
  }
  getMusicInfos(songList) {
    return songList.map((item) => {
      let songName = item.name || item.songname || item.songName || "";
      let singerName = item.singername || item.singerName || "";
      if (songName && songName.includes(" - ")) {
        const parts = songName.split(" - ");
        if (parts.length >= 2) {
          singerName = parts[0].trim();
          songName = parts.slice(1).join(" - ").trim();
        }
      }
      const albumName = item.album_name || item.albumName || item.remark || "";
      let duration = item.duration || 0;
      if (duration > 1e4) duration = Math.floor(duration / 1e3);
      let img = item.album_img || item.img || "{size}";
      if (img && !img.includes("http")) img = "{size}";
      return {
        id: String(item.hash),
        name: songName,
        singer: singerName,
        albumName,
        interval: this.formatPlayTime(duration),
        source: "kg",
        hash: item.hash,
        img: img.replace("{size}", "150")
      };
    });
  }
};
var KuwoSongListService = class _KuwoSongListService {
  static LIMIT_SONG = 100;
  parseListId(input) {
    const regExp = /\/playlist(?:_detail)?\/(\d+)/;
    const digestRegExp = /^digest-(\d+)__(\d+)$/;
    if (digestRegExp.test(input)) {
      const match = input.match(digestRegExp);
      if (match) return { id: match[2], digest: match[1] };
    }
    if (regExp.test(input)) return { id: input.replace(regExp, "$1") };
    return { id: input };
  }
  formatPlayCount(count) {
    if (count > 1e8) return (count / 1e8).toFixed(1) + "\u4EBF";
    if (count > 1e4) return (count / 1e4).toFixed(1) + "\u4E07";
    return String(count);
  }
  formatPlayTime(time) {
    const m = Math.floor(time / 60).toString().padStart(2, "0");
    const s = Math.floor(time % 60).toString().padStart(2, "0");
    return `${m}:${s}`;
  }
  async getListDetailDigest8(id, page, tryNum = 0) {
    if (tryNum > 2) throw new Error("try max num");
    const url = `http://nplserver.kuwo.cn/pl.svc?op=getlistinfo&pid=${id}&pn=${page - 1}&rn=${_KuwoSongListService.LIMIT_SONG}&encode=utf8&keyset=pl2012&identity=kuwo&pcmp4=1&vipver=MUSIC_9.0.5.0_W1&newver=1`;
    console.log("[SongList] [Kuwo] \u8BF7\u6C42URL (\u5C1D\u8BD5", tryNum + 1, "):", url);
    const response = await fetch(url, {
      headers: {
        "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36",
        "Accept": "application/json, text/plain, */*",
        "Accept-Language": "zh-CN,zh;q=0.9",
        "Referer": "http://www.kuwo.cn/"
      }
    });
    if (!response.ok) {
      if (tryNum < 2) {
        await new Promise((r) => setTimeout(r, 500));
        return this.getListDetailDigest8(id, page, tryNum + 1);
      }
      throw new Error(`\u8BF7\u6C42\u5931\u8D25: ${response.status}`);
    }
    const data = await response.json();
    if (data.result !== "ok") {
      if (tryNum < 2) {
        await new Promise((r) => setTimeout(r, 500));
        return this.getListDetailDigest8(id, page, tryNum + 1);
      }
      throw new Error("\u83B7\u53D6\u6B4C\u5355\u5931\u8D25");
    }
    const list = (data.musiclist || []).map((item) => ({
      id: String(item.id),
      name: item.name,
      singer: item.artist || "",
      albumName: item.album || "",
      albumId: item.albumid,
      interval: this.formatPlayTime(parseInt(item.duration) || 0),
      source: "kw",
      songmid: String(item.id),
      img: item.pic || ""
    }));
    return {
      list,
      page,
      limit: data.rn || 100,
      total: data.total || list.length,
      source: "kw",
      info: {
        name: data.title || "",
        img: data.pic || "",
        desc: data.info || "",
        author: data.uname || "",
        play_count: this.formatPlayCount(data.playnum || 0)
      }
    };
  }
  async getListDetailDigest5(id, page) {
    const infoUrl = `http://qukudata.kuwo.cn/q.k?op=query&cont=ninfo&node=${id}&pn=0&rn=1&fmt=json&src=mbox&level=2`;
    const infoResponse = await fetch(infoUrl, { headers: { "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36" } });
    if (!infoResponse.ok) throw new Error(`\u83B7\u53D6\u6B4C\u5355\u4FE1\u606F\u5931\u8D25: ${infoResponse.status}`);
    const infoData = await infoResponse.json();
    if (!infoData.child || infoData.child.length === 0) throw new Error("\u65E0\u6CD5\u83B7\u53D6\u6B4C\u5355\u4FE1\u606F");
    const realId = infoData.child[0].sourceid;
    if (!realId) throw new Error("\u65E0\u6CD5\u83B7\u53D6\u6B4C\u5355\u771F\u5B9EID");
    return this.getListDetailDigest8(realId, page);
  }
  async getListDetail(rawId, page = 1) {
    const { id, digest } = this.parseListId(rawId);
    console.log("[SongList] \u83B7\u53D6\u9177\u6211\u6B4C\u5355\u8BE6\u60C5, id:", id, "digest:", digest, "page:", page);
    try {
      if (digest === "5") return await this.getListDetailDigest5(id, page);
      return await this.getListDetailDigest8(id, page);
    } catch (error) {
      console.error("[SongList] \u83B7\u53D6\u9177\u6211\u6B4C\u5355\u5931\u8D25:", error.message);
      throw error;
    }
  }
};
var MiguSongListService = class _MiguSongListService {
  static SUCCESS_CODE = "000000";
  parseListId(input) {
    const regExp1 = /\/playlist\/(\d+)/;
    const regExp2 = /[?&]id=(\d+)/;
    if (regExp1.test(input)) return input.replace(regExp1, "$1");
    if (regExp2.test(input)) return input.replace(regExp2, "$1");
    return input;
  }
  formatPlayCount(count) {
    if (count > 1e4) return (count / 1e4).toFixed(1) + "\u4E07";
    return String(count);
  }
  formatPlayTime(time) {
    const m = Math.floor(time / 60).toString().padStart(2, "0");
    const s = Math.floor(time % 60).toString().padStart(2, "0");
    return `${m}:${s}`;
  }
  async getListDetail(rawId, page = 1) {
    const id = this.parseListId(rawId);
    console.log("[SongList] \u83B7\u53D6\u54AA\u5495\u6B4C\u5355\u8BE6\u60C5, id:", id, "page:", page);
    try {
      const [listData, infoData] = await Promise.all([this.getListDetailList(id, page), this.getListDetailInfo(id)]);
      return { ...listData, info: infoData };
    } catch (error) {
      console.error("[SongList] \u83B7\u53D6\u54AA\u5495\u6B4C\u5355\u5931\u8D25:", error.message);
      throw error;
    }
  }
  async getListDetailList(id, page) {
    const url = `https://app.c.nf.migu.cn/MIGUM2.0/v1.0/user/queryMusicListSongs.do?musicListId=${id}&pageNo=${page}&pageSize=50`;
    const response = await fetch(url, {
      headers: {
        "User-Agent": "Mozilla/5.0 (iPhone; CPU iPhone OS 13_2_3 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/13.0.3 Mobile/15E148 Safari/604.1",
        "Referer": "https://m.music.migu.cn/"
      }
    });
    if (!response.ok) throw new Error(`\u8BF7\u6C42\u5931\u8D25: ${response.status}`);
    const data = await response.json();
    if (data.code !== _MiguSongListService.SUCCESS_CODE) throw new Error("\u83B7\u53D6\u6B4C\u66F2\u5217\u8868\u5931\u8D25");
    const list = (data.list || []).map((item) => {
      const singerNames = item.artists?.map((s) => s.name).join("\u3001") || item.singer || "";
      let interval = "00:00";
      if (item.length) {
        if (typeof item.length === "string" && item.length.includes(":")) interval = item.length;
        else interval = this.formatPlayTime(parseInt(item.length) || 0);
      }
      return {
        id: String(item.copyrightId || item.songId),
        name: item.songName || item.title,
        singer: singerNames,
        albumName: item.album || "",
        albumId: item.albumId,
        interval,
        source: "mg",
        copyrightId: String(item.copyrightId),
        songId: String(item.songId || item.id),
        img: item.albumImgs?.length ? item.albumImgs[0].img : item.albumImg?.replace("{size}", "150") || ""
      };
    });
    return { list, page, limit: 50, total: data.totalCount || list.length, source: "mg" };
  }
  async getListDetailInfo(id) {
    const url = `https://c.musicapp.migu.cn/MIGUM3.0/resource/playlist/v2.0?playlistId=${id}`;
    const response = await fetch(url, {
      headers: {
        "User-Agent": "Mozilla/5.0 (iPhone; CPU iPhone OS 13_2_3 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/13.0.3 Mobile/15E148 Safari/604.1",
        "Referer": "https://m.music.migu.cn/"
      }
    });
    if (!response.ok) throw new Error(`\u8BF7\u6C42\u5931\u8D25: ${response.status}`);
    const data = await response.json();
    if (data.code !== _MiguSongListService.SUCCESS_CODE) throw new Error("\u83B7\u53D6\u6B4C\u5355\u4FE1\u606F\u5931\u8D25");
    const playlist = data.data || {};
    return {
      name: playlist.title || "",
      img: playlist.imgItem?.img || "",
      desc: playlist.summary || "",
      author: playlist.ownerName || "",
      play_count: this.formatPlayCount(playlist.opNumItem?.playNum || 0)
    };
  }
};
var SongListService = class {
  neteaseService = new NeteaseSongListService();
  qqService = new QQMusicSongListService();
  kugouService = new KugouSongListService();
  kuwoService = new KuwoSongListService();
  miguService = new MiguSongListService();
  async getListDetail(source, id) {
    console.log("[SongList] \u83B7\u53D6\u6B4C\u5355\u8BE6\u60C5, source:", source, "id:", id);
    switch (source) {
      case "wy":
        return this.neteaseService.getListDetail(id);
      case "tx":
        return this.qqService.getListDetail(id);
      case "kg":
        return this.kugouService.getListDetail(id);
      case "kw":
        return this.kuwoService.getListDetail(id);
      case "mg":
        return this.miguService.getListDetail(id);
      default:
        throw new Error(`\u4E0D\u652F\u6301\u7684\u6B4C\u5355\u6765\u6E90: ${source}`);
    }
  }
};

// node_modules/pako/dist/pako.esm.mjs
var Z_FIXED$1 = 4;
var Z_BINARY = 0;
var Z_TEXT = 1;
var Z_UNKNOWN$1 = 2;
function zero$1(buf) {
  let len = buf.length;
  while (--len >= 0) {
    buf[len] = 0;
  }
}
var STORED_BLOCK = 0;
var STATIC_TREES = 1;
var DYN_TREES = 2;
var MIN_MATCH$1 = 3;
var MAX_MATCH$1 = 258;
var LENGTH_CODES$1 = 29;
var LITERALS$1 = 256;
var L_CODES$1 = LITERALS$1 + 1 + LENGTH_CODES$1;
var D_CODES$1 = 30;
var BL_CODES$1 = 19;
var HEAP_SIZE$1 = 2 * L_CODES$1 + 1;
var MAX_BITS$1 = 15;
var Buf_size = 16;
var MAX_BL_BITS = 7;
var END_BLOCK = 256;
var REP_3_6 = 16;
var REPZ_3_10 = 17;
var REPZ_11_138 = 18;
var extra_lbits = (
  /* extra bits for each length code */
  new Uint8Array([0, 0, 0, 0, 0, 0, 0, 0, 1, 1, 1, 1, 2, 2, 2, 2, 3, 3, 3, 3, 4, 4, 4, 4, 5, 5, 5, 5, 0])
);
var extra_dbits = (
  /* extra bits for each distance code */
  new Uint8Array([0, 0, 0, 0, 1, 1, 2, 2, 3, 3, 4, 4, 5, 5, 6, 6, 7, 7, 8, 8, 9, 9, 10, 10, 11, 11, 12, 12, 13, 13])
);
var extra_blbits = (
  /* extra bits for each bit length code */
  new Uint8Array([0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 2, 3, 7])
);
var bl_order = new Uint8Array([16, 17, 18, 0, 8, 7, 9, 6, 10, 5, 11, 4, 12, 3, 13, 2, 14, 1, 15]);
var DIST_CODE_LEN = 512;
var static_ltree = new Array((L_CODES$1 + 2) * 2);
zero$1(static_ltree);
var static_dtree = new Array(D_CODES$1 * 2);
zero$1(static_dtree);
var _dist_code = new Array(DIST_CODE_LEN);
zero$1(_dist_code);
var _length_code = new Array(MAX_MATCH$1 - MIN_MATCH$1 + 1);
zero$1(_length_code);
var base_length = new Array(LENGTH_CODES$1);
zero$1(base_length);
var base_dist = new Array(D_CODES$1);
zero$1(base_dist);
function StaticTreeDesc(static_tree, extra_bits, extra_base, elems, max_length) {
  this.static_tree = static_tree;
  this.extra_bits = extra_bits;
  this.extra_base = extra_base;
  this.elems = elems;
  this.max_length = max_length;
  this.has_stree = static_tree && static_tree.length;
}
var static_l_desc;
var static_d_desc;
var static_bl_desc;
function TreeDesc(dyn_tree, stat_desc) {
  this.dyn_tree = dyn_tree;
  this.max_code = 0;
  this.stat_desc = stat_desc;
}
var d_code = (dist) => {
  return dist < 256 ? _dist_code[dist] : _dist_code[256 + (dist >>> 7)];
};
var put_short = (s, w) => {
  s.pending_buf[s.pending++] = w & 255;
  s.pending_buf[s.pending++] = w >>> 8 & 255;
};
var send_bits = (s, value, length) => {
  if (s.bi_valid > Buf_size - length) {
    s.bi_buf |= value << s.bi_valid & 65535;
    put_short(s, s.bi_buf);
    s.bi_buf = value >> Buf_size - s.bi_valid;
    s.bi_valid += length - Buf_size;
  } else {
    s.bi_buf |= value << s.bi_valid & 65535;
    s.bi_valid += length;
  }
};
var send_code = (s, c, tree) => {
  send_bits(
    s,
    tree[c * 2],
    tree[c * 2 + 1]
    /*.Len*/
  );
};
var bi_reverse = (code, len) => {
  let res = 0;
  do {
    res |= code & 1;
    code >>>= 1;
    res <<= 1;
  } while (--len > 0);
  return res >>> 1;
};
var bi_flush = (s) => {
  if (s.bi_valid === 16) {
    put_short(s, s.bi_buf);
    s.bi_buf = 0;
    s.bi_valid = 0;
  } else if (s.bi_valid >= 8) {
    s.pending_buf[s.pending++] = s.bi_buf & 255;
    s.bi_buf >>= 8;
    s.bi_valid -= 8;
  }
};
var gen_bitlen = (s, desc) => {
  const tree = desc.dyn_tree;
  const max_code = desc.max_code;
  const stree = desc.stat_desc.static_tree;
  const has_stree = desc.stat_desc.has_stree;
  const extra = desc.stat_desc.extra_bits;
  const base = desc.stat_desc.extra_base;
  const max_length = desc.stat_desc.max_length;
  let h;
  let n, m;
  let bits;
  let xbits;
  let f;
  let overflow = 0;
  for (bits = 0; bits <= MAX_BITS$1; bits++) {
    s.bl_count[bits] = 0;
  }
  tree[s.heap[s.heap_max] * 2 + 1] = 0;
  for (h = s.heap_max + 1; h < HEAP_SIZE$1; h++) {
    n = s.heap[h];
    bits = tree[tree[n * 2 + 1] * 2 + 1] + 1;
    if (bits > max_length) {
      bits = max_length;
      overflow++;
    }
    tree[n * 2 + 1] = bits;
    if (n > max_code) {
      continue;
    }
    s.bl_count[bits]++;
    xbits = 0;
    if (n >= base) {
      xbits = extra[n - base];
    }
    f = tree[n * 2];
    s.opt_len += f * (bits + xbits);
    if (has_stree) {
      s.static_len += f * (stree[n * 2 + 1] + xbits);
    }
  }
  if (overflow === 0) {
    return;
  }
  do {
    bits = max_length - 1;
    while (s.bl_count[bits] === 0) {
      bits--;
    }
    s.bl_count[bits]--;
    s.bl_count[bits + 1] += 2;
    s.bl_count[max_length]--;
    overflow -= 2;
  } while (overflow > 0);
  for (bits = max_length; bits !== 0; bits--) {
    n = s.bl_count[bits];
    while (n !== 0) {
      m = s.heap[--h];
      if (m > max_code) {
        continue;
      }
      if (tree[m * 2 + 1] !== bits) {
        s.opt_len += (bits - tree[m * 2 + 1]) * tree[m * 2];
        tree[m * 2 + 1] = bits;
      }
      n--;
    }
  }
};
var gen_codes = (tree, max_code, bl_count) => {
  const next_code = new Array(MAX_BITS$1 + 1);
  let code = 0;
  let bits;
  let n;
  for (bits = 1; bits <= MAX_BITS$1; bits++) {
    code = code + bl_count[bits - 1] << 1;
    next_code[bits] = code;
  }
  for (n = 0; n <= max_code; n++) {
    let len = tree[n * 2 + 1];
    if (len === 0) {
      continue;
    }
    tree[n * 2] = bi_reverse(next_code[len]++, len);
  }
};
var tr_static_init = () => {
  let n;
  let bits;
  let length;
  let code;
  let dist;
  const bl_count = new Array(MAX_BITS$1 + 1);
  length = 0;
  for (code = 0; code < LENGTH_CODES$1 - 1; code++) {
    base_length[code] = length;
    for (n = 0; n < 1 << extra_lbits[code]; n++) {
      _length_code[length++] = code;
    }
  }
  _length_code[length - 1] = code;
  dist = 0;
  for (code = 0; code < 16; code++) {
    base_dist[code] = dist;
    for (n = 0; n < 1 << extra_dbits[code]; n++) {
      _dist_code[dist++] = code;
    }
  }
  dist >>= 7;
  for (; code < D_CODES$1; code++) {
    base_dist[code] = dist << 7;
    for (n = 0; n < 1 << extra_dbits[code] - 7; n++) {
      _dist_code[256 + dist++] = code;
    }
  }
  for (bits = 0; bits <= MAX_BITS$1; bits++) {
    bl_count[bits] = 0;
  }
  n = 0;
  while (n <= 143) {
    static_ltree[n * 2 + 1] = 8;
    n++;
    bl_count[8]++;
  }
  while (n <= 255) {
    static_ltree[n * 2 + 1] = 9;
    n++;
    bl_count[9]++;
  }
  while (n <= 279) {
    static_ltree[n * 2 + 1] = 7;
    n++;
    bl_count[7]++;
  }
  while (n <= 287) {
    static_ltree[n * 2 + 1] = 8;
    n++;
    bl_count[8]++;
  }
  gen_codes(static_ltree, L_CODES$1 + 1, bl_count);
  for (n = 0; n < D_CODES$1; n++) {
    static_dtree[n * 2 + 1] = 5;
    static_dtree[n * 2] = bi_reverse(n, 5);
  }
  static_l_desc = new StaticTreeDesc(static_ltree, extra_lbits, LITERALS$1 + 1, L_CODES$1, MAX_BITS$1);
  static_d_desc = new StaticTreeDesc(static_dtree, extra_dbits, 0, D_CODES$1, MAX_BITS$1);
  static_bl_desc = new StaticTreeDesc(new Array(0), extra_blbits, 0, BL_CODES$1, MAX_BL_BITS);
};
var init_block = (s) => {
  let n;
  for (n = 0; n < L_CODES$1; n++) {
    s.dyn_ltree[n * 2] = 0;
  }
  for (n = 0; n < D_CODES$1; n++) {
    s.dyn_dtree[n * 2] = 0;
  }
  for (n = 0; n < BL_CODES$1; n++) {
    s.bl_tree[n * 2] = 0;
  }
  s.dyn_ltree[END_BLOCK * 2] = 1;
  s.opt_len = s.static_len = 0;
  s.sym_next = s.matches = 0;
};
var bi_windup = (s) => {
  if (s.bi_valid > 8) {
    put_short(s, s.bi_buf);
  } else if (s.bi_valid > 0) {
    s.pending_buf[s.pending++] = s.bi_buf;
  }
  s.bi_buf = 0;
  s.bi_valid = 0;
};
var smaller = (tree, n, m, depth) => {
  const _n2 = n * 2;
  const _m2 = m * 2;
  return tree[_n2] < tree[_m2] || tree[_n2] === tree[_m2] && depth[n] <= depth[m];
};
var pqdownheap = (s, tree, k) => {
  const v = s.heap[k];
  let j = k << 1;
  while (j <= s.heap_len) {
    if (j < s.heap_len && smaller(tree, s.heap[j + 1], s.heap[j], s.depth)) {
      j++;
    }
    if (smaller(tree, v, s.heap[j], s.depth)) {
      break;
    }
    s.heap[k] = s.heap[j];
    k = j;
    j <<= 1;
  }
  s.heap[k] = v;
};
var compress_block = (s, ltree, dtree) => {
  let dist;
  let lc;
  let sx = 0;
  let code;
  let extra;
  if (s.sym_next !== 0) {
    do {
      dist = s.pending_buf[s.sym_buf + sx++] & 255;
      dist += (s.pending_buf[s.sym_buf + sx++] & 255) << 8;
      lc = s.pending_buf[s.sym_buf + sx++];
      if (dist === 0) {
        send_code(s, lc, ltree);
      } else {
        code = _length_code[lc];
        send_code(s, code + LITERALS$1 + 1, ltree);
        extra = extra_lbits[code];
        if (extra !== 0) {
          lc -= base_length[code];
          send_bits(s, lc, extra);
        }
        dist--;
        code = d_code(dist);
        send_code(s, code, dtree);
        extra = extra_dbits[code];
        if (extra !== 0) {
          dist -= base_dist[code];
          send_bits(s, dist, extra);
        }
      }
    } while (sx < s.sym_next);
  }
  send_code(s, END_BLOCK, ltree);
};
var build_tree = (s, desc) => {
  const tree = desc.dyn_tree;
  const stree = desc.stat_desc.static_tree;
  const has_stree = desc.stat_desc.has_stree;
  const elems = desc.stat_desc.elems;
  let n, m;
  let max_code = -1;
  let node;
  s.heap_len = 0;
  s.heap_max = HEAP_SIZE$1;
  for (n = 0; n < elems; n++) {
    if (tree[n * 2] !== 0) {
      s.heap[++s.heap_len] = max_code = n;
      s.depth[n] = 0;
    } else {
      tree[n * 2 + 1] = 0;
    }
  }
  while (s.heap_len < 2) {
    node = s.heap[++s.heap_len] = max_code < 2 ? ++max_code : 0;
    tree[node * 2] = 1;
    s.depth[node] = 0;
    s.opt_len--;
    if (has_stree) {
      s.static_len -= stree[node * 2 + 1];
    }
  }
  desc.max_code = max_code;
  for (n = s.heap_len >> 1; n >= 1; n--) {
    pqdownheap(s, tree, n);
  }
  node = elems;
  do {
    n = s.heap[
      1
      /*SMALLEST*/
    ];
    s.heap[
      1
      /*SMALLEST*/
    ] = s.heap[s.heap_len--];
    pqdownheap(
      s,
      tree,
      1
      /*SMALLEST*/
    );
    m = s.heap[
      1
      /*SMALLEST*/
    ];
    s.heap[--s.heap_max] = n;
    s.heap[--s.heap_max] = m;
    tree[node * 2] = tree[n * 2] + tree[m * 2];
    s.depth[node] = (s.depth[n] >= s.depth[m] ? s.depth[n] : s.depth[m]) + 1;
    tree[n * 2 + 1] = tree[m * 2 + 1] = node;
    s.heap[
      1
      /*SMALLEST*/
    ] = node++;
    pqdownheap(
      s,
      tree,
      1
      /*SMALLEST*/
    );
  } while (s.heap_len >= 2);
  s.heap[--s.heap_max] = s.heap[
    1
    /*SMALLEST*/
  ];
  gen_bitlen(s, desc);
  gen_codes(tree, max_code, s.bl_count);
};
var scan_tree = (s, tree, max_code) => {
  let n;
  let prevlen = -1;
  let curlen;
  let nextlen = tree[0 * 2 + 1];
  let count = 0;
  let max_count = 7;
  let min_count = 4;
  if (nextlen === 0) {
    max_count = 138;
    min_count = 3;
  }
  tree[(max_code + 1) * 2 + 1] = 65535;
  for (n = 0; n <= max_code; n++) {
    curlen = nextlen;
    nextlen = tree[(n + 1) * 2 + 1];
    if (++count < max_count && curlen === nextlen) {
      continue;
    } else if (count < min_count) {
      s.bl_tree[curlen * 2] += count;
    } else if (curlen !== 0) {
      if (curlen !== prevlen) {
        s.bl_tree[curlen * 2]++;
      }
      s.bl_tree[REP_3_6 * 2]++;
    } else if (count <= 10) {
      s.bl_tree[REPZ_3_10 * 2]++;
    } else {
      s.bl_tree[REPZ_11_138 * 2]++;
    }
    count = 0;
    prevlen = curlen;
    if (nextlen === 0) {
      max_count = 138;
      min_count = 3;
    } else if (curlen === nextlen) {
      max_count = 6;
      min_count = 3;
    } else {
      max_count = 7;
      min_count = 4;
    }
  }
};
var send_tree = (s, tree, max_code) => {
  let n;
  let prevlen = -1;
  let curlen;
  let nextlen = tree[0 * 2 + 1];
  let count = 0;
  let max_count = 7;
  let min_count = 4;
  if (nextlen === 0) {
    max_count = 138;
    min_count = 3;
  }
  for (n = 0; n <= max_code; n++) {
    curlen = nextlen;
    nextlen = tree[(n + 1) * 2 + 1];
    if (++count < max_count && curlen === nextlen) {
      continue;
    } else if (count < min_count) {
      do {
        send_code(s, curlen, s.bl_tree);
      } while (--count !== 0);
    } else if (curlen !== 0) {
      if (curlen !== prevlen) {
        send_code(s, curlen, s.bl_tree);
        count--;
      }
      send_code(s, REP_3_6, s.bl_tree);
      send_bits(s, count - 3, 2);
    } else if (count <= 10) {
      send_code(s, REPZ_3_10, s.bl_tree);
      send_bits(s, count - 3, 3);
    } else {
      send_code(s, REPZ_11_138, s.bl_tree);
      send_bits(s, count - 11, 7);
    }
    count = 0;
    prevlen = curlen;
    if (nextlen === 0) {
      max_count = 138;
      min_count = 3;
    } else if (curlen === nextlen) {
      max_count = 6;
      min_count = 3;
    } else {
      max_count = 7;
      min_count = 4;
    }
  }
};
var build_bl_tree = (s) => {
  let max_blindex;
  scan_tree(s, s.dyn_ltree, s.l_desc.max_code);
  scan_tree(s, s.dyn_dtree, s.d_desc.max_code);
  build_tree(s, s.bl_desc);
  for (max_blindex = BL_CODES$1 - 1; max_blindex >= 3; max_blindex--) {
    if (s.bl_tree[bl_order[max_blindex] * 2 + 1] !== 0) {
      break;
    }
  }
  s.opt_len += 3 * (max_blindex + 1) + 5 + 5 + 4;
  return max_blindex;
};
var send_all_trees = (s, lcodes, dcodes, blcodes) => {
  let rank2;
  send_bits(s, lcodes - 257, 5);
  send_bits(s, dcodes - 1, 5);
  send_bits(s, blcodes - 4, 4);
  for (rank2 = 0; rank2 < blcodes; rank2++) {
    send_bits(s, s.bl_tree[bl_order[rank2] * 2 + 1], 3);
  }
  send_tree(s, s.dyn_ltree, lcodes - 1);
  send_tree(s, s.dyn_dtree, dcodes - 1);
};
var detect_data_type = (s) => {
  let block_mask = 4093624447;
  let n;
  for (n = 0; n <= 31; n++, block_mask >>>= 1) {
    if (block_mask & 1 && s.dyn_ltree[n * 2] !== 0) {
      return Z_BINARY;
    }
  }
  if (s.dyn_ltree[9 * 2] !== 0 || s.dyn_ltree[10 * 2] !== 0 || s.dyn_ltree[13 * 2] !== 0) {
    return Z_TEXT;
  }
  for (n = 32; n < LITERALS$1; n++) {
    if (s.dyn_ltree[n * 2] !== 0) {
      return Z_TEXT;
    }
  }
  return Z_BINARY;
};
var static_init_done = false;
var _tr_init$1 = (s) => {
  if (!static_init_done) {
    tr_static_init();
    static_init_done = true;
  }
  s.l_desc = new TreeDesc(s.dyn_ltree, static_l_desc);
  s.d_desc = new TreeDesc(s.dyn_dtree, static_d_desc);
  s.bl_desc = new TreeDesc(s.bl_tree, static_bl_desc);
  s.bi_buf = 0;
  s.bi_valid = 0;
  init_block(s);
};
var _tr_stored_block$1 = (s, buf, stored_len, last) => {
  send_bits(s, (STORED_BLOCK << 1) + (last ? 1 : 0), 3);
  bi_windup(s);
  put_short(s, stored_len);
  put_short(s, ~stored_len);
  if (stored_len) {
    s.pending_buf.set(s.window.subarray(buf, buf + stored_len), s.pending);
  }
  s.pending += stored_len;
};
var _tr_align$1 = (s) => {
  send_bits(s, STATIC_TREES << 1, 3);
  send_code(s, END_BLOCK, static_ltree);
  bi_flush(s);
};
var _tr_flush_block$1 = (s, buf, stored_len, last) => {
  let opt_lenb, static_lenb;
  let max_blindex = 0;
  if (s.level > 0) {
    if (s.strm.data_type === Z_UNKNOWN$1) {
      s.strm.data_type = detect_data_type(s);
    }
    build_tree(s, s.l_desc);
    build_tree(s, s.d_desc);
    max_blindex = build_bl_tree(s);
    opt_lenb = s.opt_len + 3 + 7 >>> 3;
    static_lenb = s.static_len + 3 + 7 >>> 3;
    if (static_lenb <= opt_lenb) {
      opt_lenb = static_lenb;
    }
  } else {
    opt_lenb = static_lenb = stored_len + 5;
  }
  if (stored_len + 4 <= opt_lenb && buf !== -1) {
    _tr_stored_block$1(s, buf, stored_len, last);
  } else if (s.strategy === Z_FIXED$1 || static_lenb === opt_lenb) {
    send_bits(s, (STATIC_TREES << 1) + (last ? 1 : 0), 3);
    compress_block(s, static_ltree, static_dtree);
  } else {
    send_bits(s, (DYN_TREES << 1) + (last ? 1 : 0), 3);
    send_all_trees(s, s.l_desc.max_code + 1, s.d_desc.max_code + 1, max_blindex + 1);
    compress_block(s, s.dyn_ltree, s.dyn_dtree);
  }
  init_block(s);
  if (last) {
    bi_windup(s);
  }
};
var _tr_tally$1 = (s, dist, lc) => {
  s.pending_buf[s.sym_buf + s.sym_next++] = dist;
  s.pending_buf[s.sym_buf + s.sym_next++] = dist >> 8;
  s.pending_buf[s.sym_buf + s.sym_next++] = lc;
  if (dist === 0) {
    s.dyn_ltree[lc * 2]++;
  } else {
    s.matches++;
    dist--;
    s.dyn_ltree[(_length_code[lc] + LITERALS$1 + 1) * 2]++;
    s.dyn_dtree[d_code(dist) * 2]++;
  }
  return s.sym_next === s.sym_end;
};
var _tr_init_1 = _tr_init$1;
var _tr_stored_block_1 = _tr_stored_block$1;
var _tr_flush_block_1 = _tr_flush_block$1;
var _tr_tally_1 = _tr_tally$1;
var _tr_align_1 = _tr_align$1;
var trees = {
  _tr_init: _tr_init_1,
  _tr_stored_block: _tr_stored_block_1,
  _tr_flush_block: _tr_flush_block_1,
  _tr_tally: _tr_tally_1,
  _tr_align: _tr_align_1
};
var adler32 = (adler, buf, len, pos) => {
  let s1 = adler & 65535 | 0, s2 = adler >>> 16 & 65535 | 0, n = 0;
  while (len !== 0) {
    n = len > 2e3 ? 2e3 : len;
    len -= n;
    do {
      s1 = s1 + buf[pos++] | 0;
      s2 = s2 + s1 | 0;
    } while (--n);
    s1 %= 65521;
    s2 %= 65521;
  }
  return s1 | s2 << 16 | 0;
};
var adler32_1 = adler32;
var makeTable = () => {
  let c, table = [];
  for (var n = 0; n < 256; n++) {
    c = n;
    for (var k = 0; k < 8; k++) {
      c = c & 1 ? 3988292384 ^ c >>> 1 : c >>> 1;
    }
    table[n] = c;
  }
  return table;
};
var crcTable = new Uint32Array(makeTable());
var crc32 = (crc, buf, len, pos) => {
  const t = crcTable;
  const end = pos + len;
  crc ^= -1;
  for (let i = pos; i < end; i++) {
    crc = crc >>> 8 ^ t[(crc ^ buf[i]) & 255];
  }
  return crc ^ -1;
};
var crc32_1 = crc32;
var messages = {
  2: "need dictionary",
  /* Z_NEED_DICT       2  */
  1: "stream end",
  /* Z_STREAM_END      1  */
  0: "",
  /* Z_OK              0  */
  "-1": "file error",
  /* Z_ERRNO         (-1) */
  "-2": "stream error",
  /* Z_STREAM_ERROR  (-2) */
  "-3": "data error",
  /* Z_DATA_ERROR    (-3) */
  "-4": "insufficient memory",
  /* Z_MEM_ERROR     (-4) */
  "-5": "buffer error",
  /* Z_BUF_ERROR     (-5) */
  "-6": "incompatible version"
  /* Z_VERSION_ERROR (-6) */
};
var constants$2 = {
  /* Allowed flush values; see deflate() and inflate() below for details */
  Z_NO_FLUSH: 0,
  Z_PARTIAL_FLUSH: 1,
  Z_SYNC_FLUSH: 2,
  Z_FULL_FLUSH: 3,
  Z_FINISH: 4,
  Z_BLOCK: 5,
  Z_TREES: 6,
  /* Return codes for the compression/decompression functions. Negative values
  * are errors, positive values are used for special but normal events.
  */
  Z_OK: 0,
  Z_STREAM_END: 1,
  Z_NEED_DICT: 2,
  Z_ERRNO: -1,
  Z_STREAM_ERROR: -2,
  Z_DATA_ERROR: -3,
  Z_MEM_ERROR: -4,
  Z_BUF_ERROR: -5,
  //Z_VERSION_ERROR: -6,
  /* compression levels */
  Z_NO_COMPRESSION: 0,
  Z_BEST_SPEED: 1,
  Z_BEST_COMPRESSION: 9,
  Z_DEFAULT_COMPRESSION: -1,
  Z_FILTERED: 1,
  Z_HUFFMAN_ONLY: 2,
  Z_RLE: 3,
  Z_FIXED: 4,
  Z_DEFAULT_STRATEGY: 0,
  /* Possible values of the data_type field (though see inflate()) */
  Z_BINARY: 0,
  Z_TEXT: 1,
  //Z_ASCII:                1, // = Z_TEXT (deprecated)
  Z_UNKNOWN: 2,
  /* The deflate compression method */
  Z_DEFLATED: 8
  //Z_NULL:                 null // Use -1 or null inline, depending on var type
};
var { _tr_init, _tr_stored_block, _tr_flush_block, _tr_tally, _tr_align } = trees;
var {
  Z_NO_FLUSH: Z_NO_FLUSH$2,
  Z_PARTIAL_FLUSH,
  Z_FULL_FLUSH: Z_FULL_FLUSH$1,
  Z_FINISH: Z_FINISH$3,
  Z_BLOCK: Z_BLOCK$1,
  Z_OK: Z_OK$3,
  Z_STREAM_END: Z_STREAM_END$3,
  Z_STREAM_ERROR: Z_STREAM_ERROR$2,
  Z_DATA_ERROR: Z_DATA_ERROR$2,
  Z_BUF_ERROR: Z_BUF_ERROR$1,
  Z_DEFAULT_COMPRESSION: Z_DEFAULT_COMPRESSION$1,
  Z_FILTERED,
  Z_HUFFMAN_ONLY,
  Z_RLE,
  Z_FIXED,
  Z_DEFAULT_STRATEGY: Z_DEFAULT_STRATEGY$1,
  Z_UNKNOWN,
  Z_DEFLATED: Z_DEFLATED$2
} = constants$2;
var MAX_MEM_LEVEL = 9;
var MAX_WBITS$1 = 15;
var DEF_MEM_LEVEL = 8;
var LENGTH_CODES = 29;
var LITERALS = 256;
var L_CODES = LITERALS + 1 + LENGTH_CODES;
var D_CODES = 30;
var BL_CODES = 19;
var HEAP_SIZE = 2 * L_CODES + 1;
var MAX_BITS = 15;
var MIN_MATCH = 3;
var MAX_MATCH = 258;
var MIN_LOOKAHEAD = MAX_MATCH + MIN_MATCH + 1;
var PRESET_DICT = 32;
var INIT_STATE = 42;
var GZIP_STATE = 57;
var EXTRA_STATE = 69;
var NAME_STATE = 73;
var COMMENT_STATE = 91;
var HCRC_STATE = 103;
var BUSY_STATE = 113;
var FINISH_STATE = 666;
var BS_NEED_MORE = 1;
var BS_BLOCK_DONE = 2;
var BS_FINISH_STARTED = 3;
var BS_FINISH_DONE = 4;
var OS_CODE = 3;
var err = (strm, errorCode) => {
  strm.msg = messages[errorCode];
  return errorCode;
};
var rank = (f) => {
  return f * 2 - (f > 4 ? 9 : 0);
};
var zero = (buf) => {
  let len = buf.length;
  while (--len >= 0) {
    buf[len] = 0;
  }
};
var slide_hash = (s) => {
  let n, m;
  let p;
  let wsize = s.w_size;
  n = s.hash_size;
  p = n;
  do {
    m = s.head[--p];
    s.head[p] = m >= wsize ? m - wsize : 0;
  } while (--n);
  n = wsize;
  p = n;
  do {
    m = s.prev[--p];
    s.prev[p] = m >= wsize ? m - wsize : 0;
  } while (--n);
};
var HASH_ZLIB = (s, prev, data) => (prev << s.hash_shift ^ data) & s.hash_mask;
var HASH = HASH_ZLIB;
var flush_pending = (strm) => {
  const s = strm.state;
  let len = s.pending;
  if (len > strm.avail_out) {
    len = strm.avail_out;
  }
  if (len === 0) {
    return;
  }
  strm.output.set(s.pending_buf.subarray(s.pending_out, s.pending_out + len), strm.next_out);
  strm.next_out += len;
  s.pending_out += len;
  strm.total_out += len;
  strm.avail_out -= len;
  s.pending -= len;
  if (s.pending === 0) {
    s.pending_out = 0;
  }
};
var flush_block_only = (s, last) => {
  _tr_flush_block(s, s.block_start >= 0 ? s.block_start : -1, s.strstart - s.block_start, last);
  s.block_start = s.strstart;
  flush_pending(s.strm);
};
var put_byte = (s, b) => {
  s.pending_buf[s.pending++] = b;
};
var putShortMSB = (s, b) => {
  s.pending_buf[s.pending++] = b >>> 8 & 255;
  s.pending_buf[s.pending++] = b & 255;
};
var read_buf = (strm, buf, start, size) => {
  let len = strm.avail_in;
  if (len > size) {
    len = size;
  }
  if (len === 0) {
    return 0;
  }
  strm.avail_in -= len;
  buf.set(strm.input.subarray(strm.next_in, strm.next_in + len), start);
  if (strm.state.wrap === 1) {
    strm.adler = adler32_1(strm.adler, buf, len, start);
  } else if (strm.state.wrap === 2) {
    strm.adler = crc32_1(strm.adler, buf, len, start);
  }
  strm.next_in += len;
  strm.total_in += len;
  return len;
};
var longest_match = (s, cur_match) => {
  let chain_length = s.max_chain_length;
  let scan = s.strstart;
  let match;
  let len;
  let best_len = s.prev_length;
  let nice_match = s.nice_match;
  const limit = s.strstart > s.w_size - MIN_LOOKAHEAD ? s.strstart - (s.w_size - MIN_LOOKAHEAD) : 0;
  const _win = s.window;
  const wmask = s.w_mask;
  const prev = s.prev;
  const strend = s.strstart + MAX_MATCH;
  let scan_end1 = _win[scan + best_len - 1];
  let scan_end = _win[scan + best_len];
  if (s.prev_length >= s.good_match) {
    chain_length >>= 2;
  }
  if (nice_match > s.lookahead) {
    nice_match = s.lookahead;
  }
  do {
    match = cur_match;
    if (_win[match + best_len] !== scan_end || _win[match + best_len - 1] !== scan_end1 || _win[match] !== _win[scan] || _win[++match] !== _win[scan + 1]) {
      continue;
    }
    scan += 2;
    match++;
    do {
    } while (_win[++scan] === _win[++match] && _win[++scan] === _win[++match] && _win[++scan] === _win[++match] && _win[++scan] === _win[++match] && _win[++scan] === _win[++match] && _win[++scan] === _win[++match] && _win[++scan] === _win[++match] && _win[++scan] === _win[++match] && scan < strend);
    len = MAX_MATCH - (strend - scan);
    scan = strend - MAX_MATCH;
    if (len > best_len) {
      s.match_start = cur_match;
      best_len = len;
      if (len >= nice_match) {
        break;
      }
      scan_end1 = _win[scan + best_len - 1];
      scan_end = _win[scan + best_len];
    }
  } while ((cur_match = prev[cur_match & wmask]) > limit && --chain_length !== 0);
  if (best_len <= s.lookahead) {
    return best_len;
  }
  return s.lookahead;
};
var fill_window = (s) => {
  const _w_size = s.w_size;
  let n, more, str;
  do {
    more = s.window_size - s.lookahead - s.strstart;
    if (s.strstart >= _w_size + (_w_size - MIN_LOOKAHEAD)) {
      s.window.set(s.window.subarray(_w_size, _w_size + _w_size - more), 0);
      s.match_start -= _w_size;
      s.strstart -= _w_size;
      s.block_start -= _w_size;
      if (s.insert > s.strstart) {
        s.insert = s.strstart;
      }
      slide_hash(s);
      more += _w_size;
    }
    if (s.strm.avail_in === 0) {
      break;
    }
    n = read_buf(s.strm, s.window, s.strstart + s.lookahead, more);
    s.lookahead += n;
    if (s.lookahead + s.insert >= MIN_MATCH) {
      str = s.strstart - s.insert;
      s.ins_h = s.window[str];
      s.ins_h = HASH(s, s.ins_h, s.window[str + 1]);
      while (s.insert) {
        s.ins_h = HASH(s, s.ins_h, s.window[str + MIN_MATCH - 1]);
        s.prev[str & s.w_mask] = s.head[s.ins_h];
        s.head[s.ins_h] = str;
        str++;
        s.insert--;
        if (s.lookahead + s.insert < MIN_MATCH) {
          break;
        }
      }
    }
  } while (s.lookahead < MIN_LOOKAHEAD && s.strm.avail_in !== 0);
};
var deflate_stored = (s, flush) => {
  let min_block = s.pending_buf_size - 5 > s.w_size ? s.w_size : s.pending_buf_size - 5;
  let len, left, have, last = 0;
  let used = s.strm.avail_in;
  do {
    len = 65535;
    have = s.bi_valid + 42 >> 3;
    if (s.strm.avail_out < have) {
      break;
    }
    have = s.strm.avail_out - have;
    left = s.strstart - s.block_start;
    if (len > left + s.strm.avail_in) {
      len = left + s.strm.avail_in;
    }
    if (len > have) {
      len = have;
    }
    if (len < min_block && (len === 0 && flush !== Z_FINISH$3 || flush === Z_NO_FLUSH$2 || len !== left + s.strm.avail_in)) {
      break;
    }
    last = flush === Z_FINISH$3 && len === left + s.strm.avail_in ? 1 : 0;
    _tr_stored_block(s, 0, 0, last);
    s.pending_buf[s.pending - 4] = len;
    s.pending_buf[s.pending - 3] = len >> 8;
    s.pending_buf[s.pending - 2] = ~len;
    s.pending_buf[s.pending - 1] = ~len >> 8;
    flush_pending(s.strm);
    if (left) {
      if (left > len) {
        left = len;
      }
      s.strm.output.set(s.window.subarray(s.block_start, s.block_start + left), s.strm.next_out);
      s.strm.next_out += left;
      s.strm.avail_out -= left;
      s.strm.total_out += left;
      s.block_start += left;
      len -= left;
    }
    if (len) {
      read_buf(s.strm, s.strm.output, s.strm.next_out, len);
      s.strm.next_out += len;
      s.strm.avail_out -= len;
      s.strm.total_out += len;
    }
  } while (last === 0);
  used -= s.strm.avail_in;
  if (used) {
    if (used >= s.w_size) {
      s.matches = 2;
      s.window.set(s.strm.input.subarray(s.strm.next_in - s.w_size, s.strm.next_in), 0);
      s.strstart = s.w_size;
      s.insert = s.strstart;
    } else {
      if (s.window_size - s.strstart <= used) {
        s.strstart -= s.w_size;
        s.window.set(s.window.subarray(s.w_size, s.w_size + s.strstart), 0);
        if (s.matches < 2) {
          s.matches++;
        }
        if (s.insert > s.strstart) {
          s.insert = s.strstart;
        }
      }
      s.window.set(s.strm.input.subarray(s.strm.next_in - used, s.strm.next_in), s.strstart);
      s.strstart += used;
      s.insert += used > s.w_size - s.insert ? s.w_size - s.insert : used;
    }
    s.block_start = s.strstart;
  }
  if (s.high_water < s.strstart) {
    s.high_water = s.strstart;
  }
  if (last) {
    return BS_FINISH_DONE;
  }
  if (flush !== Z_NO_FLUSH$2 && flush !== Z_FINISH$3 && s.strm.avail_in === 0 && s.strstart === s.block_start) {
    return BS_BLOCK_DONE;
  }
  have = s.window_size - s.strstart;
  if (s.strm.avail_in > have && s.block_start >= s.w_size) {
    s.block_start -= s.w_size;
    s.strstart -= s.w_size;
    s.window.set(s.window.subarray(s.w_size, s.w_size + s.strstart), 0);
    if (s.matches < 2) {
      s.matches++;
    }
    have += s.w_size;
    if (s.insert > s.strstart) {
      s.insert = s.strstart;
    }
  }
  if (have > s.strm.avail_in) {
    have = s.strm.avail_in;
  }
  if (have) {
    read_buf(s.strm, s.window, s.strstart, have);
    s.strstart += have;
    s.insert += have > s.w_size - s.insert ? s.w_size - s.insert : have;
  }
  if (s.high_water < s.strstart) {
    s.high_water = s.strstart;
  }
  have = s.bi_valid + 42 >> 3;
  have = s.pending_buf_size - have > 65535 ? 65535 : s.pending_buf_size - have;
  min_block = have > s.w_size ? s.w_size : have;
  left = s.strstart - s.block_start;
  if (left >= min_block || (left || flush === Z_FINISH$3) && flush !== Z_NO_FLUSH$2 && s.strm.avail_in === 0 && left <= have) {
    len = left > have ? have : left;
    last = flush === Z_FINISH$3 && s.strm.avail_in === 0 && len === left ? 1 : 0;
    _tr_stored_block(s, s.block_start, len, last);
    s.block_start += len;
    flush_pending(s.strm);
  }
  return last ? BS_FINISH_STARTED : BS_NEED_MORE;
};
var deflate_fast = (s, flush) => {
  let hash_head;
  let bflush;
  for (; ; ) {
    if (s.lookahead < MIN_LOOKAHEAD) {
      fill_window(s);
      if (s.lookahead < MIN_LOOKAHEAD && flush === Z_NO_FLUSH$2) {
        return BS_NEED_MORE;
      }
      if (s.lookahead === 0) {
        break;
      }
    }
    hash_head = 0;
    if (s.lookahead >= MIN_MATCH) {
      s.ins_h = HASH(s, s.ins_h, s.window[s.strstart + MIN_MATCH - 1]);
      hash_head = s.prev[s.strstart & s.w_mask] = s.head[s.ins_h];
      s.head[s.ins_h] = s.strstart;
    }
    if (hash_head !== 0 && s.strstart - hash_head <= s.w_size - MIN_LOOKAHEAD) {
      s.match_length = longest_match(s, hash_head);
    }
    if (s.match_length >= MIN_MATCH) {
      bflush = _tr_tally(s, s.strstart - s.match_start, s.match_length - MIN_MATCH);
      s.lookahead -= s.match_length;
      if (s.match_length <= s.max_lazy_match && s.lookahead >= MIN_MATCH) {
        s.match_length--;
        do {
          s.strstart++;
          s.ins_h = HASH(s, s.ins_h, s.window[s.strstart + MIN_MATCH - 1]);
          hash_head = s.prev[s.strstart & s.w_mask] = s.head[s.ins_h];
          s.head[s.ins_h] = s.strstart;
        } while (--s.match_length !== 0);
        s.strstart++;
      } else {
        s.strstart += s.match_length;
        s.match_length = 0;
        s.ins_h = s.window[s.strstart];
        s.ins_h = HASH(s, s.ins_h, s.window[s.strstart + 1]);
      }
    } else {
      bflush = _tr_tally(s, 0, s.window[s.strstart]);
      s.lookahead--;
      s.strstart++;
    }
    if (bflush) {
      flush_block_only(s, false);
      if (s.strm.avail_out === 0) {
        return BS_NEED_MORE;
      }
    }
  }
  s.insert = s.strstart < MIN_MATCH - 1 ? s.strstart : MIN_MATCH - 1;
  if (flush === Z_FINISH$3) {
    flush_block_only(s, true);
    if (s.strm.avail_out === 0) {
      return BS_FINISH_STARTED;
    }
    return BS_FINISH_DONE;
  }
  if (s.sym_next) {
    flush_block_only(s, false);
    if (s.strm.avail_out === 0) {
      return BS_NEED_MORE;
    }
  }
  return BS_BLOCK_DONE;
};
var deflate_slow = (s, flush) => {
  let hash_head;
  let bflush;
  let max_insert;
  for (; ; ) {
    if (s.lookahead < MIN_LOOKAHEAD) {
      fill_window(s);
      if (s.lookahead < MIN_LOOKAHEAD && flush === Z_NO_FLUSH$2) {
        return BS_NEED_MORE;
      }
      if (s.lookahead === 0) {
        break;
      }
    }
    hash_head = 0;
    if (s.lookahead >= MIN_MATCH) {
      s.ins_h = HASH(s, s.ins_h, s.window[s.strstart + MIN_MATCH - 1]);
      hash_head = s.prev[s.strstart & s.w_mask] = s.head[s.ins_h];
      s.head[s.ins_h] = s.strstart;
    }
    s.prev_length = s.match_length;
    s.prev_match = s.match_start;
    s.match_length = MIN_MATCH - 1;
    if (hash_head !== 0 && s.prev_length < s.max_lazy_match && s.strstart - hash_head <= s.w_size - MIN_LOOKAHEAD) {
      s.match_length = longest_match(s, hash_head);
      if (s.match_length <= 5 && (s.strategy === Z_FILTERED || s.match_length === MIN_MATCH && s.strstart - s.match_start > 4096)) {
        s.match_length = MIN_MATCH - 1;
      }
    }
    if (s.prev_length >= MIN_MATCH && s.match_length <= s.prev_length) {
      max_insert = s.strstart + s.lookahead - MIN_MATCH;
      bflush = _tr_tally(s, s.strstart - 1 - s.prev_match, s.prev_length - MIN_MATCH);
      s.lookahead -= s.prev_length - 1;
      s.prev_length -= 2;
      do {
        if (++s.strstart <= max_insert) {
          s.ins_h = HASH(s, s.ins_h, s.window[s.strstart + MIN_MATCH - 1]);
          hash_head = s.prev[s.strstart & s.w_mask] = s.head[s.ins_h];
          s.head[s.ins_h] = s.strstart;
        }
      } while (--s.prev_length !== 0);
      s.match_available = 0;
      s.match_length = MIN_MATCH - 1;
      s.strstart++;
      if (bflush) {
        flush_block_only(s, false);
        if (s.strm.avail_out === 0) {
          return BS_NEED_MORE;
        }
      }
    } else if (s.match_available) {
      bflush = _tr_tally(s, 0, s.window[s.strstart - 1]);
      if (bflush) {
        flush_block_only(s, false);
      }
      s.strstart++;
      s.lookahead--;
      if (s.strm.avail_out === 0) {
        return BS_NEED_MORE;
      }
    } else {
      s.match_available = 1;
      s.strstart++;
      s.lookahead--;
    }
  }
  if (s.match_available) {
    bflush = _tr_tally(s, 0, s.window[s.strstart - 1]);
    s.match_available = 0;
  }
  s.insert = s.strstart < MIN_MATCH - 1 ? s.strstart : MIN_MATCH - 1;
  if (flush === Z_FINISH$3) {
    flush_block_only(s, true);
    if (s.strm.avail_out === 0) {
      return BS_FINISH_STARTED;
    }
    return BS_FINISH_DONE;
  }
  if (s.sym_next) {
    flush_block_only(s, false);
    if (s.strm.avail_out === 0) {
      return BS_NEED_MORE;
    }
  }
  return BS_BLOCK_DONE;
};
var deflate_rle = (s, flush) => {
  let bflush;
  let prev;
  let scan, strend;
  const _win = s.window;
  for (; ; ) {
    if (s.lookahead <= MAX_MATCH) {
      fill_window(s);
      if (s.lookahead <= MAX_MATCH && flush === Z_NO_FLUSH$2) {
        return BS_NEED_MORE;
      }
      if (s.lookahead === 0) {
        break;
      }
    }
    s.match_length = 0;
    if (s.lookahead >= MIN_MATCH && s.strstart > 0) {
      scan = s.strstart - 1;
      prev = _win[scan];
      if (prev === _win[++scan] && prev === _win[++scan] && prev === _win[++scan]) {
        strend = s.strstart + MAX_MATCH;
        do {
        } while (prev === _win[++scan] && prev === _win[++scan] && prev === _win[++scan] && prev === _win[++scan] && prev === _win[++scan] && prev === _win[++scan] && prev === _win[++scan] && prev === _win[++scan] && scan < strend);
        s.match_length = MAX_MATCH - (strend - scan);
        if (s.match_length > s.lookahead) {
          s.match_length = s.lookahead;
        }
      }
    }
    if (s.match_length >= MIN_MATCH) {
      bflush = _tr_tally(s, 1, s.match_length - MIN_MATCH);
      s.lookahead -= s.match_length;
      s.strstart += s.match_length;
      s.match_length = 0;
    } else {
      bflush = _tr_tally(s, 0, s.window[s.strstart]);
      s.lookahead--;
      s.strstart++;
    }
    if (bflush) {
      flush_block_only(s, false);
      if (s.strm.avail_out === 0) {
        return BS_NEED_MORE;
      }
    }
  }
  s.insert = 0;
  if (flush === Z_FINISH$3) {
    flush_block_only(s, true);
    if (s.strm.avail_out === 0) {
      return BS_FINISH_STARTED;
    }
    return BS_FINISH_DONE;
  }
  if (s.sym_next) {
    flush_block_only(s, false);
    if (s.strm.avail_out === 0) {
      return BS_NEED_MORE;
    }
  }
  return BS_BLOCK_DONE;
};
var deflate_huff = (s, flush) => {
  let bflush;
  for (; ; ) {
    if (s.lookahead === 0) {
      fill_window(s);
      if (s.lookahead === 0) {
        if (flush === Z_NO_FLUSH$2) {
          return BS_NEED_MORE;
        }
        break;
      }
    }
    s.match_length = 0;
    bflush = _tr_tally(s, 0, s.window[s.strstart]);
    s.lookahead--;
    s.strstart++;
    if (bflush) {
      flush_block_only(s, false);
      if (s.strm.avail_out === 0) {
        return BS_NEED_MORE;
      }
    }
  }
  s.insert = 0;
  if (flush === Z_FINISH$3) {
    flush_block_only(s, true);
    if (s.strm.avail_out === 0) {
      return BS_FINISH_STARTED;
    }
    return BS_FINISH_DONE;
  }
  if (s.sym_next) {
    flush_block_only(s, false);
    if (s.strm.avail_out === 0) {
      return BS_NEED_MORE;
    }
  }
  return BS_BLOCK_DONE;
};
function Config(good_length, max_lazy, nice_length, max_chain, func) {
  this.good_length = good_length;
  this.max_lazy = max_lazy;
  this.nice_length = nice_length;
  this.max_chain = max_chain;
  this.func = func;
}
var configuration_table = [
  /*      good lazy nice chain */
  new Config(0, 0, 0, 0, deflate_stored),
  /* 0 store only */
  new Config(4, 4, 8, 4, deflate_fast),
  /* 1 max speed, no lazy matches */
  new Config(4, 5, 16, 8, deflate_fast),
  /* 2 */
  new Config(4, 6, 32, 32, deflate_fast),
  /* 3 */
  new Config(4, 4, 16, 16, deflate_slow),
  /* 4 lazy matches */
  new Config(8, 16, 32, 32, deflate_slow),
  /* 5 */
  new Config(8, 16, 128, 128, deflate_slow),
  /* 6 */
  new Config(8, 32, 128, 256, deflate_slow),
  /* 7 */
  new Config(32, 128, 258, 1024, deflate_slow),
  /* 8 */
  new Config(32, 258, 258, 4096, deflate_slow)
  /* 9 max compression */
];
var lm_init = (s) => {
  s.window_size = 2 * s.w_size;
  zero(s.head);
  s.max_lazy_match = configuration_table[s.level].max_lazy;
  s.good_match = configuration_table[s.level].good_length;
  s.nice_match = configuration_table[s.level].nice_length;
  s.max_chain_length = configuration_table[s.level].max_chain;
  s.strstart = 0;
  s.block_start = 0;
  s.lookahead = 0;
  s.insert = 0;
  s.match_length = s.prev_length = MIN_MATCH - 1;
  s.match_available = 0;
  s.ins_h = 0;
};
function DeflateState() {
  this.strm = null;
  this.status = 0;
  this.pending_buf = null;
  this.pending_buf_size = 0;
  this.pending_out = 0;
  this.pending = 0;
  this.wrap = 0;
  this.gzhead = null;
  this.gzindex = 0;
  this.method = Z_DEFLATED$2;
  this.last_flush = -1;
  this.w_size = 0;
  this.w_bits = 0;
  this.w_mask = 0;
  this.window = null;
  this.window_size = 0;
  this.prev = null;
  this.head = null;
  this.ins_h = 0;
  this.hash_size = 0;
  this.hash_bits = 0;
  this.hash_mask = 0;
  this.hash_shift = 0;
  this.block_start = 0;
  this.match_length = 0;
  this.prev_match = 0;
  this.match_available = 0;
  this.strstart = 0;
  this.match_start = 0;
  this.lookahead = 0;
  this.prev_length = 0;
  this.max_chain_length = 0;
  this.max_lazy_match = 0;
  this.level = 0;
  this.strategy = 0;
  this.good_match = 0;
  this.nice_match = 0;
  this.dyn_ltree = new Uint16Array(HEAP_SIZE * 2);
  this.dyn_dtree = new Uint16Array((2 * D_CODES + 1) * 2);
  this.bl_tree = new Uint16Array((2 * BL_CODES + 1) * 2);
  zero(this.dyn_ltree);
  zero(this.dyn_dtree);
  zero(this.bl_tree);
  this.l_desc = null;
  this.d_desc = null;
  this.bl_desc = null;
  this.bl_count = new Uint16Array(MAX_BITS + 1);
  this.heap = new Uint16Array(2 * L_CODES + 1);
  zero(this.heap);
  this.heap_len = 0;
  this.heap_max = 0;
  this.depth = new Uint16Array(2 * L_CODES + 1);
  zero(this.depth);
  this.sym_buf = 0;
  this.lit_bufsize = 0;
  this.sym_next = 0;
  this.sym_end = 0;
  this.opt_len = 0;
  this.static_len = 0;
  this.matches = 0;
  this.insert = 0;
  this.bi_buf = 0;
  this.bi_valid = 0;
}
var deflateStateCheck = (strm) => {
  if (!strm) {
    return 1;
  }
  const s = strm.state;
  if (!s || s.strm !== strm || s.status !== INIT_STATE && //#ifdef GZIP
  s.status !== GZIP_STATE && //#endif
  s.status !== EXTRA_STATE && s.status !== NAME_STATE && s.status !== COMMENT_STATE && s.status !== HCRC_STATE && s.status !== BUSY_STATE && s.status !== FINISH_STATE) {
    return 1;
  }
  return 0;
};
var deflateResetKeep = (strm) => {
  if (deflateStateCheck(strm)) {
    return err(strm, Z_STREAM_ERROR$2);
  }
  strm.total_in = strm.total_out = 0;
  strm.data_type = Z_UNKNOWN;
  const s = strm.state;
  s.pending = 0;
  s.pending_out = 0;
  if (s.wrap < 0) {
    s.wrap = -s.wrap;
  }
  s.status = //#ifdef GZIP
  s.wrap === 2 ? GZIP_STATE : (
    //#endif
    s.wrap ? INIT_STATE : BUSY_STATE
  );
  strm.adler = s.wrap === 2 ? 0 : 1;
  s.last_flush = -2;
  _tr_init(s);
  return Z_OK$3;
};
var deflateReset = (strm) => {
  const ret = deflateResetKeep(strm);
  if (ret === Z_OK$3) {
    lm_init(strm.state);
  }
  return ret;
};
var deflateSetHeader = (strm, head) => {
  if (deflateStateCheck(strm) || strm.state.wrap !== 2) {
    return Z_STREAM_ERROR$2;
  }
  strm.state.gzhead = head;
  return Z_OK$3;
};
var deflateInit2 = (strm, level, method, windowBits, memLevel, strategy) => {
  if (!strm) {
    return Z_STREAM_ERROR$2;
  }
  let wrap = 1;
  if (level === Z_DEFAULT_COMPRESSION$1) {
    level = 6;
  }
  if (windowBits < 0) {
    wrap = 0;
    windowBits = -windowBits;
  } else if (windowBits > 15) {
    wrap = 2;
    windowBits -= 16;
  }
  if (memLevel < 1 || memLevel > MAX_MEM_LEVEL || method !== Z_DEFLATED$2 || windowBits < 8 || windowBits > 15 || level < 0 || level > 9 || strategy < 0 || strategy > Z_FIXED || windowBits === 8 && wrap !== 1) {
    return err(strm, Z_STREAM_ERROR$2);
  }
  if (windowBits === 8) {
    windowBits = 9;
  }
  const s = new DeflateState();
  strm.state = s;
  s.strm = strm;
  s.status = INIT_STATE;
  s.wrap = wrap;
  s.gzhead = null;
  s.w_bits = windowBits;
  s.w_size = 1 << s.w_bits;
  s.w_mask = s.w_size - 1;
  s.hash_bits = memLevel + 7;
  s.hash_size = 1 << s.hash_bits;
  s.hash_mask = s.hash_size - 1;
  s.hash_shift = ~~((s.hash_bits + MIN_MATCH - 1) / MIN_MATCH);
  s.window = new Uint8Array(s.w_size * 2);
  s.head = new Uint16Array(s.hash_size);
  s.prev = new Uint16Array(s.w_size);
  s.lit_bufsize = 1 << memLevel + 6;
  s.pending_buf_size = s.lit_bufsize * 4;
  s.pending_buf = new Uint8Array(s.pending_buf_size);
  s.sym_buf = s.lit_bufsize;
  s.sym_end = (s.lit_bufsize - 1) * 3;
  s.level = level;
  s.strategy = strategy;
  s.method = method;
  return deflateReset(strm);
};
var deflateInit = (strm, level) => {
  return deflateInit2(strm, level, Z_DEFLATED$2, MAX_WBITS$1, DEF_MEM_LEVEL, Z_DEFAULT_STRATEGY$1);
};
var deflate$2 = (strm, flush) => {
  if (deflateStateCheck(strm) || flush > Z_BLOCK$1 || flush < 0) {
    return strm ? err(strm, Z_STREAM_ERROR$2) : Z_STREAM_ERROR$2;
  }
  const s = strm.state;
  if (!strm.output || strm.avail_in !== 0 && !strm.input || s.status === FINISH_STATE && flush !== Z_FINISH$3) {
    return err(strm, strm.avail_out === 0 ? Z_BUF_ERROR$1 : Z_STREAM_ERROR$2);
  }
  const old_flush = s.last_flush;
  s.last_flush = flush;
  if (s.pending !== 0) {
    flush_pending(strm);
    if (strm.avail_out === 0) {
      s.last_flush = -1;
      return Z_OK$3;
    }
  } else if (strm.avail_in === 0 && rank(flush) <= rank(old_flush) && flush !== Z_FINISH$3) {
    return err(strm, Z_BUF_ERROR$1);
  }
  if (s.status === FINISH_STATE && strm.avail_in !== 0) {
    return err(strm, Z_BUF_ERROR$1);
  }
  if (s.status === INIT_STATE && s.wrap === 0) {
    s.status = BUSY_STATE;
  }
  if (s.status === INIT_STATE) {
    let header = Z_DEFLATED$2 + (s.w_bits - 8 << 4) << 8;
    let level_flags = -1;
    if (s.strategy >= Z_HUFFMAN_ONLY || s.level < 2) {
      level_flags = 0;
    } else if (s.level < 6) {
      level_flags = 1;
    } else if (s.level === 6) {
      level_flags = 2;
    } else {
      level_flags = 3;
    }
    header |= level_flags << 6;
    if (s.strstart !== 0) {
      header |= PRESET_DICT;
    }
    header += 31 - header % 31;
    putShortMSB(s, header);
    if (s.strstart !== 0) {
      putShortMSB(s, strm.adler >>> 16);
      putShortMSB(s, strm.adler & 65535);
    }
    strm.adler = 1;
    s.status = BUSY_STATE;
    flush_pending(strm);
    if (s.pending !== 0) {
      s.last_flush = -1;
      return Z_OK$3;
    }
  }
  if (s.status === GZIP_STATE) {
    strm.adler = 0;
    put_byte(s, 31);
    put_byte(s, 139);
    put_byte(s, 8);
    if (!s.gzhead) {
      put_byte(s, 0);
      put_byte(s, 0);
      put_byte(s, 0);
      put_byte(s, 0);
      put_byte(s, 0);
      put_byte(s, s.level === 9 ? 2 : s.strategy >= Z_HUFFMAN_ONLY || s.level < 2 ? 4 : 0);
      put_byte(s, OS_CODE);
      s.status = BUSY_STATE;
      flush_pending(strm);
      if (s.pending !== 0) {
        s.last_flush = -1;
        return Z_OK$3;
      }
    } else {
      put_byte(
        s,
        (s.gzhead.text ? 1 : 0) + (s.gzhead.hcrc ? 2 : 0) + (!s.gzhead.extra ? 0 : 4) + (!s.gzhead.name ? 0 : 8) + (!s.gzhead.comment ? 0 : 16)
      );
      put_byte(s, s.gzhead.time & 255);
      put_byte(s, s.gzhead.time >> 8 & 255);
      put_byte(s, s.gzhead.time >> 16 & 255);
      put_byte(s, s.gzhead.time >> 24 & 255);
      put_byte(s, s.level === 9 ? 2 : s.strategy >= Z_HUFFMAN_ONLY || s.level < 2 ? 4 : 0);
      put_byte(s, s.gzhead.os & 255);
      if (s.gzhead.extra && s.gzhead.extra.length) {
        put_byte(s, s.gzhead.extra.length & 255);
        put_byte(s, s.gzhead.extra.length >> 8 & 255);
      }
      if (s.gzhead.hcrc) {
        strm.adler = crc32_1(strm.adler, s.pending_buf, s.pending, 0);
      }
      s.gzindex = 0;
      s.status = EXTRA_STATE;
    }
  }
  if (s.status === EXTRA_STATE) {
    if (s.gzhead.extra) {
      let beg = s.pending;
      let left = (s.gzhead.extra.length & 65535) - s.gzindex;
      while (s.pending + left > s.pending_buf_size) {
        let copy = s.pending_buf_size - s.pending;
        s.pending_buf.set(s.gzhead.extra.subarray(s.gzindex, s.gzindex + copy), s.pending);
        s.pending = s.pending_buf_size;
        if (s.gzhead.hcrc && s.pending > beg) {
          strm.adler = crc32_1(strm.adler, s.pending_buf, s.pending - beg, beg);
        }
        s.gzindex += copy;
        flush_pending(strm);
        if (s.pending !== 0) {
          s.last_flush = -1;
          return Z_OK$3;
        }
        beg = 0;
        left -= copy;
      }
      let gzhead_extra = new Uint8Array(s.gzhead.extra);
      s.pending_buf.set(gzhead_extra.subarray(s.gzindex, s.gzindex + left), s.pending);
      s.pending += left;
      if (s.gzhead.hcrc && s.pending > beg) {
        strm.adler = crc32_1(strm.adler, s.pending_buf, s.pending - beg, beg);
      }
      s.gzindex = 0;
    }
    s.status = NAME_STATE;
  }
  if (s.status === NAME_STATE) {
    if (s.gzhead.name) {
      let beg = s.pending;
      let val;
      do {
        if (s.pending === s.pending_buf_size) {
          if (s.gzhead.hcrc && s.pending > beg) {
            strm.adler = crc32_1(strm.adler, s.pending_buf, s.pending - beg, beg);
          }
          flush_pending(strm);
          if (s.pending !== 0) {
            s.last_flush = -1;
            return Z_OK$3;
          }
          beg = 0;
        }
        if (s.gzindex < s.gzhead.name.length) {
          val = s.gzhead.name.charCodeAt(s.gzindex++) & 255;
        } else {
          val = 0;
        }
        put_byte(s, val);
      } while (val !== 0);
      if (s.gzhead.hcrc && s.pending > beg) {
        strm.adler = crc32_1(strm.adler, s.pending_buf, s.pending - beg, beg);
      }
      s.gzindex = 0;
    }
    s.status = COMMENT_STATE;
  }
  if (s.status === COMMENT_STATE) {
    if (s.gzhead.comment) {
      let beg = s.pending;
      let val;
      do {
        if (s.pending === s.pending_buf_size) {
          if (s.gzhead.hcrc && s.pending > beg) {
            strm.adler = crc32_1(strm.adler, s.pending_buf, s.pending - beg, beg);
          }
          flush_pending(strm);
          if (s.pending !== 0) {
            s.last_flush = -1;
            return Z_OK$3;
          }
          beg = 0;
        }
        if (s.gzindex < s.gzhead.comment.length) {
          val = s.gzhead.comment.charCodeAt(s.gzindex++) & 255;
        } else {
          val = 0;
        }
        put_byte(s, val);
      } while (val !== 0);
      if (s.gzhead.hcrc && s.pending > beg) {
        strm.adler = crc32_1(strm.adler, s.pending_buf, s.pending - beg, beg);
      }
    }
    s.status = HCRC_STATE;
  }
  if (s.status === HCRC_STATE) {
    if (s.gzhead.hcrc) {
      if (s.pending + 2 > s.pending_buf_size) {
        flush_pending(strm);
        if (s.pending !== 0) {
          s.last_flush = -1;
          return Z_OK$3;
        }
      }
      put_byte(s, strm.adler & 255);
      put_byte(s, strm.adler >> 8 & 255);
      strm.adler = 0;
    }
    s.status = BUSY_STATE;
    flush_pending(strm);
    if (s.pending !== 0) {
      s.last_flush = -1;
      return Z_OK$3;
    }
  }
  if (strm.avail_in !== 0 || s.lookahead !== 0 || flush !== Z_NO_FLUSH$2 && s.status !== FINISH_STATE) {
    let bstate = s.level === 0 ? deflate_stored(s, flush) : s.strategy === Z_HUFFMAN_ONLY ? deflate_huff(s, flush) : s.strategy === Z_RLE ? deflate_rle(s, flush) : configuration_table[s.level].func(s, flush);
    if (bstate === BS_FINISH_STARTED || bstate === BS_FINISH_DONE) {
      s.status = FINISH_STATE;
    }
    if (bstate === BS_NEED_MORE || bstate === BS_FINISH_STARTED) {
      if (strm.avail_out === 0) {
        s.last_flush = -1;
      }
      return Z_OK$3;
    }
    if (bstate === BS_BLOCK_DONE) {
      if (flush === Z_PARTIAL_FLUSH) {
        _tr_align(s);
      } else if (flush !== Z_BLOCK$1) {
        _tr_stored_block(s, 0, 0, false);
        if (flush === Z_FULL_FLUSH$1) {
          zero(s.head);
          if (s.lookahead === 0) {
            s.strstart = 0;
            s.block_start = 0;
            s.insert = 0;
          }
        }
      }
      flush_pending(strm);
      if (strm.avail_out === 0) {
        s.last_flush = -1;
        return Z_OK$3;
      }
    }
  }
  if (flush !== Z_FINISH$3) {
    return Z_OK$3;
  }
  if (s.wrap <= 0) {
    return Z_STREAM_END$3;
  }
  if (s.wrap === 2) {
    put_byte(s, strm.adler & 255);
    put_byte(s, strm.adler >> 8 & 255);
    put_byte(s, strm.adler >> 16 & 255);
    put_byte(s, strm.adler >> 24 & 255);
    put_byte(s, strm.total_in & 255);
    put_byte(s, strm.total_in >> 8 & 255);
    put_byte(s, strm.total_in >> 16 & 255);
    put_byte(s, strm.total_in >> 24 & 255);
  } else {
    putShortMSB(s, strm.adler >>> 16);
    putShortMSB(s, strm.adler & 65535);
  }
  flush_pending(strm);
  if (s.wrap > 0) {
    s.wrap = -s.wrap;
  }
  return s.pending !== 0 ? Z_OK$3 : Z_STREAM_END$3;
};
var deflateEnd = (strm) => {
  if (deflateStateCheck(strm)) {
    return Z_STREAM_ERROR$2;
  }
  const status = strm.state.status;
  strm.state = null;
  return status === BUSY_STATE ? err(strm, Z_DATA_ERROR$2) : Z_OK$3;
};
var deflateSetDictionary = (strm, dictionary) => {
  let dictLength = dictionary.length;
  if (deflateStateCheck(strm)) {
    return Z_STREAM_ERROR$2;
  }
  const s = strm.state;
  const wrap = s.wrap;
  if (wrap === 2 || wrap === 1 && s.status !== INIT_STATE || s.lookahead) {
    return Z_STREAM_ERROR$2;
  }
  if (wrap === 1) {
    strm.adler = adler32_1(strm.adler, dictionary, dictLength, 0);
  }
  s.wrap = 0;
  if (dictLength >= s.w_size) {
    if (wrap === 0) {
      zero(s.head);
      s.strstart = 0;
      s.block_start = 0;
      s.insert = 0;
    }
    let tmpDict = new Uint8Array(s.w_size);
    tmpDict.set(dictionary.subarray(dictLength - s.w_size, dictLength), 0);
    dictionary = tmpDict;
    dictLength = s.w_size;
  }
  const avail = strm.avail_in;
  const next = strm.next_in;
  const input = strm.input;
  strm.avail_in = dictLength;
  strm.next_in = 0;
  strm.input = dictionary;
  fill_window(s);
  while (s.lookahead >= MIN_MATCH) {
    let str = s.strstart;
    let n = s.lookahead - (MIN_MATCH - 1);
    do {
      s.ins_h = HASH(s, s.ins_h, s.window[str + MIN_MATCH - 1]);
      s.prev[str & s.w_mask] = s.head[s.ins_h];
      s.head[s.ins_h] = str;
      str++;
    } while (--n);
    s.strstart = str;
    s.lookahead = MIN_MATCH - 1;
    fill_window(s);
  }
  s.strstart += s.lookahead;
  s.block_start = s.strstart;
  s.insert = s.lookahead;
  s.lookahead = 0;
  s.match_length = s.prev_length = MIN_MATCH - 1;
  s.match_available = 0;
  strm.next_in = next;
  strm.input = input;
  strm.avail_in = avail;
  s.wrap = wrap;
  return Z_OK$3;
};
var deflateInit_1 = deflateInit;
var deflateInit2_1 = deflateInit2;
var deflateReset_1 = deflateReset;
var deflateResetKeep_1 = deflateResetKeep;
var deflateSetHeader_1 = deflateSetHeader;
var deflate_2$1 = deflate$2;
var deflateEnd_1 = deflateEnd;
var deflateSetDictionary_1 = deflateSetDictionary;
var deflateInfo = "pako deflate (from Nodeca project)";
var deflate_1$2 = {
  deflateInit: deflateInit_1,
  deflateInit2: deflateInit2_1,
  deflateReset: deflateReset_1,
  deflateResetKeep: deflateResetKeep_1,
  deflateSetHeader: deflateSetHeader_1,
  deflate: deflate_2$1,
  deflateEnd: deflateEnd_1,
  deflateSetDictionary: deflateSetDictionary_1,
  deflateInfo
};
var _has = (obj, key) => {
  return Object.prototype.hasOwnProperty.call(obj, key);
};
var assign = function(obj) {
  const sources = Array.prototype.slice.call(arguments, 1);
  while (sources.length) {
    const source = sources.shift();
    if (!source) {
      continue;
    }
    if (typeof source !== "object") {
      throw new TypeError(source + "must be non-object");
    }
    for (const p in source) {
      if (_has(source, p)) {
        obj[p] = source[p];
      }
    }
  }
  return obj;
};
var flattenChunks = (chunks) => {
  let len = 0;
  for (let i = 0, l = chunks.length; i < l; i++) {
    len += chunks[i].length;
  }
  const result = new Uint8Array(len);
  for (let i = 0, pos = 0, l = chunks.length; i < l; i++) {
    let chunk = chunks[i];
    result.set(chunk, pos);
    pos += chunk.length;
  }
  return result;
};
var common = {
  assign,
  flattenChunks
};
var STR_APPLY_UIA_OK = true;
try {
  String.fromCharCode.apply(null, new Uint8Array(1));
} catch (__) {
  STR_APPLY_UIA_OK = false;
}
var _utf8len = new Uint8Array(256);
for (let q = 0; q < 256; q++) {
  _utf8len[q] = q >= 252 ? 6 : q >= 248 ? 5 : q >= 240 ? 4 : q >= 224 ? 3 : q >= 192 ? 2 : 1;
}
_utf8len[254] = _utf8len[254] = 1;
var string2buf = (str) => {
  if (typeof TextEncoder === "function" && TextEncoder.prototype.encode) {
    return new TextEncoder().encode(str);
  }
  let buf, c, c2, m_pos, i, str_len = str.length, buf_len = 0;
  for (m_pos = 0; m_pos < str_len; m_pos++) {
    c = str.charCodeAt(m_pos);
    if ((c & 64512) === 55296 && m_pos + 1 < str_len) {
      c2 = str.charCodeAt(m_pos + 1);
      if ((c2 & 64512) === 56320) {
        c = 65536 + (c - 55296 << 10) + (c2 - 56320);
        m_pos++;
      }
    }
    buf_len += c < 128 ? 1 : c < 2048 ? 2 : c < 65536 ? 3 : 4;
  }
  buf = new Uint8Array(buf_len);
  for (i = 0, m_pos = 0; i < buf_len; m_pos++) {
    c = str.charCodeAt(m_pos);
    if ((c & 64512) === 55296 && m_pos + 1 < str_len) {
      c2 = str.charCodeAt(m_pos + 1);
      if ((c2 & 64512) === 56320) {
        c = 65536 + (c - 55296 << 10) + (c2 - 56320);
        m_pos++;
      }
    }
    if (c < 128) {
      buf[i++] = c;
    } else if (c < 2048) {
      buf[i++] = 192 | c >>> 6;
      buf[i++] = 128 | c & 63;
    } else if (c < 65536) {
      buf[i++] = 224 | c >>> 12;
      buf[i++] = 128 | c >>> 6 & 63;
      buf[i++] = 128 | c & 63;
    } else {
      buf[i++] = 240 | c >>> 18;
      buf[i++] = 128 | c >>> 12 & 63;
      buf[i++] = 128 | c >>> 6 & 63;
      buf[i++] = 128 | c & 63;
    }
  }
  return buf;
};
var buf2binstring = (buf, len) => {
  if (len < 65534) {
    if (buf.subarray && STR_APPLY_UIA_OK) {
      return String.fromCharCode.apply(null, buf.length === len ? buf : buf.subarray(0, len));
    }
  }
  let result = "";
  for (let i = 0; i < len; i++) {
    result += String.fromCharCode(buf[i]);
  }
  return result;
};
var buf2string = (buf, max) => {
  const len = max || buf.length;
  if (typeof TextDecoder === "function" && TextDecoder.prototype.decode) {
    return new TextDecoder().decode(buf.subarray(0, max));
  }
  let i, out;
  const utf16buf = new Array(len * 2);
  for (out = 0, i = 0; i < len; ) {
    let c = buf[i++];
    if (c < 128) {
      utf16buf[out++] = c;
      continue;
    }
    let c_len = _utf8len[c];
    if (c_len > 4) {
      utf16buf[out++] = 65533;
      i += c_len - 1;
      continue;
    }
    c &= c_len === 2 ? 31 : c_len === 3 ? 15 : 7;
    while (c_len > 1 && i < len) {
      c = c << 6 | buf[i++] & 63;
      c_len--;
    }
    if (c_len > 1) {
      utf16buf[out++] = 65533;
      continue;
    }
    if (c < 65536) {
      utf16buf[out++] = c;
    } else {
      c -= 65536;
      utf16buf[out++] = 55296 | c >> 10 & 1023;
      utf16buf[out++] = 56320 | c & 1023;
    }
  }
  return buf2binstring(utf16buf, out);
};
var utf8border = (buf, max) => {
  max = max || buf.length;
  if (max > buf.length) {
    max = buf.length;
  }
  let pos = max - 1;
  while (pos >= 0 && (buf[pos] & 192) === 128) {
    pos--;
  }
  if (pos < 0) {
    return max;
  }
  if (pos === 0) {
    return max;
  }
  return pos + _utf8len[buf[pos]] > max ? pos : max;
};
var strings = {
  string2buf,
  buf2string,
  utf8border
};
function ZStream() {
  this.input = null;
  this.next_in = 0;
  this.avail_in = 0;
  this.total_in = 0;
  this.output = null;
  this.next_out = 0;
  this.avail_out = 0;
  this.total_out = 0;
  this.msg = "";
  this.state = null;
  this.data_type = 2;
  this.adler = 0;
}
var zstream = ZStream;
var toString$1 = Object.prototype.toString;
var {
  Z_NO_FLUSH: Z_NO_FLUSH$1,
  Z_SYNC_FLUSH,
  Z_FULL_FLUSH,
  Z_FINISH: Z_FINISH$2,
  Z_OK: Z_OK$2,
  Z_STREAM_END: Z_STREAM_END$2,
  Z_DEFAULT_COMPRESSION,
  Z_DEFAULT_STRATEGY,
  Z_DEFLATED: Z_DEFLATED$1
} = constants$2;
function Deflate$1(options) {
  this.options = common.assign({
    level: Z_DEFAULT_COMPRESSION,
    method: Z_DEFLATED$1,
    chunkSize: 16384,
    windowBits: 15,
    memLevel: 8,
    strategy: Z_DEFAULT_STRATEGY
  }, options || {});
  let opt = this.options;
  if (opt.raw && opt.windowBits > 0) {
    opt.windowBits = -opt.windowBits;
  } else if (opt.gzip && opt.windowBits > 0 && opt.windowBits < 16) {
    opt.windowBits += 16;
  }
  this.err = 0;
  this.msg = "";
  this.ended = false;
  this.chunks = [];
  this.strm = new zstream();
  this.strm.avail_out = 0;
  let status = deflate_1$2.deflateInit2(
    this.strm,
    opt.level,
    opt.method,
    opt.windowBits,
    opt.memLevel,
    opt.strategy
  );
  if (status !== Z_OK$2) {
    throw new Error(messages[status]);
  }
  if (opt.header) {
    deflate_1$2.deflateSetHeader(this.strm, opt.header);
  }
  if (opt.dictionary) {
    let dict;
    if (typeof opt.dictionary === "string") {
      dict = strings.string2buf(opt.dictionary);
    } else if (toString$1.call(opt.dictionary) === "[object ArrayBuffer]") {
      dict = new Uint8Array(opt.dictionary);
    } else {
      dict = opt.dictionary;
    }
    status = deflate_1$2.deflateSetDictionary(this.strm, dict);
    if (status !== Z_OK$2) {
      throw new Error(messages[status]);
    }
    this._dict_set = true;
  }
}
Deflate$1.prototype.push = function(data, flush_mode) {
  const strm = this.strm;
  const chunkSize = this.options.chunkSize;
  let status, _flush_mode;
  if (this.ended) {
    return false;
  }
  if (flush_mode === ~~flush_mode) _flush_mode = flush_mode;
  else _flush_mode = flush_mode === true ? Z_FINISH$2 : Z_NO_FLUSH$1;
  if (typeof data === "string") {
    strm.input = strings.string2buf(data);
  } else if (toString$1.call(data) === "[object ArrayBuffer]") {
    strm.input = new Uint8Array(data);
  } else {
    strm.input = data;
  }
  strm.next_in = 0;
  strm.avail_in = strm.input.length;
  for (; ; ) {
    if (strm.avail_out === 0) {
      strm.output = new Uint8Array(chunkSize);
      strm.next_out = 0;
      strm.avail_out = chunkSize;
    }
    if ((_flush_mode === Z_SYNC_FLUSH || _flush_mode === Z_FULL_FLUSH) && strm.avail_out <= 6) {
      this.onData(strm.output.subarray(0, strm.next_out));
      strm.avail_out = 0;
      continue;
    }
    status = deflate_1$2.deflate(strm, _flush_mode);
    if (status === Z_STREAM_END$2) {
      if (strm.next_out > 0) {
        this.onData(strm.output.subarray(0, strm.next_out));
      }
      status = deflate_1$2.deflateEnd(this.strm);
      this.onEnd(status);
      this.ended = true;
      return status === Z_OK$2;
    }
    if (strm.avail_out === 0) {
      this.onData(strm.output);
      continue;
    }
    if (_flush_mode > 0 && strm.next_out > 0) {
      this.onData(strm.output.subarray(0, strm.next_out));
      strm.avail_out = 0;
      continue;
    }
    if (strm.avail_in === 0) break;
  }
  return true;
};
Deflate$1.prototype.onData = function(chunk) {
  this.chunks.push(chunk);
};
Deflate$1.prototype.onEnd = function(status) {
  if (status === Z_OK$2) {
    this.result = common.flattenChunks(this.chunks);
  }
  this.chunks = [];
  this.err = status;
  this.msg = this.strm.msg;
};
function deflate$1(input, options) {
  const deflator = new Deflate$1(options);
  deflator.push(input, true);
  if (deflator.err) {
    throw deflator.msg || messages[deflator.err];
  }
  return deflator.result;
}
function deflateRaw$1(input, options) {
  options = options || {};
  options.raw = true;
  return deflate$1(input, options);
}
function gzip$1(input, options) {
  options = options || {};
  options.gzip = true;
  return deflate$1(input, options);
}
var Deflate_1$1 = Deflate$1;
var deflate_2 = deflate$1;
var deflateRaw_1$1 = deflateRaw$1;
var gzip_1$1 = gzip$1;
var constants$1 = constants$2;
var deflate_1$1 = {
  Deflate: Deflate_1$1,
  deflate: deflate_2,
  deflateRaw: deflateRaw_1$1,
  gzip: gzip_1$1,
  constants: constants$1
};
var BAD$1 = 16209;
var TYPE$1 = 16191;
var inffast = function inflate_fast(strm, start) {
  let _in;
  let last;
  let _out;
  let beg;
  let end;
  let dmax;
  let wsize;
  let whave;
  let wnext;
  let s_window;
  let hold;
  let bits;
  let lcode;
  let dcode;
  let lmask;
  let dmask;
  let here;
  let op;
  let len;
  let dist;
  let from;
  let from_source;
  let input, output;
  const state = strm.state;
  _in = strm.next_in;
  input = strm.input;
  last = _in + (strm.avail_in - 5);
  _out = strm.next_out;
  output = strm.output;
  beg = _out - (start - strm.avail_out);
  end = _out + (strm.avail_out - 257);
  dmax = state.dmax;
  wsize = state.wsize;
  whave = state.whave;
  wnext = state.wnext;
  s_window = state.window;
  hold = state.hold;
  bits = state.bits;
  lcode = state.lencode;
  dcode = state.distcode;
  lmask = (1 << state.lenbits) - 1;
  dmask = (1 << state.distbits) - 1;
  top:
    do {
      if (bits < 15) {
        hold += input[_in++] << bits;
        bits += 8;
        hold += input[_in++] << bits;
        bits += 8;
      }
      here = lcode[hold & lmask];
      dolen:
        for (; ; ) {
          op = here >>> 24;
          hold >>>= op;
          bits -= op;
          op = here >>> 16 & 255;
          if (op === 0) {
            output[_out++] = here & 65535;
          } else if (op & 16) {
            len = here & 65535;
            op &= 15;
            if (op) {
              if (bits < op) {
                hold += input[_in++] << bits;
                bits += 8;
              }
              len += hold & (1 << op) - 1;
              hold >>>= op;
              bits -= op;
            }
            if (bits < 15) {
              hold += input[_in++] << bits;
              bits += 8;
              hold += input[_in++] << bits;
              bits += 8;
            }
            here = dcode[hold & dmask];
            dodist:
              for (; ; ) {
                op = here >>> 24;
                hold >>>= op;
                bits -= op;
                op = here >>> 16 & 255;
                if (op & 16) {
                  dist = here & 65535;
                  op &= 15;
                  if (bits < op) {
                    hold += input[_in++] << bits;
                    bits += 8;
                    if (bits < op) {
                      hold += input[_in++] << bits;
                      bits += 8;
                    }
                  }
                  dist += hold & (1 << op) - 1;
                  if (dist > dmax) {
                    strm.msg = "invalid distance too far back";
                    state.mode = BAD$1;
                    break top;
                  }
                  hold >>>= op;
                  bits -= op;
                  op = _out - beg;
                  if (dist > op) {
                    op = dist - op;
                    if (op > whave) {
                      if (state.sane) {
                        strm.msg = "invalid distance too far back";
                        state.mode = BAD$1;
                        break top;
                      }
                    }
                    from = 0;
                    from_source = s_window;
                    if (wnext === 0) {
                      from += wsize - op;
                      if (op < len) {
                        len -= op;
                        do {
                          output[_out++] = s_window[from++];
                        } while (--op);
                        from = _out - dist;
                        from_source = output;
                      }
                    } else if (wnext < op) {
                      from += wsize + wnext - op;
                      op -= wnext;
                      if (op < len) {
                        len -= op;
                        do {
                          output[_out++] = s_window[from++];
                        } while (--op);
                        from = 0;
                        if (wnext < len) {
                          op = wnext;
                          len -= op;
                          do {
                            output[_out++] = s_window[from++];
                          } while (--op);
                          from = _out - dist;
                          from_source = output;
                        }
                      }
                    } else {
                      from += wnext - op;
                      if (op < len) {
                        len -= op;
                        do {
                          output[_out++] = s_window[from++];
                        } while (--op);
                        from = _out - dist;
                        from_source = output;
                      }
                    }
                    while (len > 2) {
                      output[_out++] = from_source[from++];
                      output[_out++] = from_source[from++];
                      output[_out++] = from_source[from++];
                      len -= 3;
                    }
                    if (len) {
                      output[_out++] = from_source[from++];
                      if (len > 1) {
                        output[_out++] = from_source[from++];
                      }
                    }
                  } else {
                    from = _out - dist;
                    do {
                      output[_out++] = output[from++];
                      output[_out++] = output[from++];
                      output[_out++] = output[from++];
                      len -= 3;
                    } while (len > 2);
                    if (len) {
                      output[_out++] = output[from++];
                      if (len > 1) {
                        output[_out++] = output[from++];
                      }
                    }
                  }
                } else if ((op & 64) === 0) {
                  here = dcode[(here & 65535) + (hold & (1 << op) - 1)];
                  continue dodist;
                } else {
                  strm.msg = "invalid distance code";
                  state.mode = BAD$1;
                  break top;
                }
                break;
              }
          } else if ((op & 64) === 0) {
            here = lcode[(here & 65535) + (hold & (1 << op) - 1)];
            continue dolen;
          } else if (op & 32) {
            state.mode = TYPE$1;
            break top;
          } else {
            strm.msg = "invalid literal/length code";
            state.mode = BAD$1;
            break top;
          }
          break;
        }
    } while (_in < last && _out < end);
  len = bits >> 3;
  _in -= len;
  bits -= len << 3;
  hold &= (1 << bits) - 1;
  strm.next_in = _in;
  strm.next_out = _out;
  strm.avail_in = _in < last ? 5 + (last - _in) : 5 - (_in - last);
  strm.avail_out = _out < end ? 257 + (end - _out) : 257 - (_out - end);
  state.hold = hold;
  state.bits = bits;
  return;
};
var MAXBITS = 15;
var ENOUGH_LENS$1 = 852;
var ENOUGH_DISTS$1 = 592;
var CODES$1 = 0;
var LENS$1 = 1;
var DISTS$1 = 2;
var lbase = new Uint16Array([
  /* Length codes 257..285 base */
  3,
  4,
  5,
  6,
  7,
  8,
  9,
  10,
  11,
  13,
  15,
  17,
  19,
  23,
  27,
  31,
  35,
  43,
  51,
  59,
  67,
  83,
  99,
  115,
  131,
  163,
  195,
  227,
  258,
  0,
  0
]);
var lext = new Uint8Array([
  /* Length codes 257..285 extra */
  16,
  16,
  16,
  16,
  16,
  16,
  16,
  16,
  17,
  17,
  17,
  17,
  18,
  18,
  18,
  18,
  19,
  19,
  19,
  19,
  20,
  20,
  20,
  20,
  21,
  21,
  21,
  21,
  16,
  72,
  78
]);
var dbase = new Uint16Array([
  /* Distance codes 0..29 base */
  1,
  2,
  3,
  4,
  5,
  7,
  9,
  13,
  17,
  25,
  33,
  49,
  65,
  97,
  129,
  193,
  257,
  385,
  513,
  769,
  1025,
  1537,
  2049,
  3073,
  4097,
  6145,
  8193,
  12289,
  16385,
  24577,
  0,
  0
]);
var dext = new Uint8Array([
  /* Distance codes 0..29 extra */
  16,
  16,
  16,
  16,
  17,
  17,
  18,
  18,
  19,
  19,
  20,
  20,
  21,
  21,
  22,
  22,
  23,
  23,
  24,
  24,
  25,
  25,
  26,
  26,
  27,
  27,
  28,
  28,
  29,
  29,
  64,
  64
]);
var inflate_table = (type, lens, lens_index, codes, table, table_index, work, opts) => {
  const bits = opts.bits;
  let len = 0;
  let sym = 0;
  let min = 0, max = 0;
  let root = 0;
  let curr = 0;
  let drop = 0;
  let left = 0;
  let used = 0;
  let huff = 0;
  let incr;
  let fill;
  let low;
  let mask;
  let next;
  let base = null;
  let match;
  const count = new Uint16Array(MAXBITS + 1);
  const offs = new Uint16Array(MAXBITS + 1);
  let extra = null;
  let here_bits, here_op, here_val;
  for (len = 0; len <= MAXBITS; len++) {
    count[len] = 0;
  }
  for (sym = 0; sym < codes; sym++) {
    count[lens[lens_index + sym]]++;
  }
  root = bits;
  for (max = MAXBITS; max >= 1; max--) {
    if (count[max] !== 0) {
      break;
    }
  }
  if (root > max) {
    root = max;
  }
  if (max === 0) {
    table[table_index++] = 1 << 24 | 64 << 16 | 0;
    table[table_index++] = 1 << 24 | 64 << 16 | 0;
    opts.bits = 1;
    return 0;
  }
  for (min = 1; min < max; min++) {
    if (count[min] !== 0) {
      break;
    }
  }
  if (root < min) {
    root = min;
  }
  left = 1;
  for (len = 1; len <= MAXBITS; len++) {
    left <<= 1;
    left -= count[len];
    if (left < 0) {
      return -1;
    }
  }
  if (left > 0 && (type === CODES$1 || max !== 1)) {
    return -1;
  }
  offs[1] = 0;
  for (len = 1; len < MAXBITS; len++) {
    offs[len + 1] = offs[len] + count[len];
  }
  for (sym = 0; sym < codes; sym++) {
    if (lens[lens_index + sym] !== 0) {
      work[offs[lens[lens_index + sym]]++] = sym;
    }
  }
  if (type === CODES$1) {
    base = extra = work;
    match = 20;
  } else if (type === LENS$1) {
    base = lbase;
    extra = lext;
    match = 257;
  } else {
    base = dbase;
    extra = dext;
    match = 0;
  }
  huff = 0;
  sym = 0;
  len = min;
  next = table_index;
  curr = root;
  drop = 0;
  low = -1;
  used = 1 << root;
  mask = used - 1;
  if (type === LENS$1 && used > ENOUGH_LENS$1 || type === DISTS$1 && used > ENOUGH_DISTS$1) {
    return 1;
  }
  for (; ; ) {
    here_bits = len - drop;
    if (work[sym] + 1 < match) {
      here_op = 0;
      here_val = work[sym];
    } else if (work[sym] >= match) {
      here_op = extra[work[sym] - match];
      here_val = base[work[sym] - match];
    } else {
      here_op = 32 + 64;
      here_val = 0;
    }
    incr = 1 << len - drop;
    fill = 1 << curr;
    min = fill;
    do {
      fill -= incr;
      table[next + (huff >> drop) + fill] = here_bits << 24 | here_op << 16 | here_val | 0;
    } while (fill !== 0);
    incr = 1 << len - 1;
    while (huff & incr) {
      incr >>= 1;
    }
    if (incr !== 0) {
      huff &= incr - 1;
      huff += incr;
    } else {
      huff = 0;
    }
    sym++;
    if (--count[len] === 0) {
      if (len === max) {
        break;
      }
      len = lens[lens_index + work[sym]];
    }
    if (len > root && (huff & mask) !== low) {
      if (drop === 0) {
        drop = root;
      }
      next += min;
      curr = len - drop;
      left = 1 << curr;
      while (curr + drop < max) {
        left -= count[curr + drop];
        if (left <= 0) {
          break;
        }
        curr++;
        left <<= 1;
      }
      used += 1 << curr;
      if (type === LENS$1 && used > ENOUGH_LENS$1 || type === DISTS$1 && used > ENOUGH_DISTS$1) {
        return 1;
      }
      low = huff & mask;
      table[low] = root << 24 | curr << 16 | next - table_index | 0;
    }
  }
  if (huff !== 0) {
    table[next + huff] = len - drop << 24 | 64 << 16 | 0;
  }
  opts.bits = root;
  return 0;
};
var inftrees = inflate_table;
var CODES = 0;
var LENS = 1;
var DISTS = 2;
var {
  Z_FINISH: Z_FINISH$1,
  Z_BLOCK,
  Z_TREES,
  Z_OK: Z_OK$1,
  Z_STREAM_END: Z_STREAM_END$1,
  Z_NEED_DICT: Z_NEED_DICT$1,
  Z_STREAM_ERROR: Z_STREAM_ERROR$1,
  Z_DATA_ERROR: Z_DATA_ERROR$1,
  Z_MEM_ERROR: Z_MEM_ERROR$1,
  Z_BUF_ERROR,
  Z_DEFLATED
} = constants$2;
var HEAD = 16180;
var FLAGS = 16181;
var TIME = 16182;
var OS = 16183;
var EXLEN = 16184;
var EXTRA = 16185;
var NAME = 16186;
var COMMENT = 16187;
var HCRC = 16188;
var DICTID = 16189;
var DICT = 16190;
var TYPE = 16191;
var TYPEDO = 16192;
var STORED = 16193;
var COPY_ = 16194;
var COPY = 16195;
var TABLE = 16196;
var LENLENS = 16197;
var CODELENS = 16198;
var LEN_ = 16199;
var LEN = 16200;
var LENEXT = 16201;
var DIST = 16202;
var DISTEXT = 16203;
var MATCH = 16204;
var LIT = 16205;
var CHECK = 16206;
var LENGTH = 16207;
var DONE = 16208;
var BAD = 16209;
var MEM = 16210;
var SYNC = 16211;
var ENOUGH_LENS = 852;
var ENOUGH_DISTS = 592;
var MAX_WBITS = 15;
var DEF_WBITS = MAX_WBITS;
var zswap32 = (q) => {
  return (q >>> 24 & 255) + (q >>> 8 & 65280) + ((q & 65280) << 8) + ((q & 255) << 24);
};
function InflateState() {
  this.strm = null;
  this.mode = 0;
  this.last = false;
  this.wrap = 0;
  this.havedict = false;
  this.flags = 0;
  this.dmax = 0;
  this.check = 0;
  this.total = 0;
  this.head = null;
  this.wbits = 0;
  this.wsize = 0;
  this.whave = 0;
  this.wnext = 0;
  this.window = null;
  this.hold = 0;
  this.bits = 0;
  this.length = 0;
  this.offset = 0;
  this.extra = 0;
  this.lencode = null;
  this.distcode = null;
  this.lenbits = 0;
  this.distbits = 0;
  this.ncode = 0;
  this.nlen = 0;
  this.ndist = 0;
  this.have = 0;
  this.next = null;
  this.lens = new Uint16Array(320);
  this.work = new Uint16Array(288);
  this.lendyn = null;
  this.distdyn = null;
  this.sane = 0;
  this.back = 0;
  this.was = 0;
}
var inflateStateCheck = (strm) => {
  if (!strm) {
    return 1;
  }
  const state = strm.state;
  if (!state || state.strm !== strm || state.mode < HEAD || state.mode > SYNC) {
    return 1;
  }
  return 0;
};
var inflateResetKeep = (strm) => {
  if (inflateStateCheck(strm)) {
    return Z_STREAM_ERROR$1;
  }
  const state = strm.state;
  strm.total_in = strm.total_out = state.total = 0;
  strm.msg = "";
  if (state.wrap) {
    strm.adler = state.wrap & 1;
  }
  state.mode = HEAD;
  state.last = 0;
  state.havedict = 0;
  state.flags = -1;
  state.dmax = 32768;
  state.head = null;
  state.hold = 0;
  state.bits = 0;
  state.lencode = state.lendyn = new Int32Array(ENOUGH_LENS);
  state.distcode = state.distdyn = new Int32Array(ENOUGH_DISTS);
  state.sane = 1;
  state.back = -1;
  return Z_OK$1;
};
var inflateReset = (strm) => {
  if (inflateStateCheck(strm)) {
    return Z_STREAM_ERROR$1;
  }
  const state = strm.state;
  state.wsize = 0;
  state.whave = 0;
  state.wnext = 0;
  return inflateResetKeep(strm);
};
var inflateReset2 = (strm, windowBits) => {
  let wrap;
  if (inflateStateCheck(strm)) {
    return Z_STREAM_ERROR$1;
  }
  const state = strm.state;
  if (windowBits < 0) {
    wrap = 0;
    windowBits = -windowBits;
  } else {
    wrap = (windowBits >> 4) + 5;
    if (windowBits < 48) {
      windowBits &= 15;
    }
  }
  if (windowBits && (windowBits < 8 || windowBits > 15)) {
    return Z_STREAM_ERROR$1;
  }
  if (state.window !== null && state.wbits !== windowBits) {
    state.window = null;
  }
  state.wrap = wrap;
  state.wbits = windowBits;
  return inflateReset(strm);
};
var inflateInit2 = (strm, windowBits) => {
  if (!strm) {
    return Z_STREAM_ERROR$1;
  }
  const state = new InflateState();
  strm.state = state;
  state.strm = strm;
  state.window = null;
  state.mode = HEAD;
  const ret = inflateReset2(strm, windowBits);
  if (ret !== Z_OK$1) {
    strm.state = null;
  }
  return ret;
};
var inflateInit = (strm) => {
  return inflateInit2(strm, DEF_WBITS);
};
var virgin = true;
var lenfix;
var distfix;
var fixedtables = (state) => {
  if (virgin) {
    lenfix = new Int32Array(512);
    distfix = new Int32Array(32);
    let sym = 0;
    while (sym < 144) {
      state.lens[sym++] = 8;
    }
    while (sym < 256) {
      state.lens[sym++] = 9;
    }
    while (sym < 280) {
      state.lens[sym++] = 7;
    }
    while (sym < 288) {
      state.lens[sym++] = 8;
    }
    inftrees(LENS, state.lens, 0, 288, lenfix, 0, state.work, { bits: 9 });
    sym = 0;
    while (sym < 32) {
      state.lens[sym++] = 5;
    }
    inftrees(DISTS, state.lens, 0, 32, distfix, 0, state.work, { bits: 5 });
    virgin = false;
  }
  state.lencode = lenfix;
  state.lenbits = 9;
  state.distcode = distfix;
  state.distbits = 5;
};
var updatewindow = (strm, src, end, copy) => {
  let dist;
  const state = strm.state;
  if (state.window === null) {
    state.wsize = 1 << state.wbits;
    state.wnext = 0;
    state.whave = 0;
    state.window = new Uint8Array(state.wsize);
  }
  if (copy >= state.wsize) {
    state.window.set(src.subarray(end - state.wsize, end), 0);
    state.wnext = 0;
    state.whave = state.wsize;
  } else {
    dist = state.wsize - state.wnext;
    if (dist > copy) {
      dist = copy;
    }
    state.window.set(src.subarray(end - copy, end - copy + dist), state.wnext);
    copy -= dist;
    if (copy) {
      state.window.set(src.subarray(end - copy, end), 0);
      state.wnext = copy;
      state.whave = state.wsize;
    } else {
      state.wnext += dist;
      if (state.wnext === state.wsize) {
        state.wnext = 0;
      }
      if (state.whave < state.wsize) {
        state.whave += dist;
      }
    }
  }
  return 0;
};
var inflate$2 = (strm, flush) => {
  let state;
  let input, output;
  let next;
  let put;
  let have, left;
  let hold;
  let bits;
  let _in, _out;
  let copy;
  let from;
  let from_source;
  let here = 0;
  let here_bits, here_op, here_val;
  let last_bits, last_op, last_val;
  let len;
  let ret;
  const hbuf = new Uint8Array(4);
  let opts;
  let n;
  const order = (
    /* permutation of code lengths */
    new Uint8Array([16, 17, 18, 0, 8, 7, 9, 6, 10, 5, 11, 4, 12, 3, 13, 2, 14, 1, 15])
  );
  if (inflateStateCheck(strm) || !strm.output || !strm.input && strm.avail_in !== 0) {
    return Z_STREAM_ERROR$1;
  }
  state = strm.state;
  if (state.mode === TYPE) {
    state.mode = TYPEDO;
  }
  put = strm.next_out;
  output = strm.output;
  left = strm.avail_out;
  next = strm.next_in;
  input = strm.input;
  have = strm.avail_in;
  hold = state.hold;
  bits = state.bits;
  _in = have;
  _out = left;
  ret = Z_OK$1;
  inf_leave:
    for (; ; ) {
      switch (state.mode) {
        case HEAD:
          if (state.wrap === 0) {
            state.mode = TYPEDO;
            break;
          }
          while (bits < 16) {
            if (have === 0) {
              break inf_leave;
            }
            have--;
            hold += input[next++] << bits;
            bits += 8;
          }
          if (state.wrap & 2 && hold === 35615) {
            if (state.wbits === 0) {
              state.wbits = 15;
            }
            state.check = 0;
            hbuf[0] = hold & 255;
            hbuf[1] = hold >>> 8 & 255;
            state.check = crc32_1(state.check, hbuf, 2, 0);
            hold = 0;
            bits = 0;
            state.mode = FLAGS;
            break;
          }
          if (state.head) {
            state.head.done = false;
          }
          if (!(state.wrap & 1) || /* check if zlib header allowed */
          (((hold & 255) << 8) + (hold >> 8)) % 31) {
            strm.msg = "incorrect header check";
            state.mode = BAD;
            break;
          }
          if ((hold & 15) !== Z_DEFLATED) {
            strm.msg = "unknown compression method";
            state.mode = BAD;
            break;
          }
          hold >>>= 4;
          bits -= 4;
          len = (hold & 15) + 8;
          if (state.wbits === 0) {
            state.wbits = len;
          }
          if (len > 15 || len > state.wbits) {
            strm.msg = "invalid window size";
            state.mode = BAD;
            break;
          }
          state.dmax = 1 << state.wbits;
          state.flags = 0;
          strm.adler = state.check = 1;
          state.mode = hold & 512 ? DICTID : TYPE;
          hold = 0;
          bits = 0;
          break;
        case FLAGS:
          while (bits < 16) {
            if (have === 0) {
              break inf_leave;
            }
            have--;
            hold += input[next++] << bits;
            bits += 8;
          }
          state.flags = hold;
          if ((state.flags & 255) !== Z_DEFLATED) {
            strm.msg = "unknown compression method";
            state.mode = BAD;
            break;
          }
          if (state.flags & 57344) {
            strm.msg = "unknown header flags set";
            state.mode = BAD;
            break;
          }
          if (state.head) {
            state.head.text = hold >> 8 & 1;
          }
          if (state.flags & 512 && state.wrap & 4) {
            hbuf[0] = hold & 255;
            hbuf[1] = hold >>> 8 & 255;
            state.check = crc32_1(state.check, hbuf, 2, 0);
          }
          hold = 0;
          bits = 0;
          state.mode = TIME;
        /* falls through */
        case TIME:
          while (bits < 32) {
            if (have === 0) {
              break inf_leave;
            }
            have--;
            hold += input[next++] << bits;
            bits += 8;
          }
          if (state.head) {
            state.head.time = hold;
          }
          if (state.flags & 512 && state.wrap & 4) {
            hbuf[0] = hold & 255;
            hbuf[1] = hold >>> 8 & 255;
            hbuf[2] = hold >>> 16 & 255;
            hbuf[3] = hold >>> 24 & 255;
            state.check = crc32_1(state.check, hbuf, 4, 0);
          }
          hold = 0;
          bits = 0;
          state.mode = OS;
        /* falls through */
        case OS:
          while (bits < 16) {
            if (have === 0) {
              break inf_leave;
            }
            have--;
            hold += input[next++] << bits;
            bits += 8;
          }
          if (state.head) {
            state.head.xflags = hold & 255;
            state.head.os = hold >> 8;
          }
          if (state.flags & 512 && state.wrap & 4) {
            hbuf[0] = hold & 255;
            hbuf[1] = hold >>> 8 & 255;
            state.check = crc32_1(state.check, hbuf, 2, 0);
          }
          hold = 0;
          bits = 0;
          state.mode = EXLEN;
        /* falls through */
        case EXLEN:
          if (state.flags & 1024) {
            while (bits < 16) {
              if (have === 0) {
                break inf_leave;
              }
              have--;
              hold += input[next++] << bits;
              bits += 8;
            }
            state.length = hold;
            if (state.head) {
              state.head.extra_len = hold;
            }
            if (state.flags & 512 && state.wrap & 4) {
              hbuf[0] = hold & 255;
              hbuf[1] = hold >>> 8 & 255;
              state.check = crc32_1(state.check, hbuf, 2, 0);
            }
            hold = 0;
            bits = 0;
          } else if (state.head) {
            state.head.extra = null;
          }
          state.mode = EXTRA;
        /* falls through */
        case EXTRA:
          if (state.flags & 1024) {
            copy = state.length;
            if (copy > have) {
              copy = have;
            }
            if (copy) {
              if (state.head) {
                len = state.head.extra_len - state.length;
                if (!state.head.extra) {
                  state.head.extra = new Uint8Array(state.head.extra_len);
                }
                state.head.extra.set(
                  input.subarray(
                    next,
                    // extra field is limited to 65536 bytes
                    // - no need for additional size check
                    next + copy
                  ),
                  /*len + copy > state.head.extra_max - len ? state.head.extra_max : copy,*/
                  len
                );
              }
              if (state.flags & 512 && state.wrap & 4) {
                state.check = crc32_1(state.check, input, copy, next);
              }
              have -= copy;
              next += copy;
              state.length -= copy;
            }
            if (state.length) {
              break inf_leave;
            }
          }
          state.length = 0;
          state.mode = NAME;
        /* falls through */
        case NAME:
          if (state.flags & 2048) {
            if (have === 0) {
              break inf_leave;
            }
            copy = 0;
            do {
              len = input[next + copy++];
              if (state.head && len && state.length < 65536) {
                state.head.name += String.fromCharCode(len);
              }
            } while (len && copy < have);
            if (state.flags & 512 && state.wrap & 4) {
              state.check = crc32_1(state.check, input, copy, next);
            }
            have -= copy;
            next += copy;
            if (len) {
              break inf_leave;
            }
          } else if (state.head) {
            state.head.name = null;
          }
          state.length = 0;
          state.mode = COMMENT;
        /* falls through */
        case COMMENT:
          if (state.flags & 4096) {
            if (have === 0) {
              break inf_leave;
            }
            copy = 0;
            do {
              len = input[next + copy++];
              if (state.head && len && state.length < 65536) {
                state.head.comment += String.fromCharCode(len);
              }
            } while (len && copy < have);
            if (state.flags & 512 && state.wrap & 4) {
              state.check = crc32_1(state.check, input, copy, next);
            }
            have -= copy;
            next += copy;
            if (len) {
              break inf_leave;
            }
          } else if (state.head) {
            state.head.comment = null;
          }
          state.mode = HCRC;
        /* falls through */
        case HCRC:
          if (state.flags & 512) {
            while (bits < 16) {
              if (have === 0) {
                break inf_leave;
              }
              have--;
              hold += input[next++] << bits;
              bits += 8;
            }
            if (state.wrap & 4 && hold !== (state.check & 65535)) {
              strm.msg = "header crc mismatch";
              state.mode = BAD;
              break;
            }
            hold = 0;
            bits = 0;
          }
          if (state.head) {
            state.head.hcrc = state.flags >> 9 & 1;
            state.head.done = true;
          }
          strm.adler = state.check = 0;
          state.mode = TYPE;
          break;
        case DICTID:
          while (bits < 32) {
            if (have === 0) {
              break inf_leave;
            }
            have--;
            hold += input[next++] << bits;
            bits += 8;
          }
          strm.adler = state.check = zswap32(hold);
          hold = 0;
          bits = 0;
          state.mode = DICT;
        /* falls through */
        case DICT:
          if (state.havedict === 0) {
            strm.next_out = put;
            strm.avail_out = left;
            strm.next_in = next;
            strm.avail_in = have;
            state.hold = hold;
            state.bits = bits;
            return Z_NEED_DICT$1;
          }
          strm.adler = state.check = 1;
          state.mode = TYPE;
        /* falls through */
        case TYPE:
          if (flush === Z_BLOCK || flush === Z_TREES) {
            break inf_leave;
          }
        /* falls through */
        case TYPEDO:
          if (state.last) {
            hold >>>= bits & 7;
            bits -= bits & 7;
            state.mode = CHECK;
            break;
          }
          while (bits < 3) {
            if (have === 0) {
              break inf_leave;
            }
            have--;
            hold += input[next++] << bits;
            bits += 8;
          }
          state.last = hold & 1;
          hold >>>= 1;
          bits -= 1;
          switch (hold & 3) {
            case 0:
              state.mode = STORED;
              break;
            case 1:
              fixedtables(state);
              state.mode = LEN_;
              if (flush === Z_TREES) {
                hold >>>= 2;
                bits -= 2;
                break inf_leave;
              }
              break;
            case 2:
              state.mode = TABLE;
              break;
            case 3:
              strm.msg = "invalid block type";
              state.mode = BAD;
          }
          hold >>>= 2;
          bits -= 2;
          break;
        case STORED:
          hold >>>= bits & 7;
          bits -= bits & 7;
          while (bits < 32) {
            if (have === 0) {
              break inf_leave;
            }
            have--;
            hold += input[next++] << bits;
            bits += 8;
          }
          if ((hold & 65535) !== (hold >>> 16 ^ 65535)) {
            strm.msg = "invalid stored block lengths";
            state.mode = BAD;
            break;
          }
          state.length = hold & 65535;
          hold = 0;
          bits = 0;
          state.mode = COPY_;
          if (flush === Z_TREES) {
            break inf_leave;
          }
        /* falls through */
        case COPY_:
          state.mode = COPY;
        /* falls through */
        case COPY:
          copy = state.length;
          if (copy) {
            if (copy > have) {
              copy = have;
            }
            if (copy > left) {
              copy = left;
            }
            if (copy === 0) {
              break inf_leave;
            }
            output.set(input.subarray(next, next + copy), put);
            have -= copy;
            next += copy;
            left -= copy;
            put += copy;
            state.length -= copy;
            break;
          }
          state.mode = TYPE;
          break;
        case TABLE:
          while (bits < 14) {
            if (have === 0) {
              break inf_leave;
            }
            have--;
            hold += input[next++] << bits;
            bits += 8;
          }
          state.nlen = (hold & 31) + 257;
          hold >>>= 5;
          bits -= 5;
          state.ndist = (hold & 31) + 1;
          hold >>>= 5;
          bits -= 5;
          state.ncode = (hold & 15) + 4;
          hold >>>= 4;
          bits -= 4;
          if (state.nlen > 286 || state.ndist > 30) {
            strm.msg = "too many length or distance symbols";
            state.mode = BAD;
            break;
          }
          state.have = 0;
          state.mode = LENLENS;
        /* falls through */
        case LENLENS:
          while (state.have < state.ncode) {
            while (bits < 3) {
              if (have === 0) {
                break inf_leave;
              }
              have--;
              hold += input[next++] << bits;
              bits += 8;
            }
            state.lens[order[state.have++]] = hold & 7;
            hold >>>= 3;
            bits -= 3;
          }
          while (state.have < 19) {
            state.lens[order[state.have++]] = 0;
          }
          state.lencode = state.lendyn;
          state.lenbits = 7;
          opts = { bits: state.lenbits };
          ret = inftrees(CODES, state.lens, 0, 19, state.lencode, 0, state.work, opts);
          state.lenbits = opts.bits;
          if (ret) {
            strm.msg = "invalid code lengths set";
            state.mode = BAD;
            break;
          }
          state.have = 0;
          state.mode = CODELENS;
        /* falls through */
        case CODELENS:
          while (state.have < state.nlen + state.ndist) {
            for (; ; ) {
              here = state.lencode[hold & (1 << state.lenbits) - 1];
              here_bits = here >>> 24;
              here_op = here >>> 16 & 255;
              here_val = here & 65535;
              if (here_bits <= bits) {
                break;
              }
              if (have === 0) {
                break inf_leave;
              }
              have--;
              hold += input[next++] << bits;
              bits += 8;
            }
            if (here_val < 16) {
              hold >>>= here_bits;
              bits -= here_bits;
              state.lens[state.have++] = here_val;
            } else {
              if (here_val === 16) {
                n = here_bits + 2;
                while (bits < n) {
                  if (have === 0) {
                    break inf_leave;
                  }
                  have--;
                  hold += input[next++] << bits;
                  bits += 8;
                }
                hold >>>= here_bits;
                bits -= here_bits;
                if (state.have === 0) {
                  strm.msg = "invalid bit length repeat";
                  state.mode = BAD;
                  break;
                }
                len = state.lens[state.have - 1];
                copy = 3 + (hold & 3);
                hold >>>= 2;
                bits -= 2;
              } else if (here_val === 17) {
                n = here_bits + 3;
                while (bits < n) {
                  if (have === 0) {
                    break inf_leave;
                  }
                  have--;
                  hold += input[next++] << bits;
                  bits += 8;
                }
                hold >>>= here_bits;
                bits -= here_bits;
                len = 0;
                copy = 3 + (hold & 7);
                hold >>>= 3;
                bits -= 3;
              } else {
                n = here_bits + 7;
                while (bits < n) {
                  if (have === 0) {
                    break inf_leave;
                  }
                  have--;
                  hold += input[next++] << bits;
                  bits += 8;
                }
                hold >>>= here_bits;
                bits -= here_bits;
                len = 0;
                copy = 11 + (hold & 127);
                hold >>>= 7;
                bits -= 7;
              }
              if (state.have + copy > state.nlen + state.ndist) {
                strm.msg = "invalid bit length repeat";
                state.mode = BAD;
                break;
              }
              while (copy--) {
                state.lens[state.have++] = len;
              }
            }
          }
          if (state.mode === BAD) {
            break;
          }
          if (state.lens[256] === 0) {
            strm.msg = "invalid code -- missing end-of-block";
            state.mode = BAD;
            break;
          }
          state.lenbits = 9;
          opts = { bits: state.lenbits };
          ret = inftrees(LENS, state.lens, 0, state.nlen, state.lencode, 0, state.work, opts);
          state.lenbits = opts.bits;
          if (ret) {
            strm.msg = "invalid literal/lengths set";
            state.mode = BAD;
            break;
          }
          state.distbits = 6;
          state.distcode = state.distdyn;
          opts = { bits: state.distbits };
          ret = inftrees(DISTS, state.lens, state.nlen, state.ndist, state.distcode, 0, state.work, opts);
          state.distbits = opts.bits;
          if (ret) {
            strm.msg = "invalid distances set";
            state.mode = BAD;
            break;
          }
          state.mode = LEN_;
          if (flush === Z_TREES) {
            break inf_leave;
          }
        /* falls through */
        case LEN_:
          state.mode = LEN;
        /* falls through */
        case LEN:
          if (have >= 6 && left >= 258) {
            strm.next_out = put;
            strm.avail_out = left;
            strm.next_in = next;
            strm.avail_in = have;
            state.hold = hold;
            state.bits = bits;
            inffast(strm, _out);
            put = strm.next_out;
            output = strm.output;
            left = strm.avail_out;
            next = strm.next_in;
            input = strm.input;
            have = strm.avail_in;
            hold = state.hold;
            bits = state.bits;
            if (state.mode === TYPE) {
              state.back = -1;
            }
            break;
          }
          state.back = 0;
          for (; ; ) {
            here = state.lencode[hold & (1 << state.lenbits) - 1];
            here_bits = here >>> 24;
            here_op = here >>> 16 & 255;
            here_val = here & 65535;
            if (here_bits <= bits) {
              break;
            }
            if (have === 0) {
              break inf_leave;
            }
            have--;
            hold += input[next++] << bits;
            bits += 8;
          }
          if (here_op && (here_op & 240) === 0) {
            last_bits = here_bits;
            last_op = here_op;
            last_val = here_val;
            for (; ; ) {
              here = state.lencode[last_val + ((hold & (1 << last_bits + last_op) - 1) >> last_bits)];
              here_bits = here >>> 24;
              here_op = here >>> 16 & 255;
              here_val = here & 65535;
              if (last_bits + here_bits <= bits) {
                break;
              }
              if (have === 0) {
                break inf_leave;
              }
              have--;
              hold += input[next++] << bits;
              bits += 8;
            }
            hold >>>= last_bits;
            bits -= last_bits;
            state.back += last_bits;
          }
          hold >>>= here_bits;
          bits -= here_bits;
          state.back += here_bits;
          state.length = here_val;
          if (here_op === 0) {
            state.mode = LIT;
            break;
          }
          if (here_op & 32) {
            state.back = -1;
            state.mode = TYPE;
            break;
          }
          if (here_op & 64) {
            strm.msg = "invalid literal/length code";
            state.mode = BAD;
            break;
          }
          state.extra = here_op & 15;
          state.mode = LENEXT;
        /* falls through */
        case LENEXT:
          if (state.extra) {
            n = state.extra;
            while (bits < n) {
              if (have === 0) {
                break inf_leave;
              }
              have--;
              hold += input[next++] << bits;
              bits += 8;
            }
            state.length += hold & (1 << state.extra) - 1;
            hold >>>= state.extra;
            bits -= state.extra;
            state.back += state.extra;
          }
          state.was = state.length;
          state.mode = DIST;
        /* falls through */
        case DIST:
          for (; ; ) {
            here = state.distcode[hold & (1 << state.distbits) - 1];
            here_bits = here >>> 24;
            here_op = here >>> 16 & 255;
            here_val = here & 65535;
            if (here_bits <= bits) {
              break;
            }
            if (have === 0) {
              break inf_leave;
            }
            have--;
            hold += input[next++] << bits;
            bits += 8;
          }
          if ((here_op & 240) === 0) {
            last_bits = here_bits;
            last_op = here_op;
            last_val = here_val;
            for (; ; ) {
              here = state.distcode[last_val + ((hold & (1 << last_bits + last_op) - 1) >> last_bits)];
              here_bits = here >>> 24;
              here_op = here >>> 16 & 255;
              here_val = here & 65535;
              if (last_bits + here_bits <= bits) {
                break;
              }
              if (have === 0) {
                break inf_leave;
              }
              have--;
              hold += input[next++] << bits;
              bits += 8;
            }
            hold >>>= last_bits;
            bits -= last_bits;
            state.back += last_bits;
          }
          hold >>>= here_bits;
          bits -= here_bits;
          state.back += here_bits;
          if (here_op & 64) {
            strm.msg = "invalid distance code";
            state.mode = BAD;
            break;
          }
          state.offset = here_val;
          state.extra = here_op & 15;
          state.mode = DISTEXT;
        /* falls through */
        case DISTEXT:
          if (state.extra) {
            n = state.extra;
            while (bits < n) {
              if (have === 0) {
                break inf_leave;
              }
              have--;
              hold += input[next++] << bits;
              bits += 8;
            }
            state.offset += hold & (1 << state.extra) - 1;
            hold >>>= state.extra;
            bits -= state.extra;
            state.back += state.extra;
          }
          if (state.offset > state.dmax) {
            strm.msg = "invalid distance too far back";
            state.mode = BAD;
            break;
          }
          state.mode = MATCH;
        /* falls through */
        case MATCH:
          if (left === 0) {
            break inf_leave;
          }
          copy = _out - left;
          if (state.offset > copy) {
            copy = state.offset - copy;
            if (copy > state.whave) {
              if (state.sane) {
                strm.msg = "invalid distance too far back";
                state.mode = BAD;
                break;
              }
            }
            if (copy > state.wnext) {
              copy -= state.wnext;
              from = state.wsize - copy;
            } else {
              from = state.wnext - copy;
            }
            if (copy > state.length) {
              copy = state.length;
            }
            from_source = state.window;
          } else {
            from_source = output;
            from = put - state.offset;
            copy = state.length;
          }
          if (copy > left) {
            copy = left;
          }
          left -= copy;
          state.length -= copy;
          do {
            output[put++] = from_source[from++];
          } while (--copy);
          if (state.length === 0) {
            state.mode = LEN;
          }
          break;
        case LIT:
          if (left === 0) {
            break inf_leave;
          }
          output[put++] = state.length;
          left--;
          state.mode = LEN;
          break;
        case CHECK:
          if (state.wrap) {
            while (bits < 32) {
              if (have === 0) {
                break inf_leave;
              }
              have--;
              hold |= input[next++] << bits;
              bits += 8;
            }
            _out -= left;
            strm.total_out += _out;
            state.total += _out;
            if (state.wrap & 4 && _out) {
              strm.adler = state.check = /*UPDATE_CHECK(state.check, put - _out, _out);*/
              state.flags ? crc32_1(state.check, output, _out, put - _out) : adler32_1(state.check, output, _out, put - _out);
            }
            _out = left;
            if (state.wrap & 4 && (state.flags ? hold : zswap32(hold)) !== state.check) {
              strm.msg = "incorrect data check";
              state.mode = BAD;
              break;
            }
            hold = 0;
            bits = 0;
          }
          state.mode = LENGTH;
        /* falls through */
        case LENGTH:
          if (state.wrap && state.flags) {
            while (bits < 32) {
              if (have === 0) {
                break inf_leave;
              }
              have--;
              hold += input[next++] << bits;
              bits += 8;
            }
            if (state.wrap & 4 && hold !== (state.total & 4294967295)) {
              strm.msg = "incorrect length check";
              state.mode = BAD;
              break;
            }
            hold = 0;
            bits = 0;
          }
          state.mode = DONE;
        /* falls through */
        case DONE:
          ret = Z_STREAM_END$1;
          break inf_leave;
        case BAD:
          ret = Z_DATA_ERROR$1;
          break inf_leave;
        case MEM:
          return Z_MEM_ERROR$1;
        case SYNC:
        /* falls through */
        default:
          return Z_STREAM_ERROR$1;
      }
    }
  strm.next_out = put;
  strm.avail_out = left;
  strm.next_in = next;
  strm.avail_in = have;
  state.hold = hold;
  state.bits = bits;
  if (state.wsize || _out !== strm.avail_out && state.mode < BAD && (state.mode < CHECK || flush !== Z_FINISH$1)) {
    if (updatewindow(strm, strm.output, strm.next_out, _out - strm.avail_out)) ;
  }
  _in -= strm.avail_in;
  _out -= strm.avail_out;
  strm.total_in += _in;
  strm.total_out += _out;
  state.total += _out;
  if (state.wrap & 4 && _out) {
    strm.adler = state.check = /*UPDATE_CHECK(state.check, strm.next_out - _out, _out);*/
    state.flags ? crc32_1(state.check, output, _out, strm.next_out - _out) : adler32_1(state.check, output, _out, strm.next_out - _out);
  }
  strm.data_type = state.bits + (state.last ? 64 : 0) + (state.mode === TYPE ? 128 : 0) + (state.mode === LEN_ || state.mode === COPY_ ? 256 : 0);
  if ((_in === 0 && _out === 0 || flush === Z_FINISH$1) && ret === Z_OK$1) {
    ret = Z_BUF_ERROR;
  }
  return ret;
};
var inflateEnd = (strm) => {
  if (inflateStateCheck(strm)) {
    return Z_STREAM_ERROR$1;
  }
  let state = strm.state;
  if (state.window) {
    state.window = null;
  }
  strm.state = null;
  return Z_OK$1;
};
var inflateGetHeader = (strm, head) => {
  if (inflateStateCheck(strm)) {
    return Z_STREAM_ERROR$1;
  }
  const state = strm.state;
  if ((state.wrap & 2) === 0) {
    return Z_STREAM_ERROR$1;
  }
  state.head = head;
  head.done = false;
  return Z_OK$1;
};
var inflateSetDictionary = (strm, dictionary) => {
  const dictLength = dictionary.length;
  let state;
  let dictid;
  let ret;
  if (inflateStateCheck(strm)) {
    return Z_STREAM_ERROR$1;
  }
  state = strm.state;
  if (state.wrap !== 0 && state.mode !== DICT) {
    return Z_STREAM_ERROR$1;
  }
  if (state.mode === DICT) {
    dictid = 1;
    dictid = adler32_1(dictid, dictionary, dictLength, 0);
    if (dictid !== state.check) {
      return Z_DATA_ERROR$1;
    }
  }
  ret = updatewindow(strm, dictionary, dictLength, dictLength);
  if (ret) {
    state.mode = MEM;
    return Z_MEM_ERROR$1;
  }
  state.havedict = 1;
  return Z_OK$1;
};
var inflateReset_1 = inflateReset;
var inflateReset2_1 = inflateReset2;
var inflateResetKeep_1 = inflateResetKeep;
var inflateInit_1 = inflateInit;
var inflateInit2_1 = inflateInit2;
var inflate_2$1 = inflate$2;
var inflateEnd_1 = inflateEnd;
var inflateGetHeader_1 = inflateGetHeader;
var inflateSetDictionary_1 = inflateSetDictionary;
var inflateInfo = "pako inflate (from Nodeca project)";
var inflate_1$2 = {
  inflateReset: inflateReset_1,
  inflateReset2: inflateReset2_1,
  inflateResetKeep: inflateResetKeep_1,
  inflateInit: inflateInit_1,
  inflateInit2: inflateInit2_1,
  inflate: inflate_2$1,
  inflateEnd: inflateEnd_1,
  inflateGetHeader: inflateGetHeader_1,
  inflateSetDictionary: inflateSetDictionary_1,
  inflateInfo
};
function GZheader() {
  this.text = 0;
  this.time = 0;
  this.xflags = 0;
  this.os = 0;
  this.extra = null;
  this.extra_len = 0;
  this.name = "";
  this.comment = "";
  this.hcrc = 0;
  this.done = false;
}
var gzheader = GZheader;
var toString = Object.prototype.toString;
var {
  Z_NO_FLUSH,
  Z_FINISH,
  Z_OK,
  Z_STREAM_END,
  Z_NEED_DICT,
  Z_STREAM_ERROR,
  Z_DATA_ERROR,
  Z_MEM_ERROR
} = constants$2;
function Inflate$1(options) {
  this.options = common.assign({
    chunkSize: 1024 * 64,
    windowBits: 15,
    to: ""
  }, options || {});
  const opt = this.options;
  if (opt.raw && opt.windowBits >= 0 && opt.windowBits < 16) {
    opt.windowBits = -opt.windowBits;
    if (opt.windowBits === 0) {
      opt.windowBits = -15;
    }
  }
  if (opt.windowBits >= 0 && opt.windowBits < 16 && !(options && options.windowBits)) {
    opt.windowBits += 32;
  }
  if (opt.windowBits > 15 && opt.windowBits < 48) {
    if ((opt.windowBits & 15) === 0) {
      opt.windowBits |= 15;
    }
  }
  this.err = 0;
  this.msg = "";
  this.ended = false;
  this.chunks = [];
  this.strm = new zstream();
  this.strm.avail_out = 0;
  let status = inflate_1$2.inflateInit2(
    this.strm,
    opt.windowBits
  );
  if (status !== Z_OK) {
    throw new Error(messages[status]);
  }
  this.header = new gzheader();
  inflate_1$2.inflateGetHeader(this.strm, this.header);
  if (opt.dictionary) {
    if (typeof opt.dictionary === "string") {
      opt.dictionary = strings.string2buf(opt.dictionary);
    } else if (toString.call(opt.dictionary) === "[object ArrayBuffer]") {
      opt.dictionary = new Uint8Array(opt.dictionary);
    }
    if (opt.raw) {
      status = inflate_1$2.inflateSetDictionary(this.strm, opt.dictionary);
      if (status !== Z_OK) {
        throw new Error(messages[status]);
      }
    }
  }
}
Inflate$1.prototype.push = function(data, flush_mode) {
  const strm = this.strm;
  const chunkSize = this.options.chunkSize;
  const dictionary = this.options.dictionary;
  let status, _flush_mode, last_avail_out;
  if (this.ended) return false;
  if (flush_mode === ~~flush_mode) _flush_mode = flush_mode;
  else _flush_mode = flush_mode === true ? Z_FINISH : Z_NO_FLUSH;
  if (toString.call(data) === "[object ArrayBuffer]") {
    strm.input = new Uint8Array(data);
  } else {
    strm.input = data;
  }
  strm.next_in = 0;
  strm.avail_in = strm.input.length;
  for (; ; ) {
    if (strm.avail_out === 0) {
      strm.output = new Uint8Array(chunkSize);
      strm.next_out = 0;
      strm.avail_out = chunkSize;
    }
    status = inflate_1$2.inflate(strm, _flush_mode);
    if (status === Z_NEED_DICT && dictionary) {
      status = inflate_1$2.inflateSetDictionary(strm, dictionary);
      if (status === Z_OK) {
        status = inflate_1$2.inflate(strm, _flush_mode);
      } else if (status === Z_DATA_ERROR) {
        status = Z_NEED_DICT;
      }
    }
    while (strm.avail_in > 0 && status === Z_STREAM_END && strm.state.wrap > 0 && data[strm.next_in] !== 0) {
      inflate_1$2.inflateReset(strm);
      status = inflate_1$2.inflate(strm, _flush_mode);
    }
    switch (status) {
      case Z_STREAM_ERROR:
      case Z_DATA_ERROR:
      case Z_NEED_DICT:
      case Z_MEM_ERROR:
        this.onEnd(status);
        this.ended = true;
        return false;
    }
    last_avail_out = strm.avail_out;
    if (strm.next_out) {
      if (strm.avail_out === 0 || status === Z_STREAM_END) {
        if (this.options.to === "string") {
          let next_out_utf8 = strings.utf8border(strm.output, strm.next_out);
          let tail = strm.next_out - next_out_utf8;
          let utf8str = strings.buf2string(strm.output, next_out_utf8);
          strm.next_out = tail;
          strm.avail_out = chunkSize - tail;
          if (tail) strm.output.set(strm.output.subarray(next_out_utf8, next_out_utf8 + tail), 0);
          this.onData(utf8str);
        } else {
          this.onData(strm.output.length === strm.next_out ? strm.output : strm.output.subarray(0, strm.next_out));
        }
      }
    }
    if (status === Z_OK && last_avail_out === 0) continue;
    if (status === Z_STREAM_END) {
      status = inflate_1$2.inflateEnd(this.strm);
      this.onEnd(status);
      this.ended = true;
      return true;
    }
    if (strm.avail_in === 0) break;
  }
  return true;
};
Inflate$1.prototype.onData = function(chunk) {
  this.chunks.push(chunk);
};
Inflate$1.prototype.onEnd = function(status) {
  if (status === Z_OK) {
    if (this.options.to === "string") {
      this.result = this.chunks.join("");
    } else {
      this.result = common.flattenChunks(this.chunks);
    }
  }
  this.chunks = [];
  this.err = status;
  this.msg = this.strm.msg;
};
function inflate$1(input, options) {
  const inflator = new Inflate$1(options);
  inflator.push(input);
  if (inflator.err) throw inflator.msg || messages[inflator.err];
  return inflator.result;
}
function inflateRaw$1(input, options) {
  options = options || {};
  options.raw = true;
  return inflate$1(input, options);
}
var Inflate_1$1 = Inflate$1;
var inflate_2 = inflate$1;
var inflateRaw_1$1 = inflateRaw$1;
var ungzip$1 = inflate$1;
var constants = constants$2;
var inflate_1$1 = {
  Inflate: Inflate_1$1,
  inflate: inflate_2,
  inflateRaw: inflateRaw_1$1,
  ungzip: ungzip$1,
  constants
};
var { Deflate, deflate, deflateRaw, gzip } = deflate_1$1;
var { Inflate, inflate, inflateRaw, ungzip } = inflate_1$1;
var inflate_1 = inflate;
var inflateRaw_1 = inflateRaw;

// src/services/lyric_service.ts
function encodeBase64(data) {
  let binary = "";
  for (let i = 0; i < data.length; i++) binary += String.fromCharCode(data[i]);
  return btoa(binary);
}
function decodeBase64(str) {
  const binary = atob(str);
  const bytes = new Uint8Array(binary.length);
  for (let i = 0; i < binary.length; i++) bytes[i] = binary.charCodeAt(i);
  return bytes;
}
var KuwoLyricService = class _KuwoLyricService {
  static buf_key = new Uint8Array([121, 101, 101, 108, 105, 111, 110]);
  async getLyric(musicInfo) {
    const songId = musicInfo.songmid || musicInfo.songId;
    if (!songId) throw new Error("\u7F3A\u5C11songmid\u6216songId\u53C2\u6570");
    const params = this.buildParams(songId, true);
    const url = `http://newlyric.kuwo.cn/newlyric.lrc?${params}`;
    const response = await fetch(url, { headers: { "User-Agent": "Mozilla/5.0 (Windows NT 10.0; WOW64) AppleWebKit/537.36" } });
    if (response.status !== 200) throw new Error(`\u8BF7\u6C42\u5931\u8D25: ${response.status}`);
    const buf = new Uint8Array(await response.arrayBuffer());
    const headerStr = new TextDecoder().decode(buf);
    const index = headerStr.indexOf("\r\n\r\n");
    if (index === -1) throw new Error("\u672A\u627E\u5230\u6570\u636E\u5206\u9694\u7B26");
    const headerLines = headerStr.slice(0, index).split("\r\n");
    const headers = {};
    for (const line of headerLines) {
      const ci = line.indexOf("=");
      if (ci !== -1) headers[line.slice(0, ci)] = line.slice(ci + 1);
    }
    const isGetLyricx = headers["lrcx"] === "1";
    const lrcData = buf.slice(index + 4);
    let result;
    try {
      result = inflate_1(lrcData);
      if (!result || result.length === 0) throw new Error("\u89E3\u538B\u7ED3\u679C\u4E3A\u7A7A");
    } catch (e) {
      throw new Error(`\u89E3\u538B\u5931\u8D25: ${e}`);
    }
    if (!isGetLyricx) return { lyric: this.decodeGB18030(result), tlyric: "", rlyric: "", lxlyric: "" };
    const base64Str = new TextDecoder().decode(result);
    const buf_str = decodeBase64(base64Str);
    const buf_str_len = buf_str.length;
    const output = new Uint8Array(buf_str_len);
    let i = 0;
    while (i < buf_str_len) {
      let j = 0;
      while (j < _KuwoLyricService.buf_key.length && i < buf_str_len) {
        output[i] = _KuwoLyricService.buf_key[j] ^ buf_str[i];
        i++;
        j++;
      }
    }
    const decrypted = this.decodeGB18030(output);
    return this.parseLyric(decrypted);
  }
  buildParams(id, isGetLyricx) {
    let params = `user=12345,web,web,web&requester=localhost&req=1&rid=MUSIC_${id}`;
    if (isGetLyricx) params += "&lrcx=1";
    const buf_str = new TextEncoder().encode(params);
    const output = new Uint8Array(buf_str.length);
    let i = 0;
    while (i < buf_str.length) {
      let j = 0;
      while (j < _KuwoLyricService.buf_key.length && i < buf_str.length) {
        output[i] = _KuwoLyricService.buf_key[j] ^ buf_str[i];
        i++;
        j++;
      }
    }
    return encodeBase64(output);
  }
  parseLyric(str) {
    const lines = str.split("\n");
    const lrcLines = [];
    const lxlrcLines = [];
    for (const line of lines) {
      const trimmed = line.trim();
      if (!trimmed) continue;
      const timeMatch = /^\[(\d{2}):(\d{2})\.(\d{2,3})\]/.exec(trimmed);
      if (!timeMatch) {
        lrcLines.push(trimmed);
        lxlrcLines.push(trimmed);
        continue;
      }
      const content = trimmed.replace(/^\[\d{2}:\d{2}\.\d{2,3}\]/, "");
      lrcLines.push(`[${timeMatch[1]}:${timeMatch[2]}.${timeMatch[3]}]${content.replace(/<\d+,\d+>/g, "")}`);
      const wordMatches = content.match(/<(\d+),(\d+)>([^<]*)/g);
      if (wordMatches) {
        const words = wordMatches.map((m) => {
          const mm = /<(\d+),(\d+)>([^<]*)/.exec(m);
          return mm ? `<${mm[1]},${mm[2]}>${mm[3]}` : "";
        }).join("");
        lxlrcLines.push(`[${timeMatch[1]}:${timeMatch[2]}.${timeMatch[3]}]${words}`);
      } else lxlrcLines.push(`[${timeMatch[1]}:${timeMatch[2]}.${timeMatch[3]}]${content}`);
    }
    return { lyric: lrcLines.join("\n"), tlyric: "", rlyric: "", lxlyric: lxlrcLines.join("\n") };
  }
  decodeGB18030(buf) {
    try {
      return new TextDecoder("gb18030").decode(buf);
    } catch (_e) {
      return new TextDecoder("gbk").decode(buf);
    }
  }
};
var KugouLyricService = class {
  async getLyric(musicInfo) {
    const hash = musicInfo.hash;
    const name = musicInfo.name;
    if (!hash || !name) throw new Error("\u7F3A\u5C11hash\u6216name\u53C2\u6570");
    const searchUrl = `http://lyrics.kugou.com/search?ver=1&man=yes&client=pc&keyword=${encodeURIComponent(name)}&hash=${hash}&timelength=0&lrctxt=1`;
    const searchResponse = await fetch(searchUrl, { headers: { "KG-RC": "1", "KG-THash": "expand_search_manager.cpp:852736169:451", "User-Agent": "KuGou2012-9020-ExpandSearchManager" } });
    if (searchResponse.status !== 200) throw new Error(`\u641C\u7D22\u8BF7\u6C42\u5931\u8D25: ${searchResponse.status}`);
    const searchData = await searchResponse.json();
    if (searchData.status !== 200 || !searchData.candidates || searchData.candidates.length === 0) throw new Error("\u672A\u627E\u5230\u6B4C\u8BCD\u5019\u9009");
    const candidate = searchData.candidates[0];
    const downloadUrl = `http://lyrics.kugou.com/download?ver=1&client=pc&id=${candidate.id}&accesskey=${candidate.accesskey}&fmt=krc&charset=utf8`;
    const downloadResponse = await fetch(downloadUrl, { headers: { "User-Agent": "KuGou2012-9020-ExpandSearchManager" } });
    if (downloadResponse.status !== 200) throw new Error(`\u4E0B\u8F7D\u8BF7\u6C42\u5931\u8D25: ${downloadResponse.status}`);
    const downloadData = await downloadResponse.json();
    if (downloadData.fmt === "krc") return this.decodeKrc(downloadData.content);
    else if (downloadData.fmt === "lrc") {
      const decoded = decodeBase64(downloadData.content);
      return { lyric: new TextDecoder().decode(decoded), tlyric: "", rlyric: "", lxlyric: "" };
    } else throw new Error(`\u4E0D\u652F\u6301\u7684\u6B4C\u8BCD\u683C\u5F0F: ${downloadData.fmt}`);
  }
  async decodeKrc(content) {
    const enc_key = new Uint8Array([64, 71, 97, 119, 94, 50, 116, 71, 81, 54, 49, 45, 206, 210, 110, 105]);
    const buf_str = decodeBase64(content).slice(4);
    const decrypted = new Uint8Array(buf_str.length);
    for (let i = 0; i < buf_str.length; i++) decrypted[i] = buf_str[i] ^ enc_key[i % 16];
    let result;
    try {
      result = inflate_1(decrypted);
    } catch (_e) {
      try {
        result = inflateRaw_1(decrypted);
      } catch (e2) {
        throw new Error("KRC\u89E3\u538B\u5931\u8D25: " + e2.message);
      }
    }
    return this.parseKrc(new TextDecoder().decode(result));
  }
  parseKrc(str) {
    str = str.replace(/\r/g, "");
    const headExp = /^.*\[id:\$\w+\]\n/;
    if (headExp.test(str)) str = str.replace(headExp, "");
    let tlyric = "";
    let rlyric = "";
    const transMatch = str.match(/\[language:([\w=\\/+]+)\]/);
    if (transMatch) {
      str = str.replace(/\[language:[\w=\\/+]+\]\n/, "");
      try {
        const jsonStr = new TextDecoder().decode(decodeBase64(transMatch[1]));
        const json = JSON.parse(jsonStr);
        if (json.content) {
          for (const item of json.content) {
            if (item.type === 0) rlyric = item.lyricContent?.join("\n") || "";
            else if (item.type === 1) tlyric = item.lyricContent?.join("\n") || "";
          }
        }
      } catch (_e) {
      }
    }
    let li = 0;
    let lxlyric = str.replace(/\[((\d+),\d+)\].*/g, (match) => {
      const result = match.match(/\[((\d+),\d+)\].*/);
      if (!result) return match;
      let time = parseInt(result[2]);
      let ms = time % 1e3;
      time = Math.floor(time / 1e3);
      const m = Math.floor(time / 60).toString().padStart(2, "0");
      const s = (time % 60).toString().padStart(2, "0");
      const timeStr = `${m}:${s}.${ms}`;
      if (rlyric) {
        const rl = rlyric.split("\n");
        if (rl[li]) {
          rl[li] = `[${timeStr}]${rl[li]}`;
          rlyric = rl.join("\n");
        }
      }
      if (tlyric) {
        const tl = tlyric.split("\n");
        if (tl[li]) {
          tl[li] = `[${timeStr}]${tl[li]}`;
          tlyric = tl.join("\n");
        }
      }
      li++;
      return match.replace(result[1], timeStr);
    });
    lxlyric = lxlyric.replace(/<(\d+,\d+),\d+>/g, "<$1>");
    const lyric = lxlyric.replace(/<\d+,\d+>/g, "");
    return { lyric, tlyric, rlyric, lxlyric };
  }
};
var QQMusicLyricService = class {
  async getLyric(musicInfo) {
    const songId = musicInfo.songId || musicInfo.songmid;
    if (!songId) throw new Error("\u7F3A\u5C11songId\u53C2\u6570");
    const url = `https://c.y.qq.com/lyric/fcgi-bin/fcg_query_lyric_new.fcg?songmid=${songId}&g_tk=5381&loginUin=0&hostUin=0&format=json&inCharset=utf8&outCharset=utf-8&platform=yqq`;
    const response = await fetch(url, { headers: { "Referer": "https://y.qq.com/portal/player.html", "User-Agent": "Mozilla/5.0 (Windows NT 10.0; WOW64) AppleWebKit/537.36" } });
    if (response.status !== 200) throw new Error(`\u8BF7\u6C42\u5931\u8D25: ${response.status}`);
    const data = await response.json();
    if (data.code !== 0) throw new Error(`API\u8FD4\u56DE\u9519\u8BEF: code=${data.code}`);
    const result = { lyric: "", tlyric: "", rlyric: "", lxlyric: "" };
    if (data.lyric) result.lyric = this.decodeLyric(data.lyric);
    if (data.trans) result.tlyric = this.decodeLyric(data.trans);
    return result;
  }
  decodeLyric(base64Str) {
    try {
      const decoded = decodeBase64(base64Str);
      return new TextDecoder().decode(decoded);
    } catch (_e) {
      return "";
    }
  }
};
var NeteaseLyricService = class {
  async getLyric(musicInfo) {
    const songId = musicInfo.songId;
    if (!songId) throw new Error("\u7F3A\u5C11songId\u53C2\u6570");
    const url = `https://music.163.com/api/song/lyric?id=${songId}&lv=1&kv=1&tv=-1`;
    const response = await fetch(url, { headers: { "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36", "Referer": "https://music.163.com/" } });
    if (response.status !== 200) throw new Error(`\u8BF7\u6C42\u5931\u8D25: ${response.status}`);
    const data = await response.json();
    if (data.code !== 200) throw new Error(`API\u8FD4\u56DE\u9519\u8BEF: code=${data.code}`);
    return { lyric: data.lrc?.lyric || "", tlyric: data.tlyric?.lyric || "", rlyric: data.romalrc?.lyric || "", lxlyric: "" };
  }
};
var MiguLyricService = class _MiguLyricService {
  static DELTA = 2654435769n;
  static MIN_LENGTH = 32;
  static keyArr = [27303562373562475n, 18014862372307051n, 22799692160172081n, 34058940340699235n, 30962724186095721n, 27303523720101991n, 27303523720101998n, 31244139033526382n, 28992395054481524n];
  static toLong(str) {
    const num = typeof str === "string" ? BigInt("0x" + str) : str;
    const MAX = 9223372036854775807n;
    const MIN = -9223372036854775808n;
    if (num > MAX) return _MiguLyricService.toLong(num - (1n << 64n));
    else if (num < MIN) return _MiguLyricService.toLong(num + (1n << 64n));
    return num;
  }
  static longToBytes(l) {
    const result = new Uint8Array(8);
    let num = l;
    for (let i = 0; i < 8; i++) {
      result[i] = Number(num & 0xffn);
      num >>= 8n;
    }
    return result;
  }
  static toBigintArray(data) {
    const length = Math.floor(data.length / 16);
    const jArr = [];
    for (let i = 0; i < length; i++) {
      const hex = data.substring(i * 16, i * 16 + 16);
      jArr.push(_MiguLyricService.toLong(hex));
    }
    return jArr;
  }
  static teaDecrypt(data, key) {
    const length = data.length;
    const lengthBitint = BigInt(length);
    if (length >= 1) {
      let j2 = data[0];
      let j3 = _MiguLyricService.toLong((6n + 52n / lengthBitint) * _MiguLyricService.DELTA);
      while (true) {
        const j4 = j3;
        if (j4 === 0n) break;
        const j5 = _MiguLyricService.toLong(3n & j4 >> 2n);
        let j6 = lengthBitint;
        while (true) {
          j6--;
          if (j6 > 0n) {
            const j7 = data[Number(j6 - 1n)];
            const temp12 = _MiguLyricService.toLong(j2 ^ j4) + _MiguLyricService.toLong(j7 ^ key[Number(_MiguLyricService.toLong(3n & j6) ^ j5)]);
            const temp22 = _MiguLyricService.toLong(j7 >> 5n ^ j2 << 2n) + _MiguLyricService.toLong(j2 >> 3n ^ j7 << 4n);
            j2 = _MiguLyricService.toLong(data[Number(j6)] - (temp12 ^ temp22));
            data[Number(j6)] = j2;
          } else break;
        }
        const j8 = data[Number(lengthBitint - 1n)];
        const temp1 = _MiguLyricService.toLong(_MiguLyricService.toLong(key[Number(_MiguLyricService.toLong(j6 & 3n) ^ j5)] ^ j8) + _MiguLyricService.toLong(j2 ^ j4));
        const temp2 = _MiguLyricService.toLong(j8 >> 5n ^ j2 << 2n) + _MiguLyricService.toLong(j2 >> 3n ^ j8 << 4n);
        j2 = _MiguLyricService.toLong(data[0] - (temp1 ^ temp2));
        data[0] = j2;
        j3 = _MiguLyricService.toLong(j4 - _MiguLyricService.DELTA);
      }
    }
    return data;
  }
  static longArrToString(data) {
    const result = [];
    for (const j of data) {
      const bytes = _MiguLyricService.longToBytes(j);
      result.push(new TextDecoder("utf-16le").decode(bytes));
    }
    return result.join("");
  }
  static decrypt(data) {
    if (data == null || data.length < _MiguLyricService.MIN_LENGTH) return data;
    const bigIntArray = _MiguLyricService.toBigintArray(data);
    const decrypted = _MiguLyricService.teaDecrypt(bigIntArray, _MiguLyricService.keyArr);
    return _MiguLyricService.longArrToString(decrypted);
  }
  async getLyricText(url, tryNum = 0) {
    const response = await fetch(url, { headers: { "Referer": "https://app.c.nf.migu.cn/", "User-Agent": "Mozilla/5.0 (Linux; Android 5.1.1)", "channel": "0146921" } });
    if (response.status === 200) return await response.text();
    if (tryNum > 5 || response.status === 404) throw new Error("\u6B4C\u8BCD\u83B7\u53D6\u5931\u8D25");
    await new Promise((r) => setTimeout(r, 1e3));
    return this.getLyricText(url, tryNum + 1);
  }
  parseLyric(str) {
    const lines = str.replace(/\r/g, "").split("\n");
    const lxlrcLines = [];
    const lrcLines = [];
    const lineTimeExp = /^\s*\[(\d+),\d+\]/;
    const wordTimeAllExp = /(\(\d+,\d+\))/g;
    for (const line of lines) {
      if (line.length < 6) continue;
      const result = lineTimeExp.exec(line);
      if (!result) continue;
      const startTime = parseInt(result[1]);
      let time = startTime;
      let ms = time % 1e3;
      time = Math.floor(time / 1e3);
      const m = Math.floor(time / 60).toString().padStart(2, "0");
      time = time % 60;
      const s = Math.floor(time).toString().padStart(2, "0");
      const timeStr = `${m}:${s}.${ms}`;
      let words = line.replace(lineTimeExp, "");
      lrcLines.push(`[${timeStr}]${words.replace(wordTimeAllExp, "")}`);
      const times = words.match(wordTimeAllExp);
      if (!times) continue;
      const parsedTimes = times.map((t) => {
        const m2 = /\((\d+),(\d+)\)/.exec(t);
        return m2 ? `<${parseInt(m2[1]) - startTime},${m2[2]}>` : "";
      });
      const wordArr = words.split(/\(\d+,\d+\)/);
      lxlrcLines.push(`[${timeStr}]${parsedTimes.map((t, i) => `${t}${wordArr[i] || ""}`).join("")}`);
    }
    return { lyric: lrcLines.join("\n"), tlyric: "", rlyric: "", lxlyric: lxlrcLines.join("\n") };
  }
  async getMrc(url) {
    const text = await this.getLyricText(url);
    return this.parseLyric(_MiguLyricService.decrypt(text));
  }
  async getLrc(url) {
    const text = await this.getLyricText(url);
    return { lyric: text, tlyric: "", rlyric: "", lxlyric: "" };
  }
  async getLyric(musicInfo) {
    if (!musicInfo.copyrightId) throw new Error("\u7F3A\u5C11copyrightId\u53C2\u6570");
    const searchUrl = `https://app.c.nf.migu.cn/MIGUM2.0/v1.0/content/search_all.do?isCopyright=1&isCorrect=1&pageNo=1&pageSize=10&searchSwitch=%7B%22song%22%3A1%7D&sort=0&text=${encodeURIComponent((musicInfo.name || "") + " " + (musicInfo.singer || ""))}`;
    const response = await fetch(searchUrl, { headers: { "User-Agent": "Mozilla/5.0 (Windows NT 10.0; WOW64) AppleWebKit/537.36", "Accept": "application/json" } });
    if (response.status !== 200) throw new Error(`\u641C\u7D22\u6B4C\u66F2\u5931\u8D25: ${response.status}`);
    const data = await response.json();
    if (data.code !== "000000" || !data.songResultData || !data.songResultData.resultList) throw new Error("\u641C\u7D22\u6B4C\u66F2\u5931\u8D25: \u65E0\u6548\u7684\u54CD\u5E94");
    let matchedSong = null;
    for (const item of data.songResultData.resultList) {
      const songs = Array.isArray(item) ? item : [item];
      for (const song of songs) {
        if (song.copyrightId === musicInfo.copyrightId) {
          matchedSong = song;
          break;
        }
      }
      if (matchedSong) break;
    }
    if (!matchedSong) throw new Error("\u672A\u627E\u5230\u5339\u914D\u7684\u6B4C\u66F2");
    if (matchedSong.mrcurl) return this.getMrc(matchedSong.mrcurl);
    if (matchedSong.lyricUrl) return this.getLrc(matchedSong.lyricUrl);
    throw new Error("\u672A\u627E\u5230\u6B4C\u8BCD\u94FE\u63A5");
  }
};
var LyricService = class {
  kwService = new KuwoLyricService();
  kgService = new KugouLyricService();
  txService = new QQMusicLyricService();
  wyService = new NeteaseLyricService();
  mgService = new MiguLyricService();
  async getLyric(musicInfo) {
    switch (musicInfo.source) {
      case "kw":
        return await this.kwService.getLyric(musicInfo);
      case "kg":
        return await this.kgService.getLyric(musicInfo);
      case "tx":
        return await this.txService.getLyric(musicInfo);
      case "wy":
        return await this.wyService.getLyric(musicInfo);
      case "mg":
        return await this.mgService.getLyric(musicInfo);
      default:
        throw new Error(`\u4E0D\u652F\u6301\u7684\u6B4C\u8BCD\u6E90: ${musicInfo.source}`);
    }
  }
};

// src/index.ts
var REQUEST_TIMEOUT_MS = 3e4;
var _runnerCache = /* @__PURE__ */ new Map();
var CACHE_MAX_AGE_MS = 10 * 60 * 1e3;
var CACHE_MAX_SIZE = 5;
function simpleHash(s) {
  let h = 0;
  for (let i = 0; i < s.length; i++) {
    h = (h << 5) - h + s.charCodeAt(i) | 0;
  }
  return "h" + Math.abs(h).toString(36);
}
async function getOrCreateRunner(scriptInfo) {
  const hash = simpleHash(scriptInfo.rawScript);
  const cacheKey = `${scriptInfo.id}:${hash}`;
  const cached = _runnerCache.get(cacheKey);
  if (cached && cached.runner.isReady()) {
    cached.lastUsedAt = Date.now();
    console.log(`[RunnerCache] \u2705 HIT ${scriptInfo.name} (age=${Math.round((Date.now() - cached.createdAt) / 1e3)}s, key=${cacheKey.substring(0, 30)}...)`);
    return cached.runner;
  }
  console.log(`[RunnerCache] MISS ${scriptInfo.name}, creating new instance...`);
  const runner = new ScriptRunner(scriptInfo);
  await runner.initialize();
  _runnerCache.set(cacheKey, {
    runner,
    scriptId: scriptInfo.id,
    rawScriptHash: hash,
    createdAt: Date.now(),
    lastUsedAt: Date.now()
  });
  if (_runnerCache.size > CACHE_MAX_SIZE) {
    const now = Date.now();
    for (const [key, entry] of _runnerCache) {
      if (now - entry.lastUsedAt > CACHE_MAX_AGE_MS || _runnerCache.size > CACHE_MAX_SIZE) {
        try {
          entry.runner.dispose();
        } catch (_e) {
        }
        _runnerCache.delete(key);
        console.log(`[RunnerCache] \u{1F5D1}\uFE0F Evicted ${key.substring(0, 30)}...`);
      }
    }
  }
  return runner;
}
function jsonResponse(data, status = 200, msg = "success", extra) {
  const body = { code: status === 200 ? 200 : status, msg, data };
  if (extra) Object.assign(body, extra);
  return Response.json(body, { status });
}
var searchService = new SearchService();
var shortLinkService = new ShortLinkService();
var songListService = new SongListService();
var lyricService = new LyricService();
async function handleImportScriptFromUrl(request, storage) {
  const body = await request.json();
  if (!body.url) return jsonResponse(null, 400, "\u7F3A\u5C11 url \u53C2\u6570");
  try {
    const info = await storage.importScriptFromUrl(body.url);
    const loadedScripts = await storage.getScripts();
    const stats = await storage.getScriptStats();
    const defaultInfo = await storage.getDefaultScript();
    const scriptsFormatted = await Promise.all(loadedScripts.map(async (s) => {
      const ss = stats[s.id];
      const sr = ss ? storage.getScriptSuccessRate(ss) : 0;
      const tr = ss ? ss.success + ss.fail : 0;
      const icb = await storage.isScriptCircuitBreakerTripped(s.id);
      return { id: s.id, name: s.name, description: s.description, author: s.author, homepage: s.homepage, version: s.version, createdAt: new Date(s.createdAt).toISOString(), supportedSources: s.supportedSources.length === 1 && s.supportedSources[0] === "unknown" ? ["kw", "kg", "tx", "wy", "mg"] : s.supportedSources, isDefault: s.isDefault, successRate: tr > 0 ? sr : null, successCount: ss?.success || 0, failCount: ss?.fail || 0, totalRequests: tr, isCircuitBroken: icb };
    }));
    return jsonResponse({
      success: true,
      defaultSource: defaultInfo ? { id: defaultInfo.id, name: defaultInfo.name, supportedSources: (await storage.getScript(defaultInfo.id))?.supportedSources || [] } : null,
      scripts: scriptsFormatted
    }, 200, "\u4ECEURL\u5BFC\u5165\u6210\u529F");
  } catch (e) {
    return jsonResponse(null, 500, e.message || "\u5BFC\u5165\u5931\u8D25");
  }
}
async function handleImportScriptRaw(request, storage) {
  const body = await request.json();
  if (!body.content || !body.name) return jsonResponse(null, 400, "\u7F3A\u5C11 name \u6216 content \u53C2\u6570");
  try {
    const info = await storage.importScriptRaw(body.name, body.content, body.url || "");
    return jsonResponse(info);
  } catch (e) {
    return jsonResponse(null, 500, e.message || "\u5BFC\u5165\u5931\u8D25");
  }
}
async function handleGetLoadedScripts(request, storage) {
  try {
    const scripts = await storage.getScripts();
    const stats = await storage.getScriptStats();
    const result = await Promise.all(scripts.map(async (s) => {
      const scriptStats = stats[s.id];
      const successRate = scriptStats ? storage.getScriptSuccessRate(scriptStats) : 0;
      const totalRequests = scriptStats ? scriptStats.success + scriptStats.fail : 0;
      const isCircuitBroken = await storage.isScriptCircuitBreakerTripped(s.id);
      return {
        id: s.id,
        name: s.name,
        description: s.description,
        author: s.author,
        homepage: s.homepage,
        version: s.version,
        createdAt: new Date(s.createdAt).toISOString(),
        supportedSources: s.supportedSources,
        isDefault: s.isDefault,
        successRate: totalRequests > 0 ? successRate : null,
        successCount: scriptStats?.success || 0,
        failCount: scriptStats?.fail || 0,
        totalRequests,
        isCircuitBroken
      };
    }));
    return jsonResponse(result);
  } catch (e) {
    return jsonResponse(null, 500, e.message);
  }
}
async function handleSetDefaultScript(request, storage) {
  const body = await request.json();
  if (!body.id) return jsonResponse(null, 400, "\u7F3A\u5C11 id \u53C2\u6570");
  try {
    await storage.setDefaultScript(body.id);
    return jsonResponse({ success: true });
  } catch (e) {
    return jsonResponse(null, 500, e.message);
  }
}
async function handleGetDefaultScript(storage) {
  try {
    const def = await storage.getDefaultScript();
    if (!def) return jsonResponse(null, 404, "\u672A\u8BBE\u7F6E\u9ED8\u8BA4\u811A\u672C");
    return jsonResponse({ id: def.id, name: def.name });
  } catch (e) {
    return jsonResponse(null, 500, e.message);
  }
}
async function handleDeleteScript(request, storage) {
  const body = await request.json();
  if (!body.id) return jsonResponse(null, 400, "\u7F3A\u5C11 id \u53C2\u6570");
  try {
    await storage.deleteScript(body.id);
    const loadedScripts = await storage.getScripts();
    const stats = await storage.getScriptStats();
    const defaultInfo = await storage.getDefaultScript();
    const scriptsFormatted = await Promise.all(loadedScripts.map(async (s) => {
      const ss = stats[s.id];
      const sr = ss ? storage.getScriptSuccessRate(ss) : 0;
      const tr = ss ? ss.success + ss.fail : 0;
      const icb = await storage.isScriptCircuitBreakerTripped(s.id);
      return { id: s.id, name: s.name, description: s.description, author: s.author, homepage: s.homepage, version: s.version, createdAt: new Date(s.createdAt).toISOString(), supportedSources: s.supportedSources, isDefault: s.isDefault, successRate: tr > 0 ? sr : null, successCount: ss?.success || 0, failCount: ss?.fail || 0, totalRequests: tr, isCircuitBroken: icb };
    }));
    return jsonResponse({
      success: true,
      defaultSource: defaultInfo ? { id: defaultInfo.id, name: defaultInfo.name, supportedSources: (await storage.getScript(defaultInfo.id))?.supportedSources || [] } : null,
      scripts: scriptsFormatted
    }, 200, "\u811A\u672C\u5DF2\u5220\u9664");
  } catch (e) {
    return jsonResponse(null, 500, e.message);
  }
}
async function handleGetLyric(request) {
  try {
    const body = await request.json();
    if (!body.source) return jsonResponse(null, 400, "\u7F3A\u5C11\u5FC5\u8981\u53C2\u6570: source");
    if (!body.songId) return jsonResponse(null, 400, "\u7F3A\u5C11\u5FC5\u8981\u53C2\u6570: songId");
    const musicInfo = { source: body.source };
    switch (body.source) {
      case "kw":
        musicInfo.songmid = body.songId;
        break;
      case "kg":
        musicInfo.hash = body.songId;
        musicInfo.name = body.name || "\u672A\u77E5\u6B4C\u66F2";
        break;
      case "tx":
        musicInfo.songId = body.songId;
        break;
      case "wy":
        musicInfo.songId = body.songId;
        break;
      case "mg":
        musicInfo.copyrightId = body.songId;
        musicInfo.name = body.name;
        musicInfo.singer = body.singer;
        break;
      default:
        return jsonResponse(null, 400, `\u4E0D\u652F\u6301\u7684\u97F3\u6E90: ${body.source}`);
    }
    const result = await lyricService.getLyric(musicInfo);
    return jsonResponse({ lyric: result.lyric, tlyric: result.tlyric, rlyric: result.rlyric, lxlyric: result.lxlyric }, 200, "\u83B7\u53D6\u6B4C\u8BCD\u6210\u529F");
  } catch (e) {
    return jsonResponse(null, 500, e.message || "\u83B7\u53D6\u6B4C\u8BCD\u5931\u8D25");
  }
}
async function handleSearch(request) {
  const url = new URL(request.url);
  const keyword = url.searchParams.get("keyword") || url.searchParams.get("key") || "";
  const source = url.searchParams.get("source") || "";
  const page = parseInt(url.searchParams.get("page") || "1");
  const limit = parseInt(url.searchParams.get("limit") || "20");
  if (!keyword) return jsonResponse(null, 400, "\u7F3A\u5C11 keyword \u53C2\u6570");
  try {
    const results = await searchService.search(keyword, source || void 0, page, limit);
    return jsonResponse(results);
  } catch (e) {
    return jsonResponse(null, 500, e.message);
  }
}
async function handleGetSongListDetail(request) {
  const body = await request.json();
  if (!body.source || !body.id) return jsonResponse(null, 400, "\u7F3A\u5C11 source \u6216 id \u53C2\u6570");
  try {
    const result = await songListService.getListDetail(body.source, body.id);
    return jsonResponse(result);
  } catch (e) {
    return jsonResponse(null, 500, e.message);
  }
}
async function handleGetSongListDetailByLink(request) {
  const body = await request.json();
  if (!body.link) return jsonResponse(null, 400, "\u7F3A\u5C11 link \u53C2\u6570");
  try {
    const parsed = await shortLinkService.parseShortLink(body.link);
    if (!parsed || !parsed.id) return jsonResponse(null, 500, "\u77ED\u94FE\u63A5\u89E3\u6790\u7ED3\u679C\u65E0\u6548");
    const result = await songListService.getListDetail(parsed.source, parsed.id);
    return jsonResponse(result);
  } catch (e) {
    return jsonResponse(null, 500, e.message || "\u89E3\u6790\u94FE\u63A5\u5931\u8D25");
  }
}
async function handleGetMusicUrlWithScript(request) {
  const body = await request.json();
  if (!body.source || !body.quality || !body.scriptContent) return jsonResponse(null, 400, "\u7F3A\u5C11\u5FC5\u8981\u53C2\u6570: source, quality, scriptContent");
  let rawScript = body.scriptContent;
  try {
    rawScript = atob(rawScript);
  } catch (_e) {
  }
  const scriptInfo = { id: "inline_script", name: body.scriptName || "Inline Script", rawScript };
  const runner = await getOrCreateRunner(scriptInfo);
  const musicInfo = body.musicInfo || {};
  const songId = body.songmid || body.id || body.songId || musicInfo?.id || musicInfo?.songmid || "";
  try {
    const result = await runner.request({
      source: body.source,
      action: "musicUrl",
      info: {
        type: body.quality,
        musicInfo: {
          id: songId,
          name: musicInfo?.name || "",
          singer: musicInfo?.singer || "",
          source: body.source,
          songmid: songId,
          interval: musicInfo?.interval || 0,
          meta: {
            songId,
            albumName: musicInfo?.albumName || musicInfo?.album || "",
            picUrl: musicInfo?.picUrl || musicInfo?.img || "",
            hash: musicInfo?.hash || musicInfo?.meta?.hash || "",
            strMediaMid: musicInfo?.strMediaMid || musicInfo?.meta?.strMediaMid || "",
            copyrightId: musicInfo?.copyrightId || musicInfo?.meta?.copyrightId || ""
          },
          typeUrl: {},
          albumId: musicInfo?.albumId || musicInfo?.meta?.albumId || "",
          types: musicInfo?.types || musicInfo?.qualitys || musicInfo?.meta?.qualitys || [],
          _types: {},
          hash: musicInfo?.hash || musicInfo?.meta?.hash || "",
          copyrightId: musicInfo?.copyrightId || musicInfo?.meta?.copyrightId || "",
          strMediaMid: musicInfo?.strMediaMid || musicInfo?.meta?.strMediaMid || "",
          albumMid: musicInfo?.albumMid || musicInfo?.meta?.albumMid || "",
          songId: musicInfo?.songId || musicInfo?.meta?.songId || songId,
          lrcUrl: musicInfo?.lrcUrl || musicInfo?.meta?.lrcUrl || "",
          mrcUrl: musicInfo?.mrcUrl || musicInfo?.meta?.mrcUrl || "",
          trcUrl: musicInfo?.trcUrl || musicInfo?.meta?.trcUrl || ""
        }
      }
    });
    return jsonResponse({ url: result.data.url, type: result.data.type || body.quality, source: body.source, quality: body.quality });
  } catch (error) {
    return jsonResponse(null, 500, error.message || "\u83B7\u53D6\u64AD\u653EURL\u5931\u8D25");
  }
}
function calculateScriptTimeouts(scriptIds, realAvailableCount) {
  const timeouts = /* @__PURE__ */ new Map();
  if (realAvailableCount === 0 || scriptIds.length === 0) return timeouts;
  const perScript = realAvailableCount === 1 ? 15e3 : realAvailableCount === 2 ? 7300 : 4300;
  for (const id of scriptIds) timeouts.set(id, perScript);
  console.log(`[API] \u52A8\u6001\u8D85\u65F6: \u811A\u672C\u6570=${realAvailableCount}, \u6BCF\u811A\u672C=${perScript}ms`);
  return timeouts;
}
async function handleGetMusicUrl(request, storage) {
  let scriptId = "unknown";
  let scriptName = "unknown";
  try {
    const body = await request.json();
    if (!body.source || !body.quality) return jsonResponse(null, 400, "\u7F3A\u5C11\u5FC5\u8981\u53C2\u6570: source, quality");
    const allowToggleSource = body.allowToggleSource !== false;
    const excludeSources = body.excludeSources || [];
    const songId = body.songmid || body.id || body.songId || body.musicInfo?.id || body.musicInfo?.songmid || body.musicInfo?.hash || "";
    const name = body.name || body.musicInfo?.name || "\u672A\u77E5\u6B4C\u66F2";
    const singer = body.singer || body.musicInfo?.singer || "\u672A\u77E5\u6B4C\u624B";
    const originalSource = body.source;
    const allScripts = await storage.getScripts();
    let availableScriptIds = [];
    const trippedScriptIds = [];
    for (const s of allScripts) {
      if (s.supportedSources.includes(originalSource)) {
        const isTripped = await storage.isScriptCircuitBreakerTripped(s.id);
        if (isTripped) {
          trippedScriptIds.push(s.id);
          console.log(`[API] \u26A0\uFE0F \u811A\u672C ${s.name} \u5DF2\u7194\u65AD\u4F46\u4ECD\u652F\u6301 ${originalSource}`);
        } else availableScriptIds.push(s.id);
      }
    }
    let needForceToggle = false;
    if (availableScriptIds.length === 0) {
      if (trippedScriptIds.length > 0) {
        availableScriptIds = [...trippedScriptIds];
        needForceToggle = true;
        console.log(`[API] \u26A0\uFE0F \u6240\u6709\u652F\u6301${originalSource}\u7684\u811A\u672C\u5747\u5DF2\u7194\u65AD(${trippedScriptIds.length}\u4E2A)\uFF0C\u964D\u7EA7\u4F7F\u7528`);
      } else {
        for (const s of allScripts) {
          if (s.supportedSources.includes(originalSource)) availableScriptIds.push(s.id);
        }
        if (availableScriptIds.length === 0) {
          if (allowToggleSource && originalSource !== "local") {
            console.log(`[API] \u{1F504} \u65E0\u811A\u672C\u652F\u6301 ${originalSource}\uFF0C\u7ACB\u5373\u6362\u6E90, allScripts=${allScripts.length}, allSources=${allScripts.map((s) => s.supportedSources.join(",")).join(";")}`);
            return await handleForceToggle(body, songId, name, singer, originalSource, excludeSources, storage);
          }
          return jsonResponse(null, 500, `\u6CA1\u6709\u652F\u6301 ${originalSource} \u6E90\u7684\u811A\u672C`, { source: originalSource, allScriptsCount: allScripts.length, allScriptsSources: allScripts.map((s) => ({ id: s.id, name: s.name, sources: s.supportedSources })) });
        } else {
          needForceToggle = true;
        }
      }
    }
    const sortedIds = await storage.getSortedScriptsBySuccessRate(availableScriptIds, (await storage.getDefaultScript())?.id ?? null);
    const scriptTimeouts = calculateScriptTimeouts(sortedIds, sortedIds.length);
    const triedScripts = [];
    let lastResult = null;
    const lyricPromise = getLyricForMusicUrl(body, songId, name, singer, originalSource);
    for (const currentScriptId of sortedIds) {
      const currentScript = allScripts.find((s) => s.id === currentScriptId);
      if (!currentScript) continue;
      scriptId = currentScriptId;
      scriptName = currentScript.name;
      const startTime = Date.now();
      let rawScript = null;
      try {
        rawScript = await storage.getScriptRaw(currentScriptId);
      } catch (_e) {
      }
      if (!rawScript) {
        triedScripts.push({ scriptId: currentScriptId, scriptName: currentScript.name, message: "\u65E0\u6CD5\u83B7\u53D6\u811A\u672C\u5185\u5BB9", responseTime: Date.now() - startTime });
        continue;
      }
      console.log(`[API] Initializing script ${currentScript.name}...`);
      let runner;
      try {
        runner = await getOrCreateRunner({ id: currentScriptId, name: currentScript.name, rawScript });
        console.log(`[API] Script ${currentScript.name} initialized OK`);
      } catch (error) {
        const diag = runner._featureDiagnostic ? " | features: " + runner._featureDiagnostic : "";
        const initErr = runner._scriptInitError || "";
        console.log(`[API] Script ${currentScript.name} init FAILED:`, error.message, "| diag:", diag, "| initErr:", initErr);
        triedScripts.push({ scriptId: currentScriptId, scriptName: currentScript.name, message: error.message + diag + (initErr ? " | raw:" + initErr : ""), responseTime: Date.now() - startTime });
        await storage.updateScriptStats(currentScriptId, false, Date.now() - startTime);
        await storage.recordScriptFailure(currentScriptId);
        continue;
      }
      try {
        const musicInfoSource = body.musicInfo?.source || body.source || "unknown";
        const result = await runner.request({
          source: musicInfoSource,
          action: "musicUrl",
          info: {
            type: body.quality,
            musicInfo: {
              id: songId,
              name,
              singer,
              source: musicInfoSource,
              songmid: songId,
              interval: body.interval || body.musicInfo?.interval || 0,
              meta: {
                songId,
                albumName: body.albumName || body.musicInfo?.albumName || body.musicInfo?.album || "",
                picUrl: body.picUrl || body.musicInfo?.picUrl || null,
                hash: body.hash || body.musicInfo?.hash || body.musicInfo?.songmid || "",
                strMediaMid: body.strMediaMid || body.musicInfo?.strMediaMid || "",
                copyrightId: body.copyrightId || body.musicInfo?.copyrightId || ""
              },
              albumName: body.albumName || body.musicInfo?.albumName || body.musicInfo?.album || "",
              img: body.picUrl || body.musicInfo?.picUrl || body.musicInfo?.img || "",
              typeUrl: {},
              albumId: body.albumId || body.musicInfo?.albumId || "",
              types: body.types || body.qualitys || body.musicInfo?.qualitys || [],
              _types: {},
              hash: body.hash || body.musicInfo?.hash || body.musicInfo?.songmid || "",
              copyrightId: body.copyrightId || body.musicInfo?.copyrightId || "",
              strMediaMid: body.strMediaMid || body.musicInfo?.strMediaMid || "",
              albumMid: body.albumMid || body.musicInfo?.albumMid || "",
              songId: body.songId || body.musicInfo?.songId || songId,
              lrcUrl: body.lrcUrl || body.musicInfo?.lrcUrl || "",
              mrcUrl: body.mrcUrl || body.musicInfo?.mrcUrl || "",
              trcUrl: body.trcUrl || body.musicInfo?.trcUrl || ""
            }
          },
          timeoutMs: scriptTimeouts.get(currentScriptId)
        });
        const responseTime = Date.now() - startTime;
        if (result.data.url) {
          if (result.data.url.endsWith("2149972737147268278.mp3")) {
            console.log(`[API] \u26A0\uFE0F \u68C0\u6D4B\u5230\u65E0\u6548URL(\u9ED1\u540D\u5355)\uFF0C\u89E6\u53D1\u6362\u6E90`);
            triedScripts.push({ scriptId: currentScriptId, scriptName: currentScript.name, message: "\u9ED1\u540D\u5355URL", responseTime });
            await storage.updateScriptStats(currentScriptId, false, responseTime);
            await storage.updateSourceStats(currentScriptId, originalSource, false);
            if (allowToggleSource) {
              const elapsedMs = responseTime;
              const toggleResult = await tryToggleSourceInternal(body, songId, name, singer, originalSource, excludeSources, currentScriptId, currentScript.name, runner, storage, elapsedMs);
              if (toggleResult.success && toggleResult.url) {
                return jsonResponse({
                  url: toggleResult.url,
                  type: toggleResult.type || body.quality,
                  source: toggleResult.newSource,
                  quality: body.quality,
                  lyric: "",
                  cached: false,
                  fallback: { toggled: true, originalSource, newSource: toggleResult.newSource, matchedSong: { name: toggleResult.matchedName, singer: toggleResult.matchedSinger } },
                  scriptId: currentScriptId,
                  scriptName: currentScript.name,
                  triedScripts: triedScripts.length > 0 ? triedScripts : void 0
                }, 200, "\u83B7\u53D6\u6210\u529F\uFF08\u6362\u6E90\uFF09");
              }
            }
            return jsonResponse(null, 500, "\u83B7\u53D6\u64AD\u653EURL\u5931\u8D25\uFF08\u9ED1\u540D\u5355\uFF09", { source: originalSource, scriptId: currentScriptId, scriptName: currentScript.name, triedScripts });
          }
          await storage.updateScriptStats(currentScriptId, true, responseTime);
          await storage.recordScriptSuccess(currentScriptId);
          await storage.updateSourceStats(currentScriptId, originalSource, true);
          const lyricResult = await Promise.race([lyricPromise, new Promise((r) => setTimeout(() => r({ lyric: "", tlyric: "", rlyric: "", lxlyric: "" }), 2e3))]);
          return jsonResponse({
            url: result.data.url,
            type: result.data.type || body.quality,
            source: originalSource,
            quality: body.quality,
            lyric: lyricResult.lyric,
            tlyric: lyricResult.tlyric,
            rlyric: lyricResult.rlyric,
            lxlyric: lyricResult.lxlyric,
            cached: false,
            fallback: { toggled: false, originalSource },
            scriptId: currentScriptId,
            scriptName: currentScript.name,
            triedScripts: triedScripts.length > 0 ? triedScripts : void 0
          }, 200, "\u83B7\u53D6\u6210\u529F");
        }
        throw new Error("\u83B7\u53D6\u64AD\u653EURL\u5931\u8D25");
      } catch (error) {
        const responseTime = Date.now() - startTime;
        const _diag = runner.getDiagnostics ? runner.getDiagnostics() : null;
        console.log(`[API] \u274C \u811A\u672C ${currentScript.name} \u5931\u8D25: ${error.message}, \u8017\u65F6: ${responseTime}ms`);
        triedScripts.push({ scriptId: currentScriptId, scriptName: currentScript.name, message: error.message || "\u672A\u77E5\u9519\u8BEF", responseTime, diagnostics: _diag });
        if (allowToggleSource) {
          console.log(`[API] \u{1F504} \u8C03\u7528 tryToggleSourceInternal (\u539F\u59CB\u6E90: ${originalSource})`);
          const elapsedMs = responseTime;
          const toggleResult = await tryToggleSourceInternal(body, songId, name, singer, originalSource, excludeSources, currentScriptId, currentScript.name, runner, storage, elapsedMs);
          if (toggleResult.success && toggleResult.url) {
            console.log(`[API] \u2705 tryToggleSourceInternal \u6362\u6E90\u6210\u529F: ${originalSource} -> ${toggleResult.newSource}`);
            return jsonResponse({
              url: toggleResult.url,
              type: toggleResult.type || body.quality,
              source: toggleResult.newSource,
              quality: body.quality,
              lyric: "",
              cached: false,
              fallback: { toggled: true, originalSource, newSource: toggleResult.newSource, matchedSong: { name: toggleResult.matchedName, singer: toggleResult.matchedSinger } },
              scriptId: currentScriptId,
              scriptName: currentScript.name,
              triedScripts: triedScripts.length > 0 ? triedScripts : void 0
            }, 200, "\u83B7\u53D6\u6210\u529F\uFF08\u6362\u6E90\uFF09");
          }
          console.log(`[API] tryToggleSourceInternal \u5931\u8D25: ${toggleResult.message}`);
        } else {
          console.log(`[API] \u6362\u6E90\u5DF2\u7981\u7528(allowToggleSource=false)`);
        }
        await storage.updateScriptStats(currentScriptId, false, responseTime);
        await storage.updateSourceStats(currentScriptId, originalSource, false);
        const circuitTripped = await storage.recordScriptFailure(currentScriptId);
        if (circuitTripped) console.log(`[API] \u{1F534} \u811A\u672C ${currentScript.name} \u5DF2\u89E6\u53D1\u7194\u65AD`);
        lastResult = { scriptId: currentScriptId, scriptName: currentScript.name, message: error.message };
      }
    }
    if (allowToggleSource && triedScripts.length > 0) {
      console.log(`[API] \u{1F504} \u6240\u6709\u652F\u6301 ${originalSource} \u7684\u811A\u672C\u5747\u5931\u8D25(${triedScripts.length}\u4E2A)\uFF0C\u89E6\u53D1\u6700\u7EC8\u8DE8\u811A\u672C\u6362\u6E90...`);
      try {
        const fallbackResp = await handleForceToggle(body, songId, name, singer, originalSource, [], storage);
        return fallbackResp;
      } catch (e) {
        console.log(`[API] \u6700\u7EC8\u8DE8\u811A\u672C\u6362\u6E90\u4E5F\u5931\u8D25: ${e.message}`);
      }
    }
    return jsonResponse(null, 500, "\u6240\u6709\u811A\u672C\u5747\u83B7\u53D6\u5931\u8D25", { source: originalSource, scriptId: lastResult?.scriptId || "unknown", scriptName: lastResult?.scriptName || "unknown", triedScripts });
  } catch (error) {
    return jsonResponse(null, 500, error.message || "Internal Server Error", { scriptId, scriptName });
  }
}
async function fastBuiltinMusicUrl(source, quality, songmid, name, singer) {
  const keyword = `${name} - ${singer}`;
  if (source === "kw") {
    try {
      const searchResp = await fetch(`http://search.kuwo.cn/r.s?all=${encodeURIComponent(keyword)}&ft=music&itemset=web_2013&client=kt&rformat=json&encoding=utf8`, {
        headers: { "User-Agent": "Mozilla/5.0", "Referer": "http://www.kuwo.cn" }
      });
      const searchData = await searchResp.json();
      const abslist = searchData?.abslist?.filter((s) => s?.RID) || [];
      if (abslist.length > 0) {
        const rid = abslist[0].RID;
        const proxyResp = await fetch(`https://api.nobb.cc/kuwo/url?rid=${rid}&br=${quality === "flac" ? "999k" : quality === "320k" ? "320kmp3" : "128kmp3"}`);
        const proxyData = await proxyResp.json();
        if (proxyData.code === 200 && proxyData.data?.url) return proxyData.data.url;
      }
    } catch (_e) {
    }
    throw new Error("kw fast path failed");
  }
  if (source === "kg") {
    try {
      const searchResp = await fetch(`http://msearchcdn.kugou.com/api/v3/search/song?format=json&keyword=${encodeURIComponent(keyword)}&page=1&pagesize=5`, {
        headers: { "User-Agent": "Mozilla/5.0", "KG-RC": "1" }
      });
      const searchData = await searchResp.json();
      const hash = searchData?.data?.info?.[0]?.hash;
      const albumId = searchData?.data?.info?.[0]?.album_id;
      if (hash && albumId) {
        const playResp = await fetch(`https://wwwapi.kugou.com/yy/index.php?r=play/getdata&hash=${hash}&album_id=${albumId}&mid=1_1`, {
          headers: { "User-Agent": "Mozilla/5.0", "Referer": "https://www.kugou.com/", "Origin": "https://www.kugou.com" }
        });
        const playData = await playResp.json();
        if (playData.data?.play_url) return playData.data.play_url;
      }
      throw new Error("kg play API blocked, try kw");
    } catch (kgErr) {
      console.log(`[FastPath] kg failed: ${kgErr.message}, falling back to kw...`);
      return fastBuiltinMusicUrl("kw", quality, songmid, name, singer);
    }
  }
  throw new Error(`fast path unsupported source: ${source}`);
}
async function handleForceToggle(body, songId, name, singer, originalSource, excludeSources, storage) {
  const allScripts = await storage.getScripts();
  const toggleSources = ["kw", "kg", "tx", "wy", "mg"].filter((s) => s !== originalSource && !excludeSources.includes(s));
  console.log(`[ForceToggle] \u539F\u59CB\u6E90 ${originalSource} \u65E0\u811A\u672C\uFF0C\u5C1D\u8BD5: [${toggleSources.join(",")}]`);
  const forceToggleLogs = [];
  for (const trySource of toggleSources) {
    for (const s of allScripts) {
      if (!s.supportedSources.includes(trySource)) {
        console.log(`[ForceToggle] \u23ED\uFE0F ${s.name} \u4E0D\u652F\u6301 ${trySource}\uFF0C\u4F46\u4ECD\u5C1D\u8BD5\uFF08builtin\u53EF\u80FD\u652F\u6301\uFF09`);
      }
      const isTripped = await storage.isScriptCircuitBreakerTripped(s.id);
      if (isTripped) {
        console.log(`[ForceToggle] \u8DF3\u8FC7\u7194\u65AD\u811A\u672C ${s.name}`);
        forceToggleLogs.push(`\u8DF3\u8FC7\u7194\u65AD: ${s.name}+${trySource}`);
        continue;
      }
      let rawScript = null;
      try {
        rawScript = await storage.getScriptRaw(s.id);
      } catch (_e) {
      }
      if (!rawScript) {
        forceToggleLogs.push(`\u65E0rawScript: ${s.name}+${trySource}`);
        continue;
      }
      if (trySource === "kw" || trySource === "kg") {
        console.log(`[ForceToggle] \u26A1 \u5FEB\u901F\u8DEF\u5F84 ${s.name} + ${trySource} (\u8DF3\u8FC7QuickJS)...`);
        try {
          const fastUrl = await fastBuiltinMusicUrl(trySource, body.quality, songId || "", name, singer);
          if (fastUrl) {
            await storage.updateScriptStats(s.id, true, 0);
            await storage.recordScriptSuccess(s.id);
            return jsonResponse({ url: fastUrl, type: body.quality, source: trySource, quality: body.quality, lyric: "", cached: false, fallback: { toggled: true, originalSource, newSource: trySource }, scriptId: s.id, scriptName: s.name }, 200, "\u83B7\u53D6\u6210\u529F\uFF08\u5FEB\u901F\u6362\u6E90\uFF09");
          }
        } catch (fe) {
          console.log(`[ForceToggle] \u26A1 \u5FEB\u901F\u8DEF\u5F84\u5931\u8D25: ${fe.message?.substring(0, 100)}, \u56DE\u9000\u5230\u5B8C\u6574\u8DEF\u5F84...`);
          forceToggleLogs.push(`\u5FEB\u901F\u8DEF\u5F84\u5931\u8D25: ${s.name}+${trySource}: ${fe.message?.substring(0, 80)}`);
        }
      }
      console.log(`[ForceToggle] \u{1F504} \u5C1D\u8BD5 ${s.name} + ${trySource} \u6E90...`);
      const runner = await getOrCreateRunner({ id: s.id, name: s.name, rawScript });
      try {
        console.log(`[ForceToggle] \u2705 ${s.name} \u521D\u59CB\u5316\u6210\u529F\uFF0C\u53D1\u8D77\u8BF7\u6C42...`);
        const result = await runner.request({
          source: trySource,
          action: "musicUrl",
          info: { type: body.quality, musicInfo: { id: songId, name, singer, source: trySource, songmid: songId, meta: { songId } } }
        });
        console.log(`[ForceToggle] \u{1F4CA} ${s.name}+${trySource} \u7ED3\u679C: url=${!!result.data.url}, data=${JSON.stringify(result.data || {}).substring(0, 100)}`);
        if (result.data.url) {
          await storage.updateScriptStats(s.id, true, 0);
          await storage.recordScriptSuccess(s.id);
          return jsonResponse({ url: result.data.url, type: result.data.type || body.quality, source: trySource, quality: body.quality, lyric: "", cached: false, fallback: { toggled: true, originalSource, newSource: trySource }, scriptId: s.id, scriptName: s.name }, 200, "\u83B7\u53D6\u6210\u529F\uFF08\u5F3A\u5236\u6362\u6E90\uFF09");
        }
        forceToggleLogs.push(`${s.name}+${trySource}: url\u4E3A\u7A7A`);
      } catch (ftErr) {
        console.log(`[ForceToggle] \u274C ${s.name}+${trySource} \u5F02\u5E38: ${ftErr.message?.substring(0, 120)}`);
        const diag = runner.getDiagnostics ? runner.getDiagnostics() : null;
        forceToggleLogs.push(`${s.name}+${trySource} \u5F02\u5E38: ${ftErr.message?.substring(0, 80)}`);
        if (diag?.keyLogs) forceToggleLogs.push(...diag.keyLogs.slice(-20));
      }
    }
  }
  console.log(`[ForceToggle] \u6240\u6709\u6B63\u5E38\u811A\u672C\u5931\u8D25\uFF0C\u5C1D\u8BD5\u964D\u7EA7(\u5FFD\u7565\u7194\u65AD)...`);
  for (const s of allScripts) {
    if (!s.supportedSources.includes("wy")) continue;
    let rawScript = null;
    try {
      rawScript = await storage.getScriptRaw(s.id);
    } catch (_e) {
    }
    if (!rawScript) continue;
    const runner = await getOrCreateRunner({ id: s.id, name: s.name, rawScript });
    try {
      const result = await runner.request({ source: "wy", action: "musicUrl", info: { type: body.quality, musicInfo: { id: songId || "", name, singer, source: "wy", songmid: songId || "", meta: { songId: songId || "" } } } });
      if (result.data.url) return jsonResponse({ url: result.data.url, type: result.data.type || body.quality, source: "wy", quality: body.quality, lyric: "", cached: false, fallback: { toggled: true, originalSource, newSource: "wy" }, scriptId: s.id, scriptName: s.name }, 200, "\u83B7\u53D6\u6210\u529F\uFF08\u5F3A\u5236\u6362\u6E90-\u964D\u7EA7\uFF09");
      const diag = runner.getDiagnostics ? runner.getDiagnostics() : null;
      forceToggleLogs.push(`\u964D\u7EA7wy: url\u4E3A\u7A7A`);
      if (diag?.keyLogs) forceToggleLogs.push(...diag.keyLogs.slice(-20));
    } catch (e) {
      const diag = runner.getDiagnostics ? runner.getDiagnostics() : null;
      forceToggleLogs.push(`\u964D\u7EA7wy\u5F02\u5E38: ${e.message?.substring(0, 80)}`);
      if (diag?.keyLogs) forceToggleLogs.push(...diag.keyLogs.slice(-20));
    }
  }
  for (const s of allScripts) {
    if (!s.supportedSources.includes("kw")) continue;
    let rawScript = null;
    try {
      rawScript = await storage.getScriptRaw(s.id);
    } catch (_e) {
    }
    if (!rawScript) continue;
    const runner = await getOrCreateRunner({ id: s.id, name: s.name, rawScript });
    try {
      const result = await runner.request({ source: "kw", action: "musicUrl", info: { type: body.quality, musicInfo: { id: songId || "", name, singer, source: "kw", songmid: songId || "", meta: { songId: songId || "" } } } });
      if (result.data.url) return jsonResponse({ url: result.data.url, type: result.data.type || body.quality, source: "kw", quality: body.quality, lyric: "", cached: false, fallback: { toggled: true, originalSource, newSource: "kw" }, scriptId: s.id, scriptName: s.name }, 200, "\u83B7\u53D6\u6210\u529F\uFF08\u5F3A\u5236\u6362\u6E90-\u964D\u7EA7\uFF09");
      const diag = runner.getDiagnostics ? runner.getDiagnostics() : null;
      forceToggleLogs.push(`\u964D\u7EA7kw: url\u4E3A\u7A7A`);
      if (diag?.keyLogs) forceToggleLogs.push(...diag.keyLogs.slice(-20));
    } catch (e) {
      const diag = runner.getDiagnostics ? runner.getDiagnostics() : null;
      forceToggleLogs.push(`\u964D\u7EA7kw\u5F02\u5E38: ${e.message?.substring(0, 80)}`);
      if (diag?.keyLogs) forceToggleLogs.push(...diag.keyLogs.slice(-20));
    } finally {
    }
  }
  return jsonResponse(null, 500, `\u6CA1\u6709\u652F\u6301 ${originalSource} \u6E90\u7684\u811A\u672C\u4E14\u6362\u6E90\u5931\u8D25`, { source: originalSource, forceToggleLogs });
}
async function tryToggleSourceInternal(body, songId, name, singer, originalSource, excludeSources, scriptId, scriptName, runner, storage, elapsedMs) {
  console.log(`[ToggleSource] === \u51FD\u6570\u88AB\u8C03\u7528! originalSource=${originalSource}, name=${name}, singer=${singer}, songId=${songId} ===`);
  const keyword = `${name} ${singer}`.trim();
  const allSources = ["kw", "kg", "tx", "wy", "mg"];
  const sourcesToTry = allSources.filter((s) => s !== originalSource && !excludeSources.includes(s));
  if (sourcesToTry.length === 0) return { success: false, message: "\u6CA1\u6709\u53EF\u7528\u7684\u6362\u6E90\u6E90" };
  console.log(`[ToggleSource] \u5F00\u59CB\u6362\u6E90: "${keyword}", \u539F\u59CB\u6E90: ${originalSource}, \u5019\u9009: [${sourcesToTry.join(",")}], \u5DF2\u8017\u65F6: ${elapsedMs}ms`);
  let matchedSongs = [];
  try {
    const searchPromises = sourcesToTry.map(async (source) => {
      try {
        const results = await searchService.search(keyword, source, 1, 10);
        const platformResult = results.find((r) => r.platform === source);
        return { source, results: platformResult?.results || [] };
      } catch (e) {
        return { source, results: [] };
      }
    });
    const searchResultsArray = await Promise.all(searchPromises);
    for (const { source, results } of searchResultsArray) {
      if (results.length === 0 || results.length === 1 && !results[0].name) continue;
      const matched = findBestMatch(results, name, singer, body.interval || body.musicInfo?.interval, body.albumName || body.musicInfo?.albumName || body.musicInfo?.album || "");
      if (matched) {
        matchedSongs.push({ ...matched, source });
        console.log(`[ToggleSource] \u641C\u7D22\u5339\u914D ${source}: ${matched.name} - ${matched.singer} (${(matched.matchScore || 0).toFixed(2)})`);
      }
    }
  } catch (e) {
    console.log(`[ToggleSource] \u641C\u7D22\u9636\u6BB5\u5F02\u5E38: ${e.message}`);
  }
  if (matchedSongs.length === 0) {
    console.log("[ToggleSource] \u641C\u7D22\u672A\u627E\u5230\u5339\u914D\uFF0C\u5207\u6362\u5230\u76F4\u63A5\u91CD\u8BD5\u6A21\u5F0F\uFF08\u7528\u539F\u6B4C\u66F2\u4FE1\u606F\u5C1D\u8BD5\u6240\u6709\u5019\u9009\u6E90\uFF09");
    for (const src of sourcesToTry) {
      matchedSongs.push({ name, singer, source: src, songmid: songId || "", id: songId || "", hash: songId || "", interval: body.interval || body.musicInfo?.interval || "", albumName: body.albumName || body.musicInfo?.albumName || "", picUrl: body.picUrl || "", musicInfo: { name, singer, source: src, songmid: songId }, matchScore: 0.5 });
    }
  }
  const sourceStats = await storage.getSourceStats();
  const sortedSongs = sortByMatchAndSuccessRate(matchedSongs, sourceStats[scriptId] || {});
  for (const song of sortedSongs) {
    const newSource = song.source;
    const newSongId = song.musicInfo?.songmid || song.songmid || song.id || song.hash;
    console.log(`[ToggleSource] \u5C1D\u8BD5 ${newSource} (songId: ${newSongId || "(\u539F)"})`);
    try {
      const result = await runner.request({
        source: newSource,
        action: "musicUrl",
        info: { type: body.quality, musicInfo: {
          id: newSongId || songId,
          name: song.name,
          singer: song.singer,
          source: newSource,
          songmid: newSongId || songId,
          interval: song.interval || "",
          meta: { songId: newSongId || songId },
          albumName: song.albumName || "",
          img: song.picUrl || ""
        } }
      });
      if (result.data.url) {
        await storage.updateSourceStats(scriptId, newSource, true);
        await storage.updateScriptStats(scriptId, true, 0);
        await storage.recordScriptSuccess(scriptId);
        return { success: true, url: result.data.url, type: result.data.type, newSource, matchedName: song.name, matchedSinger: song.singer, message: "ok" };
      }
      await storage.updateSourceStats(scriptId, newSource, false);
    } catch (e) {
      console.log(`[ToggleSource] ${newSource} \u5F02\u5E38: ${e.message}`);
      await storage.updateSourceStats(scriptId, newSource, false);
    }
  }
  return { success: false, message: "\u6240\u6709\u97F3\u6E90\u5747\u83B7\u53D6\u5931\u8D25" };
}
function findBestMatch(results, targetName, targetSinger, targetInterval, targetAlbumName) {
  if (results.length === 0) return null;
  const singersRxp = /、|&|;|；|\/|,|，|\|/;
  const sortSingle = (s) => singersRxp.test(s) ? s.split(singersRxp).sort((a, b) => a.localeCompare(b)).join("\u3001") : s || "";
  const filterStr = (s) => typeof s === "string" ? s.replace(/\s|'|\.|,|，|&|"|、|\(|\)|（|）|`|~|-|<|>|\||\/|\]|\[|!|！/g, "").toLowerCase() : String(s || "").toLowerCase();
  const trimStr = (s) => typeof s === "string" ? s.trim() : s || "";
  const getIntv = (intv) => {
    if (!intv) return 0;
    if (typeof intv === "number") return intv;
    const parts = intv.split(":");
    let result = 0, unit = 1;
    while (parts.length) {
      result += parseInt(parts.pop() || "0") * unit;
      unit *= 60;
    }
    return result;
  };
  const fName = filterStr(targetName), fSinger = filterStr(sortSingle(targetSinger)), fAlbum = filterStr(targetAlbumName || ""), fIntv = getIntv(targetInterval);
  const processed = results.map((item) => ({
    ...item,
    fName: filterStr(trimStr(item.name || "")),
    fSinger: filterStr(sortSingle(trimStr(item.singer || ""))),
    fAlbum: filterStr(trimStr(item.albumName || "")),
    fIntv: getIntv(item.interval),
    intervalMatch: Math.abs((getIntv(item.interval) || fIntv) - (fIntv || getIntv(item.interval))) < 5 && !!fIntv,
    nameMatch: filterStr(trimStr(item.name || "")) === fName,
    singerMatch: filterStr(sortSingle(trimStr(item.singer || ""))) === fSinger,
    albumMatch: filterStr(trimStr(item.albumName || "")) === fAlbum
  }));
  const sortMusic = (list, fn) => [...list.filter(fn), ...list.filter((item) => !fn(item))];
  let sorted = [...processed];
  sorted = sortMusic(sorted, (i) => i.singerMatch && i.nameMatch && i.intervalMatch);
  sorted = sortMusic(sorted, (i) => i.nameMatch && i.singerMatch && i.fAlbum === fAlbum);
  sorted = sortMusic(sorted, (i) => i.singerMatch && i.nameMatch);
  sorted = sortMusic(sorted, (i) => i.nameMatch && i.intervalMatch);
  sorted = sortMusic(sorted, (i) => i.singerMatch && i.intervalMatch);
  sorted = sortMusic(sorted, (i) => i.intervalMatch);
  sorted = sortMusic(sorted, (i) => i.nameMatch);
  sorted = sortMusic(sorted, (i) => i.singerMatch);
  const best = sorted[0];
  if (!best) return null;
  let score = 0;
  if (best.nameMatch) score += 0.4;
  else if (fName.includes(best.fName) || best.fName.includes(fName)) score += 0.2;
  if (best.singerMatch) score += 0.3;
  else if (fSinger.includes(best.fSinger) || best.fSinger.includes(fSinger)) score += 0.15;
  if (best.intervalMatch) score += 0.2;
  if (fAlbum && best.albumMatch) score += 0.1;
  score += Math.max(0, (processed.length - 1) / processed.length * 0.1);
  if (score < 0.3 && !best.intervalMatch) return null;
  return { ...best, matchScore: score };
}
function sortByMatchAndSuccessRate(songs, sourceStats) {
  const getRate = (src) => {
    const s = sourceStats[src];
    if (!s) return 0.5;
    const t = s.success + s.fail;
    return t === 0 ? 0.5 : s.success / t;
  };
  return songs.sort((a, b) => {
    const sA = (a.matchScore || 0) * 0.5 + getRate(a.source) * 0.3 + Math.min((sourceStats[a.source]?.success || 0) / 100, 0.2);
    const sB = (b.matchScore || 0) * 0.5 + getRate(b.source) * 0.3 + Math.min((sourceStats[b.source]?.success || 0) / 100, 0.2);
    return sB - sA;
  });
}
async function getLyricForMusicUrl(body, songId, name, singer, source) {
  try {
    const musicInfo = { source };
    switch (source) {
      case "kw":
        musicInfo.songmid = songId;
        break;
      case "kg":
        musicInfo.hash = songId;
        musicInfo.name = name;
        break;
      case "tx":
        musicInfo.songId = songId;
        break;
      case "wy":
        musicInfo.songId = songId;
        break;
      case "mg":
        musicInfo.copyrightId = songId;
        musicInfo.name = name;
        musicInfo.singer = singer;
        break;
    }
    const result = await lyricService.getLyric(musicInfo);
    return { lyric: result.lyric || "", tlyric: result.tlyric || "", rlyric: result.rlyric || "", lxlyric: result.lxlyric || "" };
  } catch (_e) {
    return { lyric: "", tlyric: "", rlyric: "", lxlyric: "" };
  }
}
var index_default = {
  async fetch(request, env, ctx) {
    const url = new URL(request.url);
    if (request.method === "OPTIONS") return new Response(null, { headers: corsHeaders() });
    const apiKey = env.API_KEY || "";
    const storage = new ScriptStorage(env.DB);
    const pathParts = url.pathname.split("/").filter(Boolean);
    const apiKeyInPath = pathParts[0];
    const isApiCall = pathParts.length >= 2 && (pathParts[1] === "api" || pathParts[1] === "scripts");
    if (isApiCall && apiKeyInPath !== apiKey) return jsonResponse(null, 401, "\u65E0\u6548\u7684 API Key");
    const pathEndsWith = (suffix) => url.pathname.endsWith(suffix);
    if (pathEndsWith("/setup")) {
      return jsonResponse({ apiKey, endpoints: {
        importScript: `POST /${apiKey}/api/scripts/import/url`,
        getMusicUrl: `POST /${apiKey}/api/music/url`,
        loadedScripts: `GET /${apiKey}/api/scripts/loaded`,
        search: `GET /${apiKey}/api/search?keyword=xxx&source=kw&page=1&limit=20`,
        songListDetail: `POST /${apiKey}/api/songlist/detail`,
        songListByLink: `POST /${apiKey}/api/songlist/detail/by-link`
      } });
    }
    try {
      switch (`${request.method} ${url.pathname}`) {
        case `GET /health`:
          return jsonResponse({ code: 200, msg: "success", data: { status: "ok", service: "cf-phg-music-server" } });
        case `POST /${apiKey}/api/scripts/import/url`:
          return await withTimeout(handleImportScriptFromUrl(request, storage), REQUEST_TIMEOUT_MS);
        case `POST /${apiKey}/api/scripts/import/raw`:
          return await withTimeout(handleImportScriptRaw(request, storage), REQUEST_TIMEOUT_MS);
        case `POST /${apiKey}/api/music/url`:
          return await withTimeout(handleGetMusicUrl(request, storage), REQUEST_TIMEOUT_MS);
        case `POST /${apiKey}/api/music/lyric`:
          return await withTimeout(handleGetLyric(request), REQUEST_TIMEOUT_MS);
        case `POST /${apiKey}/api/music/url/inline`:
          return await withTimeout(handleGetMusicUrlWithScript(request), REQUEST_TIMEOUT_MS);
        case `GET /${apiKey}/api/scripts/loaded`:
          return await withTimeout(handleGetLoadedScripts(request, storage), REQUEST_TIMEOUT_MS);
        case `POST /${apiKey}/api/scripts/default`:
          return await withTimeout(handleSetDefaultScript(request, storage), REQUEST_TIMEOUT_MS);
        case `GET /${apiKey}/api/scripts/default`:
          return await withTimeout(handleGetDefaultScript(storage), REQUEST_TIMEOUT_MS);
        case `POST /${apiKey}/api/scripts/delete`:
          return await withTimeout(handleDeleteScript(request, storage), REQUEST_TIMEOUT_MS);
        case `GET /${apiKey}/api/search`:
        case `GET /${apiKey}/api/search/`:
          return await withTimeout(handleSearch(request), REQUEST_TIMEOUT_MS);
        case `POST /${apiKey}/api/songlist/detail`:
          return await withTimeout(handleGetSongListDetail(request), REQUEST_TIMEOUT_MS);
        case `POST /${apiKey}/api/songlist/detail/by-link`:
          return await withTimeout(handleGetSongListDetailByLink(request), REQUEST_TIMEOUT_MS);
        case `GET /${apiKey}`:
          return jsonResponse({ status: "ok", version: "1.0.0", endpoints: [
            "POST /{key}/api/scripts/import/url - \u5BFC\u5165\u811A\u672C",
            "POST /{key}/api/music/url - \u83B7\u53D6\u97F3\u4E50URL",
            "GET /{key}/api/scripts/loaded - \u5DF2\u52A0\u8F7D\u811A\u672C\u5217\u8868",
            "POST /{key}/api/scripts/default - \u8BBE\u7F6E\u9ED8\u8BA4\u811A\u672C",
            "GET /{key}/api/scripts/default - \u83B7\u53D6\u9ED8\u8BA4\u811A\u672C",
            "POST /{key}/api/scripts/delete - \u5220\u9664\u811A\u672C",
            "GET /{key}/api/search?keyword=xxx - \u641C\u7D22\u6B4C\u66F2",
            "POST /{key}/api/songlist/detail - \u6B4C\u5355\u8BE6\u60C5",
            "POST /{key}/api/songlist/detail/by-link - \u94FE\u63A5\u89E3\u6790\u6B4C\u5355"
          ] });
        default:
          if (url.pathname === "/" || url.pathname === "/health") return jsonResponse({ status: "ok", service: "cf-phg-music-server" });
          if (url.pathname === "/debug/fetch-test") {
            const testUrl = url.searchParams.get("url") || "https://88.lxmusic.xn--fiqs8s/lxmusicv4/url/tx/000mNo691TTyRP/128k?sign=3d70d2d3dfde12d07c892b458cb768e8ee94418966c96654f66c9cad6e269814";
            try {
              const resp = await fetch(testUrl, { headers: { "Content-Type": "application/json", "User-Agent": "lx-music-desktop/2.0.0", "X-Request-Key": "lxmusic" } });
              const body = await resp.text();
              return jsonResponse({ status: resp.status, statusText: resp.statusText, bodyPreview: body.substring(0, 500) });
            } catch (e) {
              return jsonResponse({ error: e.message });
            }
          }
          return jsonResponse(null, 404, "Not Found");
      }
    } catch (error) {
      return jsonResponse(null, 500, error.message || "Internal Server Error");
    } finally {
      await storage.flush();
    }
  }
};
function corsHeaders() {
  return { "Access-Control-Allow-Origin": "*", "Access-Control-Allow-Methods": "GET, POST, OPTIONS", "Access-Control-Allow-Headers": "Content-Type, Authorization" };
}
async function withTimeout(promise, ms) {
  const controller = new AbortController();
  const timeoutId = setTimeout(() => controller.abort(), ms);
  try {
    const result = await promise;
    clearTimeout(timeoutId);
    return result;
  } catch (error) {
    clearTimeout(timeoutId);
    if (error.name === "AbortError") throw new Error("\u8BF7\u6C42\u8D85\u65F6 (" + ms + "ms)");
    throw error;
  }
}
export {
  index_default as default
};
/*! Bundled license information:

pako/dist/pako.esm.mjs:
  (*! pako 2.1.0 https://github.com/nodeca/pako @license (MIT AND Zlib) *)
*/
